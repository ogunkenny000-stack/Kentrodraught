BEGIN;
ALTER TABLE public.global_chat ADD COLUMN IF NOT EXISTS "deletedForEveryone" boolean NOT NULL DEFAULT false;
ALTER TABLE public.private_messages ADD COLUMN IF NOT EXISTS "deletedForEveryone" boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS "statusQuote" text;
COMMIT;
