BEGIN;
REVOKE ALL ON FUNCTION public.debit_wallet(text,numeric,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.credit_wallet(text,numeric,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.debit_multiple_wallets(text[],numeric,text,text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.refund_tournament_entries(text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.pay_tournament_prize(text,text,numeric) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.debit_wallet(text,numeric,text,text), public.credit_wallet(text,numeric,text,text), public.debit_multiple_wallets(text[],numeric,text,text), public.refund_tournament_entries(text), public.pay_tournament_prize(text,text,numeric) TO service_role;
COMMIT;
