# WrongHint2 v3 official evaluation return

All four official controls passed. Pytest: all 4 expected FAIL_TO_PASS tests failed on the broken version and passed on the reference, and all 62 PASS_TO_PASS tests passed on both. SymPy: the expected FAIL_TO_PASS test failed on the broken version and passed on the reference, and all 6 PASS_TO_PASS tests passed on both. No expected tests were missing. Control checks, exact commands, reports and raw test logs are in `RESULTS.json` and `runs/`.

The exact pytest candidate patch was evaluated once after the control gate. It applied, tests were collected and executed, and the official report says unresolved. All four expected FAIL_TO_PASS tests still failed; 60 of 62 PASS_TO_PASS tests passed, with `test_record_property` and `test_record_property_same_name` failing. The test process exit code was 1. This one patch was selected in conditions N and D; map this one outcome to both records, not two independent repairs. No SymPy candidate was staged or tested.

The candidate SHA-256 before and after evaluation was `f671a167c1a8108e1f09633e6c342400b1a5f6408fc81d0b9ea19c8dc26c783a`. All 26 handoff hashes and the 679 recorded harness source hashes matched. The imported harness source matched the prior pinned manifest for commit `02e7a74ffd0b707aab73d203fe87bdc7c76afc8e`; the source was an unpacked tree without Git metadata. Image identities and digest-pinned pull commands are in `PREFLIGHT.json` and `images/`.

The first attempt stopped during image pull at the 8 GB storage guard; `previous_storage_blocked_attempt.zip` preserves it. The successful retry used one image and one worker at a time, with a 3 GB pull reserve and a 1.5 GB container watchdog. No paid compute, new inference, publication or Kaggle change occurred.
