# Execute private official evaluation of the preserved WrongHint2 v3 distinct candidate

Read this handoff and verify SHA256.json. Use the existing Docker-capable WrongHint host. No paid compute, public publishing, competition edits, new inference, candidate modification or selection. Preserve prior results and other projects' resources.

Verify the actual imported SWE-bench harness against commit 02e7a74ffd0b707aab73d203fe87bdc7c76afc8e. Prior metadata commit: 3d07b464b7b311a0cbfb5ed5b2d8a3b96f84a33d. Preserve all original task fields and the included documented image/evaluation metadata adaptation. TASKS_PINNED.json retains exact digest-pinned images. Check space/CPU/memory before starting, use one worker and disposable containers, preserve all environment/command/image/harness identities.

Before the candidate, revalidate broken AND reference controls for BOTH tasks. Broken uses broken_control_predictions.jsonl; reference uses the harness's predictions_path=gold. Previous valid patterns were Pytest: 4 FAIL_TO_PASS broken failures/reference passes plus 62 maintained PASS_TO_PASS; SymPy: 1 FAIL_TO_PASS broken failure/reference pass plus 6 maintained PASS_TO_PASS. Collect every expected test; skipped/missing collection is not a pass. Independently check raw statuses, exact applied patches, report parsing, startup/infrastructure flags and exit codes. If a task's control pair fails, report that and do not test its candidate.

Template, replacing absolute paths and unique run IDs after validating the pinned CLI:

    /workspace/wronghint/venv/bin/python -m swebench.harness.run_evaluation --dataset_name /ABS/HANDOFF/TASKS_PINNED.json --predictions_path /ABS/HANDOFF/broken_control_predictions.jsonl --instance_ids pytest-dev__pytest-5205 sympy__sympy-18903 --max_workers 1 --timeout 1800 --run_id wh2v3_broken_UNIQUE

Repeat with --predictions_path gold and a new reference run ID. The inert marker in broken predictions ensures no source change while allowing evaluation; it is an infrastructure control, never a model repair.

After all four control runs validate, run candidate_predictions.jsonl for pytest-dev__pytest-5205 only, with the same pinned task/image/harness and a distinct run ID. PATCH_IDENTITY.json records the exact pre-execution review. Verify candidate.diff SHA before/after. No post-test fixes, test-feedback loops, retries, hidden best-of selection or endpoint changes.

Return all command/configuration records, Docker image identities, raw control/candidate stdout and test logs, exact tested patches, parsed reports, expected-test recount and hashes in a ZIP. Distinguish applicability failure, startup/infrastructure failure, unresolved after collected tests and official resolution. A gold reference control is never a Gemma success.

These are two exposed development tasks. Keep both control pairs; evaluate the one distinct Pytest patch once and map the verified outcome to both N and D selection records. No SymPy candidate exists. A duplicate is not an independent repair. No competition submission change.
