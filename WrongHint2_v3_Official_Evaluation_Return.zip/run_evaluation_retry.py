from pathlib import Path
import json,subprocess,os,datetime,hashlib,time,shutil,traceback
from swebench.harness.utils import make_test_spec
from swebench.harness.grading import get_logs_eval,parse_test_exit_code,_resolve_case,test_passed,test_maintained
b=Path('/workspace/wronghint2_v3_evaluation_20261105'); h=b/'handoff'; r=b/'return_retry'; rows=json.loads((h/'TASKS_PINNED.json').read_text()); rows={x['instance_id']:x for x in rows}; env=os.environ.copy(); env['HF_HOME']='/workspace/wronghint/hf-cache'
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
docker=['docker','--host=unix:///var/run/docker.sock']; expected_hash=json.loads((h/'PATCH_IDENTITY.json').read_text())['sha256']; results={'controls':{},'candidate':{'status':'not_run'},'images':{},'candidate_sha256_before':hashlib.sha256((h/'candidate.diff').read_bytes()).hexdigest()};assert results['candidate_sha256_before']==expected_hash

def save(): (r/'RESULTS.json').write_text(json.dumps(results,indent=2))
def pull(tid):
 row=rows[tid];image=row['image'];root=r/'images'/tid;root.mkdir(parents=True,exist_ok=True);d=root/('attempt_'+str(len(list(root.glob('attempt_*')))+1));d.mkdir();cached=subprocess.run(docker+['image','inspect',image],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0;results['images'][tid]={'digest_reference':image,'preexisting':cached,'attempt_dir':str(d.relative_to(r))};save()
 if not cached:
  cmd=docker+['pull',image];(d/'pull_command.json').write_text(json.dumps(cmd,indent=2));print('PULL',tid,flush=True)
  with (d/'pull.log').open('w') as f:
   p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT);start=time.monotonic();reason=None
   while p.poll() is None:
    if shutil.disk_usage(b).free<3_000_000_000: reason='free space fell below 3,000,000,000 bytes during pull';p.terminate();break
    if time.monotonic()-start>1500:reason='pull timeout at 1500 seconds';p.terminate();break
    time.sleep(2)
   try:p.wait(timeout=30)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  results['images'][tid].update({'pull_exit_code':p.returncode,'pull_stop_reason':reason});save()
  if p.returncode:raise RuntimeError('image pull failed: '+str(reason or p.returncode))
 x=subprocess.run(docker+['image','inspect',image],env=env,capture_output=True,text=True);(d/'image_inspect.json').write_text(x.stdout);(d/'image_inspect.stderr').write_text(x.stderr)
 if x.returncode:raise RuntimeError('pinned image inspect failed')
 if shutil.disk_usage(b).free<2_500_000_000:raise RuntimeError('insufficient free space for vfs container after pull')
def cleanup(tid):
 image=rows[tid]['image'];d=r/results['images'].get(tid,{}).get('attempt_dir',('images/'+tid))
 if not results['images'].get(tid,{}).get('preexisting',True):
  x=subprocess.run(docker+['image','rm',image],env=env,capture_output=True,text=True);(d/'remove.log').write_text(x.stdout+x.stderr)
  for _ in range(45):
   if shutil.disk_usage(b).free>20_000_000_000:break
   time.sleep(2)
def run(tid,label):
 row=rows[tid];d=r/'runs'/tid/label;d.mkdir(parents=True);rid='wh2v3_'+label+'_'+tid+'_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');pred={'broken':str(h/'broken_control_predictions.jsonl'),'reference':'gold','candidate':str(h/'candidate_predictions.jsonl')}[label];cmd=['/workspace/wronghint/venv/bin/python','-m','swebench.harness.run_evaluation','--dataset_name',str(h/'TASKS_PINNED.json'),'--predictions_path',pred,'--instance_ids',tid,'--max_workers','1','--timeout','1800','--run_id',rid];(d/'command.json').write_text(json.dumps({'argv':cmd,'cwd':str(d),'run_id':rid},indent=2));print('START',tid,label,flush=True)
 with (d/'console.log').open('w') as f:
  proc=subprocess.Popen(cmd,cwd=d,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True); start=time.monotonic(); stop_reason=None
  while proc.poll() is None:
   if shutil.disk_usage(b).free<1_500_000_000: stop_reason='free space fell below 1.5 GB while running harness';break
   if time.monotonic()-start>2200: stop_reason='harness timeout';break
   time.sleep(2)
  if stop_reason:
   import signal
   os.killpg(proc.pid,signal.SIGTERM); containers=subprocess.run(docker+['ps','-a','--filter','name='+rid,'--format','{{.ID}}'],env=env,capture_output=True,text=True).stdout.split()
   if containers: subprocess.run(docker+['rm','-f']+containers,env=env,stdout=f,stderr=subprocess.STDOUT)
   try: proc.wait(timeout=30)
   except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   f.write('\nWATCHDOG: '+stop_reason+'\n'); rc=None
  else:rc=proc.returncode
 reps=list((d/'logs/evaluation'/rid).glob('*/*/report.json'));v={'run_id':rid,'process_returncode':rc,'report_count':len(reps),'valid':False}
 if len(reps)==1:
  try:
   rp=reps[0];report=json.loads(rp.read_text())[tid];log=rp.with_name('test_output.txt');spec=make_test_spec(row);statuses,parsed=get_logs_eval(spec,str(log));ec=parse_test_exit_code(log.read_text()); missing=[k for k in spec.FAIL_TO_PASS+spec.PASS_TO_PASS if _resolve_case(k,statuses) is None];f2p={k:statuses.get(_resolve_case(k,statuses)) for k in spec.FAIL_TO_PASS};p2p={k:statuses.get(_resolve_case(k,statuses)) for k in spec.PASS_TO_PASS};expected=row['patch'] if label=='reference' else next(json.loads(x)['model_patch'] for x in Path(pred).read_text().splitlines() if json.loads(x)['instance_id']==tid);patchfile=rp.with_name('patch.diff');exact=patchfile.is_file() and patchfile.read_text()==expected;valid=bool(rc==0 and parsed and not missing and exact and report.get('patch_successfully_applied') and not report.get('infra_failure') and all(test_maintained(k,statuses) for k in spec.PASS_TO_PASS) and (all(x == 'FAILED' for x in f2p.values()) if label=='broken' else all(test_passed(k,statuses) for k in spec.FAIL_TO_PASS)) and report.get('resolved')==(label=='reference') and ec==(1 if label=='broken' else 0));v.update({'valid':valid,'resolved':report.get('resolved'),'patch_exact':exact,'patch_successfully_applied':report.get('patch_successfully_applied'),'infrastructure_failure':report.get('infra_failure'),'test_exit_code':ec,'parser_recognized_output':parsed,'missing_expected_tests':missing,'FAIL_TO_PASS':f2p,'PASS_TO_PASS':p2p,'report_path':str(rp.relative_to(r)),'test_output_path':str(log.relative_to(r))})
  except Exception as e:v['validation_error']=repr(e);v['traceback']=traceback.format_exc()
 (d/'VALIDATION.json').write_text(json.dumps(v,indent=2));print('DONE',tid,label,'valid',v['valid'],flush=True);return v
try:
 for tid in ['pytest-dev__pytest-5205','sympy__sympy-18903']:
  try:
   pull(tid)
   for label in ['broken','reference']:
    v=run(tid,label);results['controls'][tid+':'+label]=v;save()
    if not v['valid']:raise RuntimeError('control invalid: '+tid+' '+label)
  finally:cleanup(tid)
 tid='pytest-dev__pytest-5205'
 try:
  pull(tid);v=run(tid,'candidate');results['candidate']['evaluation']=v
  if v.get('infrastructure_failure') or v.get('process_returncode') is None or v.get('report_count')!=1:status='blocked_by_infrastructure'
  elif not v.get('patch_successfully_applied'):status='failed_to_apply'
  elif not v.get('parser_recognized_output') or v.get('test_exit_code') is None:status='failed_before_test_collection'
  elif v.get('resolved'):status='resolved'
  else:status='ran_tests_unresolved'
  results['candidate'].update({'status':status,'mapped_conditions':['N','D'],'independent_patches':1})
 finally:cleanup(tid)
except Exception as e:
 results['blocker']=repr(e);results['traceback']=traceback.format_exc();print('STOP',repr(e),flush=True)
finally:
 results['candidate_sha256_after']=hashlib.sha256((h/'candidate.diff').read_bytes()).hexdigest();results['candidate_unchanged']=results['candidate_sha256_after']==expected_hash;save()
