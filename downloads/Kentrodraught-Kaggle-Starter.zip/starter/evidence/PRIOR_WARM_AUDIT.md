# Prior warm-training audit

Audited on 25 October 2026 (Africa/Lagos). Read-only audit of the first twelve
completed warm rounds; this report does not claim that round 13 has completed.
All twelve completed validation-record hashes were independently checked.

Twelve rounds produced four qualified candidates (1, 3, 6, 12), six rejected
primary strength comparisons (2, 4, 5, 8, 10, 11), and two rounds with no eligible
model (7, 9). **No candidate achieved seven actual wins in ten fresh games.**

Scores are wins–losses–rule draws–move-limit cutoffs. Primary/control blocks
contain twenty games each at one second per move; confirmations contain ten.
Defense columns show losses in the paired forty-position defensive tests.

| Round | Control primary | Candidate primary | Fresh confirmation | Defense losses control→candidate | Qualified |
|---|---|---|---|---|---|
| 1 | 1–0–18–1 | 2–0–17–1 | 1–0–9–0 | 18→18 | Yes |
| 2 | 1–0–17–2 | 1–1–16–2 | — | —→— | No |
| 3 | 2–3–14–1 | 2–1–17–0 | 0–0–10–0 | 18→12 | Yes |
| 4 | 3–1–16–0 | 2–1–16–1 | — | —→— | No |
| 5 | 2–0–17–1 | 1–0–19–0 | — | —→— | No |
| 6 | 6–6–7–1 | 7–5–8–0 | 2–2–5–1 | 18→15 | Yes |
| 7 | — | — | — | —→— | No |
| 8 | 2–1–17–0 | 2–1–17–0 | — | —→— | No |
| 9 | — | — | — | —→— | No |
| 10 | 3–1–16–0 | 3–1–14–2 | — | —→— | No |
| 11 | 5–1–14–0 | 4–2–14–0 | — | —→— | No |
| 12 | 0–0–19–1 | 2–0–17–1 | 0–0–9–1 | 17→19 | Yes |

Across the ten primary comparisons, candidates recorded 26W/12L/155 rule draws/
7 cutoffs versus controls' 25W/13L/155 rule draws/7 cutoffs, over 200 games each.
This pooled description combines different models and openings; it is not an
independent win-rate estimate or proof of a lasting strength increase.

The four qualified fresh confirmations total 3W/2L/33 rule draws/2 cutoffs over
forty games. Round 6's seven primary wins occurred in twenty games, not ten.

## Qualified champion at the audit checkpoint

Round 12 is the recorded qualified champion. Its primary candidate score was
2W/0L/17 rule draws/1 cutoff against unchanged C++, compared with control's
0W/0L/19 rule draws/1 cutoff on the same opening set. Its fresh confirmation was
0W/0L/9 rule draws/1 cutoff. Its defensive loss count worsened from control's
17/40 to candidate's 19/40. The existing four-loss regression allowance admitted
that result; qualification must not be described as uniform improvement.

All six integration checks passed: tests, Clippy, smoke, rule parity, exact zero
and inference parity. All 359 certificates passed (320 tactics, 15 middlegame,
24 king positions). All nine protected engine source/data/manifest files still
match the integration report's checksums. The C++ executable remains unchanged.
Compiled/native parity covered 197,014 unique held-out positions with zero
residual and total-score error.

Verified artifact hashes:

| Artifact | SHA-256 |
|---|---|
| Validation record | `4abf1b8a85db2cfcac79f4520e1cd472cdce3b18338573b55eea2f6c0649e4ef` |
| Engine binary | `1593f67bd0c158ef7ba4dbb9541eec93944ad7a8427f0c391090fe3c4e0bc26b` |
| Embedded model | `07002b819ddc3dbef3ddf003bd41587475cee5fddb257df2f73cbad517cf2aae` |
| Integration report | `1601e57a14a07195d27d86cf3faf0d2cf4d90a67f929447c634897c5f7634435` |
| Candidate archive | `8a4bc468ba08a9a2d777ec4e69795c29f00156683a51b5c9073c4eabafedcaa0` |
| Unchanged C++ | `f0db50c49ef811ddae6a95822be32bee595719485c6148558bd0950a4aa2c793` |

Artifact paths:

- Validation record: `/workspace/rust-draughts/strength-v05/king-curriculum/broad-strength/warm-learning/round-012/validation/status.json`
- Engine binary: `/workspace/rust-draughts/strength-v05/king-curriculum/broad-strength/warm-learning/round-012/engine-check/target/release/scan_nigerian`
- Embedded model: `/workspace/rust-draughts/strength-v05/king-curriculum/broad-strength/warm-learning/round-012/source/data/eval_nnue.nnk`
- Integration report: `/workspace/rust-draughts/strength-v05/king-curriculum/broad-strength/warm-learning/round-012/engine-check/report.json`
- Candidate archive: `/workspace/rust-draughts/strength-v05/king-curriculum/broad-strength/warm-learning/round-012/validation-candidate.zip`

## Training-method implication

The dominant observed failure is lack of repeatable winning conversion, rather
than failed tactical checks. Round 12's known-outcome held-out BCE was
0.5569098869905326 versus frozen CORE's 0.5662542024503799. Those numbers establish
prediction improvement on that corpus, not a match win rate. Held-out corpora
change across rounds, so cross-round BCE declines are not a paired trend.

Every warm round still obtains bootstrap values from the frozen static CORE
(`nnue/continuous.py`, `phase_main`; `prepare_long_targets.py`, `trace_targets`).
Known games use .65 MC + .25 TD(lambda=.98) + .10 bootstrap. Unknown move-limit
cutoffs use .8 TD + .2 bootstrap and retain zero MC mass. The shared 32-unit
residual has gradients only with kings or near-crown men; ordinary early men
positions remain gated off.

The strongest isolated next experiment is training-only deep conversion
teaching using the current qualified champion and complete histories. Replace
only registered training bootstrap values, retrace affected TD targets using
the unchanged formula, retain genuine recorded outcomes and every held-out
array, and require the same fresh strength checks. This is a proposed method,
not evidence that deep teaching has already run or succeeded.
