# Portable Rust training starter

This directory can be uploaded as a private Kaggle dataset. Import `Kaggle_Rust_Training.ipynb` into the Kaggle account used by the receiving ChatGPT conversation. The notebook locates the attached starter, verifies frozen input hashes, builds/tests the dependency-free Rust trainer, and validates the native corpus. No optimizer runs by default. The transferred round-13 corpus/model pair already completed all four local fits and produced no eligible checkpoint. An optional four-trial rerun is explicitly a reproducibility check, not new training progress. Python performs scheduling and fixed-prediction audits only. GPU/TPU training kernels are not implemented.

Command-line usage:

```sh
python run_training.py --root . --output /kaggle/working/rust-training-001 --dry-run
python run_training.py --root . --output /kaggle/working/rust-preflight-001 --check-only
# Optional reproduction of already-completed local work:
python run_training.py --root . --output /kaggle/working/rust-reproduction-001 --workers 4 --purpose reproduce
```

Install NumPy and a stable Rust toolchain with Clippy if unavailable. Rust >=1.85 supports the engine's 2024 edition; the trainer itself uses the 2021 edition and has no third-party Cargo dependencies. Cargo runs offline with the supplied lockfile. The output directory must not exist. `--max-seconds N` optionally imposes a caller-chosen wall-time limit; there is no default compute cap in this launcher.

The CPU IDs are derived from the actual Kaggle affinity mask, not assumed to be 0–3. Four fixed trials use seeds 173/997, anchors .02/.1, twelve epochs, batch256, learning rate .003, default L2 .00001 and clip10, and the original .7/.2/.1 group mixture. All initial weights must exactly match the qualified transferred model and each epoch-zero model. Adam state starts fresh. Native checkpoint eligibility requires primary BCE improvement over that initializer; the independent outcome audit additionally requires strict true-MC BCE gain over both initializer and static core. Move-limit cutoffs retain zero MC mass.

This portable driver is not a resumed historical continuous controller. `--purpose train-new` rejects the exact already-fitted transferred corpus/model pair; prepare and verify a genuinely changed deep-teaching corpus before using that purpose. The separate research handoff contains the next method as unexecuted source. No new deep labels, fits or strength evidence exist yet. Its preregistration records source hashes, input hashes, actual CPU affinity and configuration. It preserves all four trial reports and returns the exact initial champion if no checkpoint qualifies. No model is adopted into an engine automatically; `playing_strength_validated` and `target_reached` remain false.

The frozen corpus manifest contains original machine paths and provenance. The launcher ignores those paths when opening files, using local `data/corpus.bin`, `data/true-outcomes.npz` and `model/eval_nnue.nnk`; their hashes must match the original manifest and qualified evidence. Retain the original manifest unchanged.

After offline fitting, use the complete research handoff to run engine integration, exact compiled/native parity, rule parity, 359 tactical checks, stricter defense comparison and fresh preregistered 1-second games against unchanged C++. Preserve incomplete or losing match evidence and choose new seeds for a genuinely new validation. A training loss improvement is not proof of stronger play or a 70% win rate.
