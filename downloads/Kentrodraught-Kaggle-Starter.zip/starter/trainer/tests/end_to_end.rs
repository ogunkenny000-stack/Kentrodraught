use native_king_nnue::data::Corpus;
use native_king_nnue::inference::{active, Model};
use native_king_nnue::train::{train, Config, Metrics};

#[test]
fn real_format_corpus_native_training_and_quantized_artifacts() {
    let mut bytes = b"NNKCOR01".to_vec();
    bytes.extend_from_slice(&64_u64.to_le_bytes());
    for validation in 0_u8..2 {
        for group in 0_u8..4 {
            for row in 0_u8..8 {
                let features = [row + 1 + 9 * validation, 75 + row % 5, 123];
                assert!(active(&features));
                bytes.extend_from_slice(&[3, validation, group, 1 | ((row % 2) << 1)]);
                for number in [0.2_f32, [0.85, 0.6, 0.45, 0.55][usize::from(group)], 0.125] {
                    bytes.extend_from_slice(&number.to_le_bytes());
                }
                bytes.extend_from_slice(&features);
            }
        }
    }
    let corpus = Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).unwrap();
    corpus.validate_training().unwrap();
    let unique = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
    let directory = std::env::temp_dir().join(format!("native-nnue-smoke-{}-{unique}", std::process::id()));
    let config = Config { epochs: 5, batch: 8, seed: 73, ..Config::default() };
    train(&corpus, "synthetic-test-only", &directory, &config).unwrap();
    let report = std::fs::read_to_string(directory.join("report.json")).unwrap();
    assert!(report.contains("\"language\":\"Rust\""));
    assert!(report.contains("\"playing_strength_validated\":false"));
    let zero = Model::load(directory.join("epoch-000.nnk")).unwrap();
    assert!(corpus.records.iter().all(|row| zero.predict(row.ids(), row.active()) == 0));
    let final_model = Model::load(directory.join("epoch-005.nnk")).unwrap();
    let metrics = Metrics::evaluate(&corpus, &final_model);
    let baseline = Metrics::evaluate(&corpus, &zero);
    assert!(metrics.groups[0][0].bce < baseline.groups[0][0].bce);
    assert!(corpus.records.iter().any(|row| final_model.predict(row.ids(), row.active()) != 0));
    let selected = Model::load(directory.join("selected.nnk")).unwrap();
    assert_eq!(selected.to_bytes().unwrap().len(), 13_016);
    // Refuse accidental reuse instead of mixing artifacts from distinct trials.
    assert!(train(&corpus, "synthetic-test-only", &directory, &config).is_err());
    std::fs::remove_dir_all(directory).unwrap();
}
