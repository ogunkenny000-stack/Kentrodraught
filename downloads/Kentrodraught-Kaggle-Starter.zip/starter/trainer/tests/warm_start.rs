use native_king_nnue::data::Corpus;
use native_king_nnue::inference::{active, Model};
use native_king_nnue::train::{train, train_from_model, Config, FloatModel, Metrics};
use std::path::{Path, PathBuf};
use std::process::Command;

struct Fixture {
    directory: PathBuf,
    corpus_bytes: Vec<u8>,
}

impl Fixture {
    fn new() -> Self {
        let unique = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let directory = std::env::temp_dir().join(format!("native-nnue-warm-{}-{unique}", std::process::id()));
        std::fs::create_dir(&directory).unwrap();
        let mut corpus_bytes = b"NNKCOR01".to_vec();
        corpus_bytes.extend_from_slice(&64_u64.to_le_bytes());
        for validation in 0_u8..2 {
            for group in 0_u8..4 {
                for row in 0_u8..8 {
                    let features = [row + 1 + 9 * validation, 75 + row % 5, 123];
                    assert!(active(&features));
                    corpus_bytes.extend_from_slice(&[3, validation, group, 1 | ((row % 2) << 1)]);
                    for value in [0.2_f32, [0.85, 0.6, 0.45, 0.55][usize::from(group)], 0.125] {
                        corpus_bytes.extend_from_slice(&value.to_le_bytes());
                    }
                    corpus_bytes.extend_from_slice(&features);
                }
            }
        }
        std::fs::write(directory.join("corpus.bin"), &corpus_bytes).unwrap();
        Self { directory, corpus_bytes }
    }

    fn corpus(&self) -> Corpus {
        Corpus::from_reader(self.corpus_bytes.as_slice(), self.corpus_bytes.len() as u64).unwrap()
    }

    fn out(&self, name: &str) -> PathBuf { self.directory.join(name) }
}

impl Drop for Fixture {
    fn drop(&mut self) { let _ = std::fs::remove_dir_all(&self.directory); }
}

fn initial_model() -> Model {
    let mut model = Model::zero();
    // A small nonzero residual with nonzero gradients on the common king.
    model.bias[0] = 128;
    model.input[123][0] = 256;
    model.output[0] = 64;
    model
}

#[test]
fn warm_training_keeps_exact_epoch_zero_and_updates_native_weights() {
    let fixture = Fixture::new();
    let corpus = fixture.corpus();
    let initial = initial_model();
    let bytes = initial.to_bytes().unwrap();
    let config = Config { epochs: 3, batch: 8, seed: 73, learning_rate: 0.01, ..Config::default() };
    let output = fixture.out("trained");
    train_from_model(&corpus, "synthetic-only", &output, &config, &initial, "champion\"with\nlabel").unwrap();
    assert_eq!(std::fs::read(output.join("epoch-000.nnk")).unwrap(), bytes);
    let final_model = Model::load(output.join("epoch-003.nnk")).unwrap();
    assert_ne!(final_model, initial, "native optimization must actually update warm weights");
    let before = Metrics::evaluate(&corpus, &initial);
    let after = Metrics::evaluate(&corpus, &final_model);
    assert!(after.groups[0][0].bce < before.groups[0][0].bce);
    let report = std::fs::read_to_string(output.join("report.json")).unwrap();
    assert!(report.contains("\"mode\":\"warm_start\""));
    assert!(report.contains("\"source\":\"champion\\\"with\\nlabel\""));
    assert!(report.contains("\"epoch_zero_exact_source_bytes\":true"));
    assert!(report.contains("\"optimizer_state_restored\":false"));
    assert!(report.contains("\"baseline_metrics_reference\":\"epoch_000\""));
    assert!(train_from_model(&corpus, "synthetic-only", &output, &config, &initial, "champion").is_err());
}

#[test]
fn ineligible_warm_checkpoints_keep_the_original_champion() {
    let fixture = Fixture::new();
    let initial = initial_model();
    let output = fixture.out("ineligible");
    let config = Config { epochs: 2, batch: 8, minimum_primary_improvement: 100.0, ..Config::default() };
    train_from_model(&fixture.corpus(), "synthetic-only", &output, &config, &initial, "champion").unwrap();
    assert_eq!(std::fs::read(output.join("selected.nnk")).unwrap(), initial.to_bytes().unwrap());
    let report = std::fs::read_to_string(output.join("report.json")).unwrap();
    assert!(report.contains("\"selected_epoch\":0"));
    assert!(report.contains("\"eligible_checkpoint_found\":false"));
}

#[test]
fn legacy_train_api_retains_seeded_random_initialization() {
    let fixture = Fixture::new();
    let config = Config { epochs: 1, batch: 8, seed: 991, ..Config::default() };
    let output = fixture.out("fresh");
    train(&fixture.corpus(), "synthetic-only", &output, &config).unwrap();
    assert_eq!(std::fs::read(output.join("epoch-000.nnk")).unwrap(),
        FloatModel::new(config.seed).quantize().unwrap().to_bytes().unwrap());
    let report = std::fs::read_to_string(output.join("report.json")).unwrap();
    assert!(report.contains("\"mode\":\"fresh_random_input_zero_output\""));
}

#[test]
fn unsupported_initial_weights_fail_before_creating_a_trial() {
    let fixture = Fixture::new();
    let mut model = initial_model();
    model.output[0] = 2049;
    let output = fixture.out("unsupported");
    assert!(train_from_model(&fixture.corpus(), "synthetic-only", &output, &Config::default(), &model, "bad").is_err());
    assert!(!output.exists());
}

fn cli(corpus: &Path, output: &Path, options: &[&str]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_native-nnue"))
        .arg("train").arg(corpus).arg(output).args(options).output().unwrap()
}

#[test]
fn cli_warm_start_loads_real_model_and_no_argument_stays_fresh() {
    let fixture = Fixture::new();
    let model_path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/champion9.nnk");
    let model_text = model_path.to_str().unwrap();
    let warm = fixture.out("cli-warm");
    let result = cli(&fixture.out("corpus.bin"), &warm,
        &["--init-model", model_text, "--epochs", "1", "--batch", "8"]);
    assert!(result.status.success(), "{}", String::from_utf8_lossy(&result.stderr));
    assert_eq!(std::fs::read(warm.join("epoch-000.nnk")).unwrap(), std::fs::read(&model_path).unwrap());
    let fresh = fixture.out("cli-fresh");
    let result = cli(&fixture.out("corpus.bin"), &fresh, &["--epochs", "1", "--batch", "8"]);
    assert!(result.status.success(), "{}", String::from_utf8_lossy(&result.stderr));
    let initial = Model::load(fresh.join("epoch-000.nnk")).unwrap();
    assert!(fixture.corpus().records.iter().all(|row| initial.predict(row.ids(), row.active()) == 0));
}

#[test]
fn cli_rejects_missing_duplicate_or_corrupted_initial_model() {
    let fixture = Fixture::new();
    let corpus = fixture.out("corpus.bin");
    for (name, options) in [
        ("missing-value", vec!["--init-model"]),
        ("missing-file", vec!["--init-model", "this-model-does-not-exist.nnk"]),
        ("duplicate", vec!["--init-model", "one.nnk", "--init-model", "two.nnk"]),
    ] {
        let output = fixture.out(name);
        assert!(!cli(&corpus, &output, &options).status.success());
        assert!(!output.exists());
    }
    let bad_model = fixture.out("bad.nnk");
    let mut bytes = include_bytes!("fixtures/champion9.nnk").to_vec();
    bytes[20] = 1; // Unsupported model flags must not be ignored.
    std::fs::write(&bad_model, bytes).unwrap();
    let output = fixture.out("corrupt");
    assert!(!cli(&corpus, &output, &["--init-model", bad_model.to_str().unwrap()]).status.success());
    assert!(!output.exists());
}
