use crate::data::{Corpus, Record, GROUP_NAMES};
use crate::inference::{rotate, Model, HIDDEN, INPUTS, Q};
use crate::{invalid, json_string, write_atomic};
use std::io;
use std::path::Path;
use std::time::Instant;

const BIAS: usize = INPUTS * HIDDEN;
const OUTPUT: usize = BIAS + HIDDEN;
const PARAMETERS: usize = OUTPUT + HIDDEN;

#[derive(Clone, Debug)]
pub struct Config {
    pub epochs: usize,
    pub seed: u64,
    pub batch: usize,
    pub learning_rate: f64,
    pub anchor_strength: f64,
    pub l2: f64,
    pub group_mix: [f64; 3],
    pub anchor_rms_limit: f64,
    pub minimum_primary_improvement: f64,
    pub gradient_clip: f64,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            epochs: 10, seed: 173, batch: 256, learning_rate: 0.003,
            anchor_strength: 0.02, l2: 1.0e-5, group_mix: [0.7, 0.2, 0.1],
            anchor_rms_limit: 150.0, minimum_primary_improvement: 0.0001,
            gradient_clip: 10.0,
        }
    }
}

impl Config {
    pub fn validate(&self) -> io::Result<()> {
        if self.epochs == 0 || self.batch == 0 || self.epochs > 10000
            || !self.learning_rate.is_finite() || self.learning_rate <= 0.0
            || !self.anchor_strength.is_finite() || self.anchor_strength < 0.0
            || !self.l2.is_finite() || self.l2 < 0.0
            || !self.gradient_clip.is_finite() || self.gradient_clip <= 0.0
            || !self.anchor_rms_limit.is_finite() || self.anchor_rms_limit < 0.0
            || !self.minimum_primary_improvement.is_finite() || self.minimum_primary_improvement < 0.0
            || self.group_mix.iter().any(|x| !x.is_finite() || *x < 0.0)
            || (self.group_mix.iter().sum::<f64>() - 1.0).abs() > 1.0e-9
        {
            return Err(invalid("invalid optimizer or checkpoint configuration"));
        }
        Ok(())
    }

    fn json(&self) -> String {
        format!("{{\"epochs\":{},\"seed\":{},\"batch\":{},\"learning_rate\":{},\"anchor_strength\":{},\"l2\":{},\"group_mix\":[{},{},{}],\"active_anchor_rms_limit_internal\":{},\"minimum_primary_bce_improvement\":{},\"gradient_clip\":{},\"parameter_clamp\":8,\"optimizer\":\"Adam(beta1=0.9,beta2=0.999,epsilon=1e-8)\"}}", self.epochs, self.seed, self.batch, self.learning_rate, self.anchor_strength, self.l2, self.group_mix[0], self.group_mix[1], self.group_mix[2], self.anchor_rms_limit, self.minimum_primary_improvement, self.gradient_clip)
    }
}

struct Rng(u64);
impl Rng {
    fn new(seed: u64) -> Self { Self(if seed == 0 { 0x9e3779b97f4a7c15 } else { seed }) }
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 >> 12;
        self.0 ^= self.0 << 25;
        self.0 ^= self.0 >> 27;
        self.0.wrapping_mul(0x2545f4914f6cdd1d)
    }
    fn unit(&mut self) -> f64 { ((self.next() >> 11) as f64) / ((1_u64 << 53) as f64) }
    fn shuffle(&mut self, rows: &mut [usize]) {
        for index in (1..rows.len()).rev() {
            // Rejection sampling avoids modulo bias while remaining deterministic.
            let width = (index + 1) as u64;
            let limit = u64::MAX - u64::MAX % width;
            let mut random = self.next();
            while random >= limit { random = self.next(); }
            rows.swap(index, (random % width) as usize);
        }
    }
}

#[derive(Clone)]
pub struct FloatModel { pub parameters: Vec<f64> }

struct Forward {
    white: [f64; HIDDEN],
    black: [f64; HIDDEN],
    raw: f64,
    residual: f64,
}

impl FloatModel {
    pub fn new(seed: u64) -> Self {
        let mut parameters = vec![0.0; PARAMETERS];
        let mut random = Rng::new(seed);
        let scale = (6.0 / ((INPUTS + HIDDEN) as f64)).sqrt();
        for value in &mut parameters[..BIAS] { *value = (2.0 * random.unit() - 1.0) * scale; }
        // Exact-zero output preserves the existing evaluator at initialization.
        Self { parameters }
    }

    /// Initialize weights from a quantized model without changing its bytes.
    /// The optimizer accepts a narrower domain than integer inference: reject
    /// unsupported coefficients rather than clipping the supplied champion.
    pub fn from_quantized(model: &Model) -> io::Result<Self> {
        model.validate()?;
        let mut parameters = vec![0.0; PARAMETERS];
        let scale = f64::from(Q);
        for (input, row) in model.input.iter().enumerate() {
            for (hidden, &value) in row.iter().enumerate() {
                parameters[input * HIDDEN + hidden] = f64::from(value) / scale;
            }
        }
        for hidden in 0..HIDDEN {
            parameters[BIAS + hidden] = f64::from(model.bias[hidden]) / scale;
            parameters[OUTPUT + hidden] = f64::from(model.output[hidden]) / scale;
        }
        let result = Self { parameters };
        // Quantization validates the floating parameter domain before casting.
        // Dividing by the power-of-two scale is exact; require every serialized
        // coefficient to survive before allowing any training artifact writes.
        if result.quantize()?.to_bytes()? != model.to_bytes()? {
            return Err(invalid("initial model did not round-trip exactly through float weights"));
        }
        Ok(result)
    }

    // Matching indices expose the fixed-width dense arithmetic across packed
    // parameter vectors and both orientation accumulators to vectorization.
    #[allow(clippy::needless_range_loop)]
    fn forward(&self, record: &Record) -> Forward {
        let mut white = [0.0; HIDDEN];
        let mut black = [0.0; HIDDEN];
        if !record.active() { return Forward { white, black, raw: 0.0, residual: 0.0 }; }
        white.copy_from_slice(&self.parameters[BIAS..OUTPUT]);
        black = white;
        for &id in record.ids() {
            let index = usize::from(id) * HIDDEN;
            let flipped = usize::from(rotate(id)) * HIDDEN;
            for hidden in 0..HIDDEN {
                white[hidden] += self.parameters[index + hidden];
                black[hidden] += self.parameters[flipped + hidden];
            }
        }
        let mut raw = 0.0;
        for hidden in 0..HIDDEN {
            raw += self.parameters[OUTPUT + hidden]
                * (white[hidden].clamp(0.0, 8.0) - black[hidden].clamp(0.0, 8.0)) * 0.5;
        }
        Forward { white, black, raw, residual: raw.clamp(-2.5, 2.5) }
    }

    pub fn residual(&self, record: &Record) -> f64 { self.forward(record).residual }

    /// Accumulate exact analytic derivatives of coefficient * loss. For an
    /// anchor the loss is residual-logit squared; other groups use soft BCE.
    #[allow(clippy::needless_range_loop)]
    fn gradient(&self, record: &Record, coefficient: f64, anchor: bool, gradient: &mut [f64]) {
        if !record.active() || coefficient == 0.0 { return; }
        let forward = self.forward(record);
        if forward.raw <= -2.5 || forward.raw >= 2.5 { return; }
        let derivative = coefficient * if anchor {
            2.0 * forward.residual
        } else {
            sigmoid(record.baseline + forward.residual) - record.target
        };
        let mut white_gradient = [0.0; HIDDEN];
        let mut black_gradient = [0.0; HIDDEN];
        for hidden in 0..HIDDEN {
            gradient[OUTPUT + hidden] += derivative * 0.5
                * (forward.white[hidden].clamp(0.0, 8.0) - forward.black[hidden].clamp(0.0, 8.0));
            let output = self.parameters[OUTPUT + hidden];
            if forward.white[hidden] > 0.0 && forward.white[hidden] < 8.0 {
                white_gradient[hidden] = derivative * 0.5 * output;
            }
            if forward.black[hidden] > 0.0 && forward.black[hidden] < 8.0 {
                black_gradient[hidden] = -derivative * 0.5 * output;
            }
            gradient[BIAS + hidden] += white_gradient[hidden] + black_gradient[hidden];
        }
        for &id in record.ids() {
            let index = usize::from(id) * HIDDEN;
            let flipped = usize::from(rotate(id)) * HIDDEN;
            for hidden in 0..HIDDEN {
                gradient[index + hidden] += white_gradient[hidden];
                gradient[flipped + hidden] += black_gradient[hidden];
            }
        }
    }

    #[allow(clippy::needless_range_loop)]
    pub fn quantize(&self) -> io::Result<Model> {
        if self.parameters.len() != PARAMETERS || self.parameters.iter().any(|p| !p.is_finite() || p.abs() > 8.0) {
            return Err(invalid("non-finite or out-of-range float parameter"));
        }
        let mut model = Model::zero();
        for input in 0..INPUTS {
            for hidden in 0..HIDDEN {
                model.input[input][hidden] = (self.parameters[input * HIDDEN + hidden] * f64::from(Q)).round() as i16;
            }
        }
        for hidden in 0..HIDDEN {
            model.bias[hidden] = (self.parameters[BIAS + hidden] * f64::from(Q)).round() as i32;
            model.output[hidden] = (self.parameters[OUTPUT + hidden] * f64::from(Q)).round() as i16;
        }
        model.validate()?;
        Ok(model)
    }
}

pub fn sigmoid(value: f64) -> f64 {
    if value >= 0.0 { 1.0 / (1.0 + (-value).exp()) } else { let exp = value.exp(); exp / (1.0 + exp) }
}

pub fn bce(logit: f64, target: f64) -> f64 {
    logit.max(0.0) - logit * target + (-logit.abs()).exp().ln_1p()
}

#[derive(Clone, Copy, Default, Debug)]
pub struct GroupMetrics {
    pub weight: f64,
    pub active_weight: f64,
    pub bce: f64,
    pub residual_rms: f64,
    pub active_residual_rms: f64,
    pub active_cap_fraction: f64,
    pub residual_mean: f64,
}

#[derive(Clone, Default, Debug)]
pub struct Metrics { pub groups: [[GroupMetrics; 4]; 2] }

impl Metrics {
    pub fn evaluate(corpus: &Corpus, model: &Model) -> Self {
        let mut result = Self::default();
        for record in &corpus.records {
            let residual = f64::from(model.predict(record.ids(), record.active()));
            let metrics = &mut result.groups[usize::from(record.validation)][usize::from(record.group)];
            metrics.weight += record.weight;
            if record.active() { metrics.active_weight += record.weight; }
            if residual.abs() >= 500.0 { metrics.active_cap_fraction += record.weight; }
            metrics.bce += record.weight * bce(record.baseline + residual / 200.0, record.target);
            metrics.residual_rms += record.weight * residual * residual;
            metrics.residual_mean += record.weight * residual;
        }
        for split in &mut result.groups {
            for group in split {
                if group.weight > 0.0 {
                    group.bce /= group.weight;
                    if group.active_weight > 0.0 {
                        group.active_residual_rms = (group.residual_rms / group.active_weight).sqrt();
                        group.active_cap_fraction /= group.active_weight;
                    }
                    group.residual_rms = (group.residual_rms / group.weight).sqrt();
                    group.residual_mean /= group.weight;
                }
            }
        }
        result
    }

    pub fn json(&self) -> String {
        let splits: Vec<String> = (0..2).map(|split| {
            let groups: Vec<String> = (0..4).map(|group| {
                let value = self.groups[split][group];
                format!("\"{}\":{{\"weight\":{:.12},\"active_weight\":{:.12},\"bce\":{:.12},\"residual_rms_internal\":{:.9},\"active_residual_rms_internal\":{:.9},\"active_cap_fraction\":{:.9},\"residual_mean_internal\":{:.9}}}", GROUP_NAMES[group], value.weight, value.active_weight, value.bce, value.residual_rms, value.active_residual_rms, value.active_cap_fraction, value.residual_mean)
            }).collect();
            format!("\"{}\":{{{}}}", if split == 0 { "training" } else { "validation" }, groups.join(","))
        }).collect();
        format!("{{{}}}", splits.join(","))
    }
}

struct Adam {
    first: Vec<f64>, second: Vec<f64>, beta1_power: f64, beta2_power: f64,
}
impl Adam {
    fn new() -> Self {
        Self { first: vec![0.0; PARAMETERS], second: vec![0.0; PARAMETERS], beta1_power: 1.0, beta2_power: 1.0 }
    }
    fn step(&mut self, model: &mut FloatModel, gradient: &mut [f64], config: &Config) -> io::Result<()> {
        let decay = 2.0 * config.l2 / PARAMETERS as f64;
        for (grad, parameter) in gradient.iter_mut().zip(&model.parameters) { *grad += decay * parameter; }
        let norm = gradient.iter().map(|grad| grad * grad).sum::<f64>().sqrt();
        if !norm.is_finite() { return Err(invalid("non-finite training gradient")); }
        let scale = if norm > config.gradient_clip { config.gradient_clip / norm } else { 1.0 };
        self.beta1_power *= 0.9;
        self.beta2_power *= 0.999;
        for (index, &grad) in gradient.iter().enumerate() {
            let grad = grad * scale;
            self.first[index] = 0.9 * self.first[index] + 0.1 * grad;
            self.second[index] = 0.999 * self.second[index] + 0.001 * grad * grad;
            let first = self.first[index] / (1.0 - self.beta1_power);
            let second = self.second[index] / (1.0 - self.beta2_power);
            model.parameters[index] = (model.parameters[index] - config.learning_rate * first / (second.sqrt() + 1.0e-8)).clamp(-8.0, 8.0);
        }
        Ok(())
    }
}

/// Train against fixed splits only. Every checkpoint decision uses quantized
/// inference on held-out primary rows, with a separate anchor drift limit.
pub fn train(corpus: &Corpus, corpus_path: &str, out: &Path, config: &Config) -> io::Result<()> {
    train_initialized(corpus, corpus_path, out, config, None)
}

/// Fine-tune existing quantized weights with freshly initialized Adam state.
/// `initial_source` is a provenance label, normally the loaded model's path.
/// The caller/orchestrator should independently retain that file's SHA-256.
pub fn train_from_model(corpus: &Corpus, corpus_path: &str, out: &Path, config: &Config,
    initial: &Model, initial_source: &str) -> io::Result<()> {
    train_initialized(corpus, corpus_path, out, config, Some((initial, initial_source)))
}

fn train_initialized(corpus: &Corpus, corpus_path: &str, out: &Path, config: &Config,
    initialization: Option<(&Model, &str)>) -> io::Result<()> {
    config.validate()?;
    corpus.validate_training()?;
    // Reject unsupported warm starts before creating a trial directory.
    let warmed = initialization.map(|(model, _)| FloatModel::from_quantized(model)).transpose()?;
    std::fs::create_dir_all(out)?;
    if ["report.json", "epoch-000.nnk", "selected.nnk"].iter().any(|name| out.join(name).exists()) {
        return Err(invalid("output trial artifacts already exist; choose a new trial directory"));
    }
    let started = Instant::now();
    let mut model = warmed.unwrap_or_else(|| FloatModel::new(config.seed));
    let initialization_json = match initialization {
        Some((_, source)) => format!("{{\"mode\":\"warm_start\",\"source\":{},\"quantized_model_bytes\":13016,\"epoch_zero_exact_source_bytes\":true,\"optimizer_state\":\"fresh Adam moments and step counter\",\"optimizer_state_restored\":false}}", json_string(source)),
        None => "{\"mode\":\"fresh_random_input_zero_output\",\"source\":null,\"epoch_zero_exact_source_bytes\":null,\"optimizer_state\":\"fresh Adam moments and step counter\",\"optimizer_state_restored\":false}".to_string(),
    };
    let mut random = Rng::new(config.seed ^ 0x6a09e667f3bcc909);
    let mut adam = Adam::new();
    let mut indices: Vec<usize> = corpus.records.iter().enumerate()
        .filter_map(|(index, row)| (!row.validation && row.active() && row.weight > 0.0).then_some(index)).collect();
    let count = indices.len();
    if count == 0 { return Err(invalid("no active training rows")); }
    let initial = model.quantize()?;
    if let Some((expected, _)) = initialization {
        if initial.to_bytes()? != expected.to_bytes()? {
            return Err(invalid("epoch-zero weights differ from the supplied initial model"));
        }
    }
    initial.save(out.join("epoch-000.nnk"))?;
    initial.save(out.join("selected.nnk"))?;
    let baseline = Metrics::evaluate(corpus, &initial);
    let primary_baseline = baseline.groups[1][0].bce;
    let mut selected_epoch = 0;
    let mut selected_primary = primary_baseline;
    let mut selected_metrics = baseline.clone();
    let mut epochs = vec![format!("{{\"epoch\":0,\"eligible\":false,\"selected\":true,\"elapsed_seconds\":0,\"metrics\":{}}}", baseline.json())];
    write_report(out, corpus, corpus_path, config, &initialization_json, &baseline, &selected_metrics, selected_epoch, &epochs, started.elapsed().as_secs_f64())?;
    let mut gradient = vec![0.0; PARAMETERS];
    for epoch in 1..=config.epochs {
        random.shuffle(&mut indices);
        for batch in indices.chunks(config.batch) {
            gradient.fill(0.0);
            let sampling_scale = count as f64 / batch.len() as f64;
            for &index in batch {
                let record = &corpus.records[index];
                let group = usize::from(record.group);
                let fraction = if group == 3 { config.anchor_strength } else { config.group_mix[group] };
                let coefficient = sampling_scale * fraction * record.weight / corpus.stats[0][group].weight;
                model.gradient(record, coefficient, group == 3, &mut gradient);
            }
            adam.step(&mut model, &mut gradient, config)?;
        }
        let quantized = model.quantize()?;
        quantized.save(out.join(format!("epoch-{epoch:03}.nnk")))?;
        let metrics = Metrics::evaluate(corpus, &quantized);
        let primary = metrics.groups[1][0].bce;
        let anchor = metrics.groups[1][3].active_residual_rms;
        let eligible = primary < primary_baseline - config.minimum_primary_improvement
            && anchor <= config.anchor_rms_limit;
        let selected = eligible && (selected_epoch == 0 || primary < selected_primary);
        if selected {
            selected_epoch = epoch;
            selected_primary = primary;
            selected_metrics = metrics.clone();
            quantized.save(out.join("selected.nnk"))?;
        }
        let elapsed = started.elapsed().as_secs_f64();
        epochs.push(format!("{{\"epoch\":{epoch},\"eligible\":{eligible},\"selected_when_seen\":{selected},\"elapsed_seconds\":{elapsed:.6},\"metrics\":{}}}", metrics.json()));
        write_report(out, corpus, corpus_path, config, &initialization_json, &baseline, &selected_metrics, selected_epoch, &epochs, elapsed)?;
        println!("epoch={epoch} seconds={elapsed:.2} primary_val_bce={primary:.9} active_anchor_val_rms={anchor:.3} rehearsal_val_bce={:.9} handicap_val_bce={:.9} eligible={eligible} selected_epoch={selected_epoch}", metrics.groups[1][1].bce, metrics.groups[1][2].bce);
    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn write_report(out: &Path, corpus: &Corpus, corpus_path: &str, config: &Config, initialization: &str, baseline: &Metrics,
    selected: &Metrics, selected_epoch: usize, epochs: &[String], elapsed: f64) -> io::Result<()> {
    let contents = format!("{{\"format\":\"native-nnue-training-v1\",\"language\":\"Rust\",\"architecture\":\"200x32x1-shared-color-antisymmetric-clipped-ReLU\",\"corpus\":{},\"corpus_stats\":{},\"config\":{},\"initialization\":{},\"baseline_metrics_reference\":\"epoch_000\",\"selection\":{{\"criterion\":\"minimum quantized validation primary BCE, improvement >= configured threshold, validation active-anchor RMS <= configured limit; rehearsal BCE diagnostic only\",\"selected_epoch\":{},\"eligible_checkpoint_found\":{},\"playing_strength_validated\":false}},\"elapsed_seconds\":{:.6},\"baseline_metrics\":{},\"selected_metrics\":{},\"epochs\":[{}]}}\n", json_string(corpus_path), corpus.stats_json(), config.json(), initialization, selected_epoch, selected_epoch != 0, elapsed, baseline.json(), selected.json(), epochs.join(","));
    write_atomic(&out.join("report.json"), contents.as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn record() -> Record {
        let mut features = [0; 40];
        features[..4].copy_from_slice(&[8, 73, 118, 177]);
        Record { features, n: 4, validation: false, group: 0, flags: 1, baseline: 0.2, target: 0.8, weight: 1.0 }
    }

    #[test]
    fn warm_start_preserves_real_champion_bytes_and_integer_predictions() {
        let bytes = include_bytes!("../tests/fixtures/champion9.nnk");
        let champion = Model::from_bytes(bytes).unwrap();
        let warmed = FloatModel::from_quantized(&champion).unwrap().quantize().unwrap();
        assert_eq!(warmed.to_bytes().unwrap(), bytes.as_slice());
        for features in [vec![], vec![6, 73, 140], vec![8, 73, 118, 177], vec![4, 99, 123, 175]] {
            crate::inference::validate_features(&features).unwrap();
            for enabled in [false, true] {
                assert_eq!(warmed.predict(&features, enabled), champion.predict(&features, enabled));
            }
        }
    }

    #[test]
    fn warm_start_accepts_exact_training_bounds_without_clipping() {
        let mut model = Model::zero();
        for input in 0..INPUTS {
            for hidden in 0..HIDDEN {
                model.input[input][hidden] = if (input + hidden) % 2 == 0 { -2048 } else { 2048 };
            }
        }
        for hidden in 0..HIDDEN {
            model.bias[hidden] = if hidden % 2 == 0 { -2048 } else { 2048 };
            model.output[hidden] = if hidden % 2 == 0 { 2048 } else { -2048 };
        }
        let warmed = FloatModel::from_quantized(&model).unwrap();
        assert_eq!(warmed.quantize().unwrap().to_bytes().unwrap(), model.to_bytes().unwrap());
        assert!(warmed.parameters.iter().all(|value| value.abs() == 8.0));
    }

    #[test]
    fn warm_start_rejects_every_out_of_domain_parameter_group() {
        for sign in [-1_i32, 1] {
            let mut input = Model::zero();
            input.input[0][0] = (sign * 2049) as i16;
            let mut bias = Model::zero();
            bias.bias[0] = sign * 2049;
            let mut output = Model::zero();
            output.output[0] = (sign * 2049) as i16;
            for model in [input, bias, output] {
                assert!(model.validate().is_ok(), "valid inference models may be outside the training domain");
                assert!(FloatModel::from_quantized(&model).is_err());
            }
        }
        let mut invalid = Model::zero();
        invalid.bias[0] = i32::MAX;
        assert!(FloatModel::from_quantized(&invalid).is_err());
    }

    #[test]
    fn zero_output_keeps_core_exactly_and_rotation_reverses_scores() {
        let mut model = FloatModel::new(123);
        let mut row = record();
        assert_eq!(model.residual(&row), 0.0);
        assert_eq!(model.quantize().unwrap().predict(row.ids(), true), 0);
        for hidden in 0..HIDDEN { model.parameters[OUTPUT + hidden] = (hidden as f64 - 16.0) / 100.0; }
        let original = model.residual(&row);
        for feature in &mut row.features[..4] { *feature = rotate(*feature); }
        row.features[..4].sort_unstable();
        assert!((original + model.residual(&row)).abs() < 1.0e-12);
    }

    #[test]
    fn analytic_bce_and_anchor_gradient_match_finite_differences() {
        let row = record();
        let mut model = FloatModel::new(73);
        for hidden in 0..HIDDEN {
            model.parameters[BIAS + hidden] = 0.8;
            model.parameters[OUTPUT + hidden] = (hidden as f64 + 1.0) * 0.002;
        }
        // Exercise a shared bias when only one orientation crosses the ReLU.
        model.parameters[BIAS + 3] = 0.01;
        for &id in row.ids() {
            model.parameters[usize::from(id) * HIDDEN + 3] = 0.02;
            model.parameters[usize::from(rotate(id)) * HIDDEN + 3] = -0.02;
        }
        for anchor in [false, true] {
            let mut gradient = vec![0.0; PARAMETERS];
            model.gradient(&row, 0.7, anchor, &mut gradient);
            assert!(gradient[BIAS + 3].abs() > 1.0e-8);
            for index in [8 * HIDDEN, usize::from(rotate(8)) * HIDDEN + 4, BIAS + 3, OUTPUT + 2, OUTPUT + 31] {
                let original = model.parameters[index];
                let epsilon = 1.0e-6;
                let loss = |model: &FloatModel| {
                    let residual = model.residual(&row);
                    0.7 * if anchor { residual * residual } else { bce(row.baseline + residual, row.target) }
                };
                model.parameters[index] = original + epsilon;
                let upper = loss(&model);
                model.parameters[index] = original - epsilon;
                let lower = loss(&model);
                model.parameters[index] = original;
                let numeric = (upper - lower) / (2.0 * epsilon);
                assert!((gradient[index] - numeric).abs() < 1.0e-8, "anchor={anchor} index={index} analytic={} numeric={numeric}", gradient[index]);
            }
        }
    }

    #[test]
    fn native_adam_actually_learns_a_soft_target() {
        let mut row = record();
        row.target = 0.9;
        let mut model = FloatModel::new(99);
        let initial_loss = bce(row.baseline, row.target);
        let mut adam = Adam::new();
        let config = Config { learning_rate: 0.01, ..Config::default() };
        for _ in 0..100 {
            let mut gradient = vec![0.0; PARAMETERS];
            model.gradient(&row, 1.0, false, &mut gradient);
            adam.step(&mut model, &mut gradient, &config).unwrap();
        }
        let quantized = model.quantize().unwrap();
        let residual = f64::from(quantized.predict(row.ids(), true)) / 200.0;
        assert!(bce(row.baseline + residual, row.target) < initial_loss - 0.1);
        assert!(residual > 0.5);
    }

    #[test]
    fn stable_extreme_logits_and_inactive_gate() {
        assert!(bce(1000.0, 1.0).abs() < 1.0e-12);
        assert!(bce(-1000.0, 0.0).abs() < 1.0e-12);
        let mut row = record();
        row.flags = 0;
        let mut model = FloatModel::new(42);
        model.parameters[OUTPUT] = 8.0;
        assert_eq!(model.residual(&row), 0.0);
        let mut gradient = vec![0.0; PARAMETERS];
        model.gradient(&row, 1.0, false, &mut gradient);
        assert!(gradient.iter().all(|value| *value == 0.0));
    }
}
