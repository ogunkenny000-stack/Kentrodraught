use crate::inference::{active, rotate, validate_features, MAX_PIECES};
use crate::invalid;
use std::collections::HashMap;
use std::fs::File;
use std::io::{self, BufReader, Read};
use std::path::Path;

pub const MAGIC: &[u8; 8] = b"NNKCOR01";
pub const GROUP_NAMES: [&str; 4] = ["primary", "rehearsal", "handicap", "anchor"];

#[derive(Clone, Debug)]
pub struct Record {
    pub features: [u8; MAX_PIECES],
    pub n: u8,
    pub validation: bool,
    pub group: u8,
    pub flags: u8,
    pub baseline: f64,
    pub target: f64,
    pub weight: f64,
}

impl Record {
    pub fn ids(&self) -> &[u8] {
        &self.features[..usize::from(self.n)]
    }
    pub fn active(&self) -> bool {
        self.flags & 1 != 0
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct GroupStats {
    pub records: usize,
    pub active_records: usize,
    pub weight: f64,
    pub active_weight: f64,
}

#[derive(Debug)]
pub struct Corpus {
    pub records: Vec<Record>,
    pub stats: [[GroupStats; 4]; 2],
    pub bytes: u64,
    pub unique_boards: usize,
}

#[derive(PartialEq, Eq, Hash)]
struct BoardKey {
    features: [u8; MAX_PIECES],
    n: u8,
}

/// The evaluator ignores side to move and is exactly color/180° antisymmetric.
/// Split isolation must therefore cover both turns and both orientations.
fn canonical_board(features: [u8; MAX_PIECES], n: u8) -> BoardKey {
    let mut flipped = [0_u8; MAX_PIECES];
    for (destination, &id) in flipped.iter_mut().zip(&features[..usize::from(n)]) {
        *destination = rotate(id);
    }
    flipped[..usize::from(n)].sort_unstable();
    BoardKey { features: if flipped < features { flipped } else { features }, n }
}

impl Corpus {
    pub fn load(path: impl AsRef<Path>) -> io::Result<Self> {
        let file = File::open(path)?;
        let bytes = file.metadata()?.len();
        Self::from_reader(BufReader::new(file), bytes)
    }

    pub fn from_reader(mut reader: impl Read, bytes: u64) -> io::Result<Self> {
        let mut header = [0_u8; 16];
        reader.read_exact(&mut header)?;
        if &header[..8] != MAGIC {
            return Err(invalid("wrong corpus magic/version"));
        }
        let count = u64::from_le_bytes(header[8..].try_into().unwrap());
        if count == 0 || count > bytes.saturating_sub(16) / 16 {
            return Err(invalid("empty corpus or impossible record count"));
        }
        let count = usize::try_from(count).map_err(|_| invalid("corpus is too large"))?;
        let mut records = Vec::with_capacity(count);
        let mut boards = HashMap::<BoardKey, bool>::with_capacity(count);
        let mut stats = [[GroupStats::default(); 4]; 2];
        for index in 0..count {
            let mut row = [0_u8; 16];
            reader.read_exact(&mut row).map_err(|error| invalid(format!("record {index}: {error}")))?;
            let n = usize::from(row[0]);
            if n > MAX_PIECES || row[1] > 1 || row[2] > 3 || row[3] & !3 != 0 {
                return Err(invalid(format!("invalid record {index} header")));
            }
            let number = |offset| f32::from_le_bytes(row[offset..offset + 4].try_into().unwrap()) as f64;
            let baseline = number(4);
            let target = number(8);
            let weight = number(12);
            if !baseline.is_finite() || !target.is_finite() || !(0.0..=1.0).contains(&target)
                || !weight.is_finite() || weight < 0.0
            {
                return Err(invalid(format!("non-finite or invalid record {index} numbers")));
            }
            let mut features = [0_u8; MAX_PIECES];
            reader.read_exact(&mut features[..n])?;
            validate_features(&features[..n]).map_err(|error| invalid(format!("record {index}: {error}")))?;
            if (row[3] & 1 != 0) != active(&features[..n]) {
                return Err(invalid(format!("record {index}: active flag disagrees with board geometry")));
            }
            let validation = row[1] == 1;
            let key = canonical_board(features, row[0]);
            if let Some(previous_validation) = boards.insert(key, validation) {
                if previous_validation != validation {
                    return Err(invalid(format!("record {index}: canonical placement/color-rotation orbit leaks across training and validation (turn ignored)")));
                }
            }
            let group_stats = &mut stats[usize::from(validation)][usize::from(row[2])];
            group_stats.records += 1;
            group_stats.weight += weight;
            if row[3] & 1 != 0 {
                group_stats.active_records += 1;
                group_stats.active_weight += weight;
            }
            records.push(Record { features, n: row[0], validation, group: row[2], flags: row[3], baseline, target, weight });
        }
        let mut extra = [0_u8; 1];
        if reader.read(&mut extra)? != 0 {
            return Err(invalid("unexpected bytes after final corpus record"));
        }
        Ok(Self { records, stats, bytes, unique_boards: boards.len() })
    }

    pub fn validate_training(&self) -> io::Result<()> {
        for (split, name) in [(0, "training"), (1, "validation")] {
            if self.stats[split][0].active_weight <= 0.0 {
                return Err(invalid(format!("{name} has no positive-weight active primary records")));
            }
            if self.stats[split][3].active_weight <= 0.0 {
                return Err(invalid(format!("{name} has no positive-weight active anchors")));
            }
            for (group, group_name) in GROUP_NAMES.iter().enumerate().take(3) {
                if self.stats[split][group].weight <= 0.0 {
                    return Err(invalid(format!("{name} group {group_name} has no positive weight")));
                }
            }
        }
        Ok(())
    }

    pub fn stats_json(&self) -> String {
        let splits: Vec<String> = (0..2).map(|split| {
            let groups: Vec<String> = (0..4).map(|group| {
                let value = self.stats[split][group];
                format!("\"{}\":{{\"records\":{},\"active_records\":{},\"weight\":{:.12},\"active_weight\":{:.12}}}", GROUP_NAMES[group], value.records, value.active_records, value.weight, value.active_weight)
            }).collect();
            format!("\"{}\":{{{}}}", if split == 0 { "training" } else { "validation" }, groups.join(","))
        }).collect();
        format!("{{\"records\":{},\"unique_position_orbits\":{},\"bytes\":{},\"splits\":{{{}}}}}", self.records.len(), self.unique_boards, self.bytes, splits.join(","))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture(rows: &[(u8, u8, Vec<u8>)]) -> Vec<u8> {
        let mut data = MAGIC.to_vec();
        data.extend_from_slice(&(rows.len() as u64).to_le_bytes());
        for (validation, turn, ids) in rows {
            data.extend_from_slice(&[ids.len() as u8, *validation, 0, u8::from(active(ids)) | (*turn << 1)]);
            for value in [0.0_f32, 0.6, 1.0] { data.extend_from_slice(&value.to_le_bytes()); }
            data.extend_from_slice(ids);
        }
        data
    }

    #[test]
    fn rejects_exact_opposite_turn_and_color_rotation_leaks() {
        let bytes = fixture(&[(0, 0, vec![10, 80]), (1, 0, vec![10, 80])]);
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
        let bytes = fixture(&[(0, 0, vec![10, 80]), (1, 1, vec![10, 80])]);
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
        let bytes = fixture(&[(0, 0, vec![10, 80]), (1, 1, vec![19, 89])]);
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
        let bytes = fixture(&[(0, 0, vec![10, 80]), (1, 1, vec![19, 88])]);
        assert_eq!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).unwrap().unique_boards, 2);
    }

    #[test]
    fn rejects_overlap_wrong_gate_and_trailing_bytes() {
        let bytes = fixture(&[(0, 0, vec![10, 60])]);
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
        let mut bytes = fixture(&[(0, 0, vec![10, 80])]);
        bytes[19] ^= 1;
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
        let mut bytes = fixture(&[(0, 0, vec![10, 80])]);
        bytes.push(0);
        assert!(Corpus::from_reader(bytes.as_slice(), bytes.len() as u64).is_err());
    }
}
