use native_king_nnue::data::Corpus;
use native_king_nnue::inference::Model;
use native_king_nnue::train::{self, Config, Metrics};
use native_king_nnue::{invalid, json_string, write_atomic};
use std::io::{self, BufWriter, Write};
use std::path::Path;

fn usage() -> &'static str {
    "native-nnue zero MODEL.nnk\n\
     native-nnue check CORPUS.bin [REPORT.json]\n\
     native-nnue train CORPUS.bin OUTPUT_DIR [--init-model MODEL.nnk] [--epochs N] [--seed N] [--batch N] [--lr X] [--anchor X] [--l2 X] [--anchor-rms X] [--min-improvement X] [--gradient-clip X]\n\
     native-nnue report MODEL.nnk CORPUS.bin OUTPUT.json\n\
     native-nnue predict MODEL.nnk CORPUS.bin OUTPUT.bin\n\
     predict output: NNKPRD01 magic, u64 LE record count, then i16 LE White residuals in corpus order"
}

fn parse<T: std::str::FromStr>(value: &str, name: &str) -> io::Result<T> {
    value.parse().map_err(|_| invalid(format!("invalid {name}: {value}")))
}

fn run() -> io::Result<()> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let command = args.first().map(String::as_str).unwrap_or("help");
    match command {
        "help" | "--help" | "-h" => println!("{}", usage()),
        "zero" if args.len() == 2 => {
            Model::zero().save(&args[1])?;
            println!("wrote exact-zero 13016-byte quantized model: {}", args[1]);
        }
        "check" if args.len() == 2 || args.len() == 3 => {
            let corpus = Corpus::load(&args[1])?;
            let metrics = Metrics::evaluate(&corpus, &Model::zero());
            let training_ready = corpus.validate_training().is_ok();
            let report = format!("{{\"format\":\"native-nnue-corpus-check-v1\",\"corpus\":{},\"training_ready\":{},\"stats\":{},\"baseline_metrics\":{}}}\n", json_string(&args[1]), training_ready, corpus.stats_json(), metrics.json());
            if args.len() == 3 { write_atomic(Path::new(&args[2]), report.as_bytes())?; }
            print!("{report}");
        }
        "train" if args.len() >= 3 => {
            let mut config = Config::default();
            let mut initial_model = None;
            let mut offset = 3;
            while offset < args.len() {
                let option = &args[offset];
                let value = args.get(offset + 1).ok_or_else(|| invalid(format!("missing value for {option}")))?;
                match option.as_str() {
                    "--init-model" => {
                        if initial_model.is_some() {
                            return Err(invalid("--init-model may be supplied only once"));
                        }
                        initial_model = Some(value.as_str());
                    }
                    "--epochs" => config.epochs = parse(value, "epochs")?,
                    "--seed" => config.seed = parse(value, "seed")?,
                    "--batch" => config.batch = parse(value, "batch")?,
                    "--lr" => config.learning_rate = parse(value, "learning rate")?,
                    "--anchor" => config.anchor_strength = parse(value, "anchor strength")?,
                    "--l2" => config.l2 = parse(value, "L2 strength")?,
                    "--anchor-rms" => config.anchor_rms_limit = parse(value, "anchor RMS limit")?,
                    "--min-improvement" => config.minimum_primary_improvement = parse(value, "minimum improvement")?,
                    "--gradient-clip" => config.gradient_clip = parse(value, "gradient clip")?,
                    _ => return Err(invalid(format!("unknown training option: {option}"))),
                }
                offset += 2;
            }
            config.validate()?;
            let corpus = Corpus::load(&args[1])?;
            if let Some(source) = initial_model {
                let model = Model::load(source)?;
                train::train_from_model(&corpus, &args[1], Path::new(&args[2]), &config, &model, source)?;
            } else {
                train::train(&corpus, &args[1], Path::new(&args[2]), &config)?;
            }
        }
        "report" if args.len() == 4 => {
            let model = Model::load(&args[1])?;
            let corpus = Corpus::load(&args[2])?;
            let metrics = Metrics::evaluate(&corpus, &model);
            let report = format!("{{\"format\":\"native-nnue-model-report-v1\",\"model\":{},\"corpus\":{},\"stats\":{},\"metrics\":{}}}\n", json_string(&args[1]), json_string(&args[2]), corpus.stats_json(), metrics.json());
            write_atomic(Path::new(&args[3]), report.as_bytes())?;
            print!("{report}");
        }
        "predict" if args.len() == 4 => {
            let model = Model::load(&args[1])?;
            let corpus = Corpus::load(&args[2])?;
            let destination = Path::new(&args[3]);
            let temporary = destination.with_extension(format!("tmp-{}", std::process::id()));
            let mut writer = BufWriter::new(std::fs::File::create(&temporary)?);
            writer.write_all(b"NNKPRD01")?;
            writer.write_all(&(corpus.records.len() as u64).to_le_bytes())?;
            for record in &corpus.records {
                let residual = model.predict(record.ids(), record.active()) as i16;
                writer.write_all(&residual.to_le_bytes())?;
            }
            writer.flush()?;
            writer.get_ref().sync_all()?;
            drop(writer);
            std::fs::rename(temporary, destination)?;
            println!("wrote {} quantized White residuals to {}", corpus.records.len(), destination.display());
        }
        _ => return Err(invalid(usage())),
    }
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("native-nnue: {error}");
        std::process::exit(1);
    }
}
