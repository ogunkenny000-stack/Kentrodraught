"""Fixed native-prediction outcome audit. No optimizer or engine search here."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct

import numpy as np


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def bce(scores, targets, weights):
    scores, targets, weights = [np.asarray(x, dtype=np.float64) for x in
                                (scores, targets, weights)]
    if scores.shape != targets.shape or targets.shape != weights.shape:
        raise ValueError('BCE vectors differ in shape')
    if not (np.all(np.isfinite(scores)) and np.all(np.isfinite(targets))
            and np.all(np.isfinite(weights)) and np.all(weights >= 0)
            and np.all((targets >= 0) & (targets <= 1)) and weights.sum() > 0):
        raise ValueError('Invalid BCE vectors or no genuine outcome mass')
    z = scores / 200.
    return float(np.dot(weights / weights.sum(), np.logaddexp(0, z) - targets * z))


def predictions(path, count):
    path = Path(path)
    with path.open('rb') as stream:
        header = stream.read(16)
    if (len(header) != 16 or header[:8] != b'NNKPRD01'
            or struct.unpack('<Q', header[8:])[0] != count
            or path.stat().st_size != 16 + count * 2):
        raise ValueError('Native prediction header, count or length differs')
    return np.memmap(path, mode='r', dtype='<i2', offset=16, shape=(count,))


def audit(manifest_path, sidecar, candidate_predictions, initial_predictions):
    manifest = json.loads(Path(manifest_path).read_text())
    if (manifest.get('state') != 'completed'
            or not manifest.get('leakage_check', {}).get('passed')
            or not manifest.get('placement_orbit_isolation', {}).get('passed')):
        raise ValueError('A completed orbit-isolated corpus is required')
    if sha(sidecar) != manifest['true_outcomes']['sha256']:
        raise ValueError('True-outcome sidecar changed')
    before = predictions(initial_predictions, manifest['records'])
    after = predictions(candidate_predictions, manifest['records'])
    with np.load(sidecar, allow_pickle=False) as stored:
        data = {name: stored[name] for name in stored.files}
    block = manifest['blocks']['V']
    ids = block['record_start'] + np.arange(block['records'], dtype=np.uint64)
    if not np.array_equal(data['corpus_record_index'], ids):
        raise ValueError('Outcome rows differ from the primary validation block')
    baseline = data['baseline_logit'].astype(np.float64) * 200.
    candidate = np.clip(baseline + after[ids], -8000, 8000)
    initial = np.clip(baseline + before[ids], -8000, 8000)
    core_bce = bce(baseline, data['mc'], data['mc_weight'])
    initial_bce = bce(initial, data['mc'], data['mc_weight'])
    candidate_bce = bce(candidate, data['mc'], data['mc_weight'])
    return dict(eligible=candidate_bce < initial_bce and candidate_bce < core_bce,
                core_baseline_bce=core_bce, initial_bce=initial_bce,
                candidate_bce=candidate_bce, improvement=initial_bce - candidate_bce,
                primary_mc_records=int(np.count_nonzero(data['mc_weight'])),
                cutoff_records_excluded=int(np.count_nonzero(data['mc_weight'] == 0)),
                censored_mass_excluded=float(np.sum(data['unknown_weight'])),
                unknown_outcome_policy='zero MC mass; never relabeled as a terminal draw')
