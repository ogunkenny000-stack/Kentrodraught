//! SCAN's Nigerian pattern evaluator, including the original big-endian weights.
use crate::board::{Position, SPARSE, SQUARES, bits, dense, king_quiets};
// 8 KiB of exact byte-subset features fits in cache. The low half stores tempo;
// the signed high half stores left/right skew. Tempo never carries into skew.
const MAN_FEATURES: [[u32; 256]; 8] = {
    let mut tables = [[0u32; 256]; 8];
    let mut chunk = 0;
    while chunk < 8 {
        let mut subset = 0;
        while subset < 256 {
            let mut score = 0u32;
            let mut i = 0;
            while i < 50 {
                let q = SPARSE[i] as usize;
                if q / 8 == chunk && subset & (1 << (q % 8)) != 0 {
                    let rank = i / 5;
                    let file = (i % 5) * 2 + 1 - rank % 2;
                    score = score
                        .wrapping_add(rank as u32 | (((file as i16 * 2 - 9) as u16 as u32) << 16));
                }
                i += 1;
            }
            tables[chunk][subset] = score;
            subset += 1;
        }
        chunk += 1;
    }
    tables
};
#[inline]
fn man_features(b: u64) -> (i32, i32) {
    let mut score = 0u32;
    for (chunk, table) in MAN_FEATURES.iter().enumerate() {
        score = score.wrapping_add(table[((b >> (chunk * 8)) & 255) as usize]);
    }
    ((score & 65535) as i32, (score >> 16) as i16 as i32)
}
pub struct Evaluator {
    weights: Vec<i32>,
    trits: [[i32; 4096]; 2],
    neural: Option<crate::nnue_eval::NeuralEvaluator>,
}
impl Default for Evaluator {
    fn default() -> Self {
        Self::new()
    }
}
impl Evaluator {
    pub fn new() -> Self {
        let bytes = include_bytes!("../data/eval_nigerian");
        assert_eq!(bytes.len(), 2_125_820 * 4);
        let weights = bytes
            .as_chunks::<2>()
            .0
            .iter()
            .map(|b| i16::from_be_bytes([b[0], b[1]]) as i32)
            .collect();
        let mut trits = [[0; 4096]; 2];
        for (t, perm) in [
            [11, 10, 7, 6, 3, 2, 9, 8, 5, 4, 1, 0],
            [0, 1, 4, 5, 8, 9, 2, 3, 6, 7, 10, 11],
        ]
        .iter()
        .enumerate()
        {
            for (i, value) in trits[t].iter_mut().enumerate() {
                for (j, &power) in perm.iter().enumerate() {
                    *value += ((i >> j) & 1) as i32 * 3i32.pow(power);
                }
            }
        }
        Self { weights, trits, neural: crate::nnue_eval::NeuralEvaluator::embedded() }
    }
    pub fn with_nnue_model(model: crate::nnue_model::Model) -> Self {
        let mut evaluator = Self::new();
        evaluator.neural = crate::nnue_eval::NeuralEvaluator::new(model);
        evaluator
    }
    pub fn neural_correction(&self, p: Position) -> i32 {
        self.neural.as_ref().map_or(0, |neural| neural.evaluate(p))
    }
    pub fn evaluate(&self, p: Position) -> i32 {
        let nwm = p.men[0].count_ones() as i32;
        let nbm = p.men[1].count_ones() as i32;
        let nwk = p.kings[0].count_ones() as i32;
        let nbk = p.kings[1].count_ones() as i32;
        let mut mg = 0;
        let mut eg = 0;
        let mut add = |v: usize, val: i32| {
            mg += self.weights[v * 2] * val;
            eg += self.weights[v * 2 + 1] * val;
        };
        add(0, nwm - nbm);
        add(1, i32::from(nwk >= 1) - i32::from(nbk >= 1));
        add(2, (nwk - 1).max(0) - (nbk - 1).max(0));
        for q in bits(p.kings[0]) {
            add(3 + dense(q), 1);
        }
        for q in bits(p.kings[1]) {
            add(3 + dense(62 - q), -1);
        }
        let mut ns = 0;
        let mut nd = 0;
        let empty = p.empty();
        for side in 0..2 {
            let ba = p.men[side ^ 1];
            let attacked = SQUARES
                & (((ba >> 7) & (empty << 7))
                    | ((ba >> 6) & (empty << 6))
                    | ((ba << 6) & (empty >> 6))
                    | ((ba << 7) & (empty >> 7)));
            let sign = if side == 0 { 1 } else { -1 };
            for from in bits(p.kings[side]) {
                let destinations = king_quiets(from, empty);
                ns += sign * (destinations & !attacked).count_ones() as i32;
                nd += sign * (destinations & attacked).count_ones() as i32;
            }
        }
        add(53, ns);
        add(54, nd);
        let (white_tempo, white_skew) = man_features(p.men[0]);
        let (black_tempo, black_skew) = man_features(p.men[1]);
        add(55, white_skew.abs() - black_skew.abs());
        for col in 0..4 {
            let index = |b: u64| {
                let l = (b >> col) & 0x0C3061830C1860C3;
                let shuffle = l | (l >> 11) | (l >> 22);
                ((shuffle & 4095) as usize, ((shuffle >> 26) & 4095) as usize)
            };
            let (w0, w2) = index(p.men[0]);
            let (b0, b2) = index(p.men[1]);
            let top = self.trits[0][b0] - self.trits[0][w0];
            let bottom = self.trits[1][b2] - self.trits[1][w2];
            add((56 + 265720 + 531441 * col + top) as usize, 1);
            add((56 + 1860043 - 531441 * col - bottom) as usize, -1);
        }
        let tempo = white_tempo + 9 * nbm - black_tempo;
        let stage = 300 - tempo;
        // C++ ml::div_round: floor(a/b + 0.5), including negative scores.
        let score = (mg as i64 * (300 - stage) as i64 + eg as i64 * stage as i64 + 1500)
            .div_euclid(3000) as i32;
        let score = score + self.neural_correction(p);
        (if p.turn == 0 { score } else { -score }).clamp(-8000, 8000)
    }
    pub fn pst(&self, p: Position) -> i32 {
        const PST: [i32; 50] = [
            0, 0, 0, 0, 0, 18, 87, 78, 74, 102, 43, 21, 22, 30, 4, -4, 8, -3, 0, 0, -13, -13, -7,
            -13, -8, -11, -16, -9, -13, -21, -20, -15, -10, -18, -17, -20, -18, -13, -14, -17, -23,
            -16, -14, -17, -19, -23, -15, -12, -15, -17,
        ];
        let side = |s: usize| {
            p.men[s].count_ones() as i32 * 100
                + p.kings[s].count_ones() as i32 * 300
                + bits(p.men[s])
                    .map(|q| PST[if s == 0 { dense(q) } else { 49 - dense(q) }])
                    .sum::<i32>()
        };
        side(p.turn) - side(p.turn ^ 1)
    }
}
