//! Exact integer inference for the shared, color-antisymmetric NNUE residual.
//!
//! This module does not alter the core evaluator or game rules. Feature IDs are
//! white men 0..50, black men 50..100, white kings 100..150 and black kings
//! 150..200, with zero-based dense squares. Weights must remain immutable while
//! a cache is in use; call `Cache::clear` after modifying a model in place.
use std::fs::{self, File};
use std::io::{self, Write};
use std::path::Path;

pub const INPUTS: usize = 200;
pub const HIDDEN: usize = 32;
pub const Q: i32 = 256;
pub const MAX_PIECES: usize = 40;
pub const MODEL_BYTES: usize = 24 + INPUTS * HIDDEN * 2 + HIDDEN * 4 + HIDDEN * 2;
const MAGIC: &[u8; 8] = b"NNKMOD01";
const MAX_BIAS: i64 = 1_i64 << 30;
const ACTIVATION_MAX: i32 = 8 * Q;
const DENOMINATOR: i64 = Q as i64 * Q as i64;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Model {
    pub input: [[i16; HIDDEN]; INPUTS],
    pub bias: [i32; HIDDEN],
    pub output: [i16; HIDDEN],
}

fn invalid(message: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}

/// Rotate the square by 180 degrees and exchange piece colors.
#[inline]
pub fn rotate(id: u8) -> u8 {
    let kind = id / 50;
    (kind ^ 1) * 50 + (49 - id % 50)
}

/// The residual is inactive on ordinary men-only positions.
#[inline]
pub fn active(features: &[u8]) -> bool {
    features.iter().any(|&id| {
        let kind = id / 50;
        let rank = (id % 50) / 5;
        kind >= 2 || (kind == 0 && rank <= 2) || (kind == 1 && rank >= 7)
    })
}

/// Validate externally supplied feature lists once, before inference.
pub fn validate_features(features: &[u8]) -> io::Result<()> {
    if features.len() > MAX_PIECES {
        return Err(invalid("more than forty piece-square features"));
    }
    let mut squares = 0_u64;
    let mut previous = None;
    for &id in features {
        if usize::from(id) >= INPUTS {
            return Err(invalid("piece-square feature is out of range"));
        }
        if previous.is_some_and(|p| p >= id) {
            return Err(invalid("piece-square features must be sorted and unique"));
        }
        let square = 1_u64 << (id % 50);
        if squares & square != 0 {
            return Err(invalid("two pieces occupy the same square"));
        }
        squares |= square;
        previous = Some(id);
    }
    Ok(())
}

fn accumulators(model: &Model, features: &[u8]) -> ([i32; HIDDEN], [i32; HIDDEN]) {
    let mut white = model.bias;
    let mut black = model.bias;
    for &id in features {
        add_feature(model, id, 1, &mut white, &mut black);
    }
    (white, black)
}

#[inline]
// Fixed-width matching indices keep both accumulator updates in one kernel.
#[allow(clippy::needless_range_loop)]
fn add_feature(
    model: &Model,
    id: u8,
    sign: i32,
    white: &mut [i32; HIDDEN],
    black: &mut [i32; HIDDEN],
) {
    let w = &model.input[usize::from(id)];
    let b = &model.input[usize::from(rotate(id))];
    for index in 0..HIDDEN {
        white[index] += i32::from(w[index]) * sign;
        black[index] += i32::from(b[index]) * sign;
    }
}

#[allow(clippy::needless_range_loop)]
fn prediction(model: &Model, white: &[i32; HIDDEN], black: &[i32; HIDDEN]) -> i32 {
    let mut numerator = 0_i64;
    for index in 0..HIDDEN {
        let w = white[index].clamp(0, ACTIVATION_MAX);
        let b = black[index].clamp(0, ACTIVATION_MAX);
        numerator += i64::from(w - b) * i64::from(model.output[index]);
    }
    // Shared-network subtraction supplies the /2, so 200 internal units per
    // logit becomes 100 here. Symmetric rounding preserves antisymmetry even at
    // ties, unlike floor(x+0.5) for negative x.
    let scaled = numerator * 100;
    let rounded = if scaled >= 0 {
        (scaled + DENOMINATOR / 2) / DENOMINATOR
    } else {
        -((-scaled + DENOMINATOR / 2) / DENOMINATOR)
    };
    rounded.clamp(-500, 500) as i32
}

impl Model {
    pub fn zero() -> Self {
        Self {
            input: [[0; HIDDEN]; INPUTS],
            bias: [0; HIDDEN],
            output: [0; HIDDEN],
        }
    }

    pub fn validate(&self) -> io::Result<()> {
        // Even during an incremental remove/add sequence this leaves much more
        // than forty i16 vectors of headroom in every signed accumulator.
        if self.bias.iter().any(|&value| i64::from(value).abs() > MAX_BIAS) {
            return Err(invalid("hidden bias exceeds safe integer-accumulator range"));
        }
        Ok(())
    }

    pub fn validate_features(features: &[u8]) -> io::Result<()> {
        validate_features(features)
    }

    /// Score a validated feature list in internal engine units, from White.
    pub fn predict(&self, features: &[u8], enabled: bool) -> i32 {
        if !enabled {
            return 0;
        }
        debug_assert!(validate_features(features).is_ok());
        let (white, black) = accumulators(self, features);
        prediction(self, &white, &black)
    }

    pub fn from_bytes(bytes: &[u8]) -> io::Result<Self> {
        if bytes.len() != MODEL_BYTES || &bytes[..8] != MAGIC {
            return Err(invalid("NNUE model has the wrong version or byte length"));
        }
        let read_u32 = |offset: usize| {
            u32::from_le_bytes(bytes[offset..offset + 4].try_into().unwrap())
        };
        if read_u32(8) != INPUTS as u32
            || read_u32(12) != HIDDEN as u32
            || read_u32(16) != Q as u32
            || read_u32(20) != 0
        {
            return Err(invalid("unsupported NNUE dimensions, scale or flags"));
        }
        let mut model = Self::zero();
        let mut cursor = 24;
        for row in &mut model.input {
            for value in row {
                *value = i16::from_le_bytes(bytes[cursor..cursor + 2].try_into().unwrap());
                cursor += 2;
            }
        }
        for value in &mut model.bias {
            *value = i32::from_le_bytes(bytes[cursor..cursor + 4].try_into().unwrap());
            cursor += 4;
        }
        for value in &mut model.output {
            *value = i16::from_le_bytes(bytes[cursor..cursor + 2].try_into().unwrap());
            cursor += 2;
        }
        debug_assert_eq!(cursor, MODEL_BYTES);
        model.validate()?;
        Ok(model)
    }

    pub fn to_bytes(&self) -> io::Result<Vec<u8>> {
        self.validate()?;
        let mut bytes = Vec::with_capacity(MODEL_BYTES);
        bytes.extend_from_slice(MAGIC);
        for value in [INPUTS as u32, HIDDEN as u32, Q as u32, 0] {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
        for row in &self.input {
            for value in row {
                bytes.extend_from_slice(&value.to_le_bytes());
            }
        }
        for value in self.bias {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
        for value in self.output {
            bytes.extend_from_slice(&value.to_le_bytes());
        }
        debug_assert_eq!(bytes.len(), MODEL_BYTES);
        Ok(bytes)
    }

    pub fn load(path: impl AsRef<Path>) -> io::Result<Self> {
        let path = path.as_ref();
        if fs::metadata(path)?.len() != MODEL_BYTES as u64 {
            return Err(invalid("NNUE model byte length is not13016"));
        }
        Self::from_bytes(&fs::read(path)?)
    }

    pub fn save(&self, path: impl AsRef<Path>) -> io::Result<()> {
        let path = path.as_ref();
        let bytes = self.to_bytes()?;
        let temporary = path.with_extension(format!("tmp-{}", std::process::id()));
        let mut file = File::create(&temporary)?;
        file.write_all(&bytes)?;
        file.sync_all()?;
        fs::rename(temporary, path)
    }
}

#[derive(Debug)]
pub struct Cache {
    last: Vec<u8>,
    white: [i32; HIDDEN],
    black: [i32; HIDDEN],
    model_address: usize,
    initialized: bool,
}

impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}

impl Cache {
    pub fn new() -> Self {
        Self {
            last: Vec::with_capacity(MAX_PIECES),
            white: [0; HIDDEN],
            black: [0; HIDDEN],
            model_address: 0,
            initialized: false,
        }
    }

    /// Required when replacing the weights of the same model object in place.
    pub fn clear(&mut self) {
        self.last.clear();
        self.initialized = false;
        self.model_address = 0;
    }

    pub fn predict(&mut self, model: &Model, features: &[u8], enabled: bool) -> i32 {
        if !enabled {
            return 0;
        }
        debug_assert!(validate_features(features).is_ok());
        let address = model as *const Model as usize;
        let changes = if self.initialized && self.model_address == address {
            difference_count(&self.last, features)
        } else {
            usize::MAX
        };
        if changes > 8 {
            (self.white, self.black) = accumulators(model, features);
        } else {
            let mut old = 0;
            let mut new = 0;
            while old < self.last.len() || new < features.len() {
                if old < self.last.len()
                    && (new == features.len() || self.last[old] < features[new])
                {
                    add_feature(model, self.last[old], -1, &mut self.white, &mut self.black);
                    old += 1;
                } else if new < features.len()
                    && (old == self.last.len() || features[new] < self.last[old])
                {
                    add_feature(model, features[new], 1, &mut self.white, &mut self.black);
                    new += 1;
                } else {
                    old += 1;
                    new += 1;
                }
            }
        }
        self.last.clear();
        self.last.extend_from_slice(features);
        self.model_address = address;
        self.initialized = true;
        prediction(model, &self.white, &self.black)
    }
}

fn difference_count(a: &[u8], b: &[u8]) -> usize {
    let mut first = 0;
    let mut second = 0;
    let mut count = 0;
    while first < a.len() || second < b.len() {
        if first < a.len() && (second == b.len() || a[first] < b[second]) {
            first += 1;
            count += 1;
        } else if second < b.len() && (first == a.len() || b[second] < a[first]) {
            second += 1;
            count += 1;
        } else {
            first += 1;
            second += 1;
        }
    }
    count
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_model() -> Model {
        let mut model = Model::zero();
        for (piece, row) in model.input.iter_mut().enumerate() {
            for (hidden, value) in row.iter_mut().enumerate() {
                *value = ((piece * 37 + hidden * 17) % 291) as i16 - 145;
            }
        }
        for (hidden, value) in model.bias.iter_mut().enumerate() {
            *value = hidden as i32 * 11 - 100;
            model.output[hidden] = (hidden as i16 * 7) - 100;
        }
        model
    }

    fn rotate_position(features: &[u8]) -> Vec<u8> {
        let mut rotated: Vec<_> = features.iter().map(|&id| rotate(id)).collect();
        rotated.sort_unstable();
        rotated
    }

    #[test]
    fn zero_output_preserves_the_core_exactly() {
        let mut model = sample_model();
        model.output = [0; HIDDEN];
        for features in [vec![], vec![18, 74, 109], vec![1, 61, 122, 199]] {
            validate_features(&features).unwrap();
            assert_eq!(model.predict(&features, true), 0);
            assert_eq!(Cache::new().predict(&model, &features, true), 0);
        }
    }

    #[test]
    fn shared_color_rotation_is_exactly_antisymmetric() {
        let model = sample_model();
        for first in 0_u8..200 {
            for second in (first + 1)..200 {
                if first % 50 == second % 50 {
                    continue;
                }
                let features = [first, second];
                let rotated = rotate_position(&features);
                assert_eq!(model.predict(&features, true), -model.predict(&rotated, true));
                assert_eq!(active(&features), active(&rotated));
            }
        }
    }

    #[test]
    fn integer_cache_matches_full_after_capture_promotion_and_removal() {
        let model = sample_model();
        let mut cache = Cache::new();
        let positions = [
            vec![6, 17, 31, 63, 79, 144, 198],
            vec![6, 17, 31, 63, 79, 143, 198], // quiet king move
            vec![6, 17, 31, 79, 130, 198],     // captured black man
            vec![17, 31, 79, 100, 130, 198],   // promotion
            vec![17, 31, 79, 100, 130],        // king removed
            vec![],                           // full recomputation
            (30..50).chain(50..70).collect(),   // unrelated forty-piece board
            vec![12, 37, 53, 76, 144],
        ];
        for features in positions {
            validate_features(&features).unwrap();
            assert_eq!(cache.predict(&model, &features, true), model.predict(&features, true));
        }
    }

    #[test]
    fn cache_handles_inactive_gaps_and_model_replacement() {
        let model = sample_model();
        let mut other = sample_model();
        other.output[0] += 100;
        let features = [6, 73, 140];
        let mut cache = Cache::new();
        assert_eq!(cache.predict(&model, &features, true), model.predict(&features, true));
        assert_eq!(cache.predict(&model, &[35, 58], false), 0);
        assert_eq!(cache.predict(&other, &features, true), other.predict(&features, true));
        other.input[6][0] += 100;
        cache.clear();
        assert_eq!(cache.predict(&other, &features, true), other.predict(&features, true));
    }

    #[test]
    fn model_format_is_exact_and_rejects_corruption() {
        let model = sample_model();
        let bytes = model.to_bytes().unwrap();
        assert_eq!(bytes.len(), 13_016);
        assert_eq!(Model::from_bytes(&bytes).unwrap(), model);
        let mut bad = bytes.clone();
        bad[8] = 199;
        assert!(Model::from_bytes(&bad).is_err());
        let mut flags = bytes.clone();
        flags[20] = 1;
        assert!(Model::from_bytes(&flags).is_err());
        assert!(Model::from_bytes(&bytes[..bytes.len() - 1]).is_err());
        let mut extra = bytes.clone();
        extra.push(0);
        assert!(Model::from_bytes(&extra).is_err());
        let mut bad_bias = model;
        bad_bias.bias[0] = i32::MAX;
        assert!(bad_bias.to_bytes().is_err());
    }

    #[test]
    fn features_and_activation_are_validated() {
        assert!(validate_features(&[1, 1]).is_err());
        assert!(validate_features(&[2, 1]).is_err());
        assert!(validate_features(&[1, 51]).is_err());
        assert!(validate_features(&[200]).is_err());
        assert!(!active(&[35, 58]));
        assert!(active(&[6, 58]));
        assert!(active(&[35, 93]));
        assert!(active(&[35, 108]));
    }

    #[test]
    fn extreme_quantized_values_do_not_overflow() {
        let mut model = Model::zero();
        model.input = [[i16::MAX; HIDDEN]; INPUTS];
        model.bias = [MAX_BIAS as i32; HIDDEN];
        model.output = [i16::MIN; HIDDEN];
        model.validate().unwrap();
        let features: Vec<_> = (0..40).collect();
        validate_features(&features).unwrap();
        assert_eq!(model.predict(&features, true), 0);
        for index in 0..HIDDEN {
            model.input[0][index] = i16::MIN;
        }
        let value = model.predict(&features, true);
        assert!((-500..=500).contains(&value));
        assert_eq!(Cache::new().predict(&model, &features, true), value);
        let mut signed = Model::zero();
        signed.input[0] = [i16::MAX; HIDDEN];
        signed.input[usize::from(rotate(0))] = [i16::MIN; HIDDEN];
        signed.output = [i16::MAX; HIDDEN];
        assert_eq!(signed.predict(&[0], true), 500);
        assert_eq!(signed.predict(&[rotate(0)], true), -500);
    }
}
