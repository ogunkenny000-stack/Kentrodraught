//! Geometric gating and exact incremental NNUE evaluation on engine boards.
use crate::board::{Position, SPARSE, bits, dense};
use crate::nnue_model::{Cache, Model};
use std::cell::RefCell;

const WHITE_NEAR: u64 = promotion_mask(0);
const BLACK_NEAR: u64 = promotion_mask(1);
const fn promotion_mask(side: usize) -> u64 {
    let mut mask = 0;
    let mut square = 0;
    while square < 50 {
        if (side == 0 && square / 5 <= 2) || (side == 1 && square / 5 >= 7) {
            mask |= 1_u64 << SPARSE[square];
        }
        square += 1;
    }
    mask
}

#[inline]
pub fn active(position: Position) -> bool {
    position.kings[0] | position.kings[1] != 0
        || position.men[0] & WHITE_NEAR != 0
        || position.men[1] & BLACK_NEAR != 0
}

pub struct Features {
    ids: [u8; 40],
    count: usize,
}
impl Features {
    pub fn of(position: Position) -> Self {
        let mut features = Self { ids: [0; 40], count: 0 };
        for (kind, board) in [position.men[0], position.men[1], position.kings[0], position.kings[1]]
            .into_iter().enumerate()
        {
            for square in bits(board) {
                features.ids[features.count] = (kind * 50 + dense(square)) as u8;
                features.count += 1;
            }
        }
        features
    }
    pub fn as_slice(&self) -> &[u8] {
        &self.ids[..self.count]
    }
}

pub struct NeuralEvaluator {
    model: Model,
    // Each Search owns its Evaluator. The cache is local to that evaluator,
    // and diffing complete feature lists remains correct across sibling nodes.
    cache: RefCell<Cache>,
}
impl NeuralEvaluator {
    pub fn new(model: Model) -> Option<Self> {
        model.validate().expect("validated embedded NNUE model");
        model.output.iter().any(|&weight| weight != 0).then(|| Self {
            model,
            cache: RefCell::new(Cache::new()),
        })
    }
    pub fn embedded() -> Option<Self> {
        Self::new(Model::from_bytes(include_bytes!("../data/eval_nnue.nnk"))
            .expect("embedded NNUE format"))
    }
    #[inline]
    pub fn evaluate(&self, position: Position) -> i32 {
        if !active(position) {
            return 0;
        }
        let features = Features::of(position);
        self.cache.borrow_mut().predict(&self.model, features.as_slice(), true)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn model() -> Model {
        let mut model = Model::zero();
        for (piece, row) in model.input.iter_mut().enumerate() {
            for (hidden, value) in row.iter_mut().enumerate() {
                *value = ((piece * 37 + hidden * 17) % 291) as i16 - 145;
            }
        }
        for hidden in 0..32 {
            model.bias[hidden] = hidden as i32 * 11 - 100;
            model.output[hidden] = hidden as i16 * 7 - 100;
        }
        model
    }

    #[test]
    fn board_features_match_trainer_order_and_activation() {
        for text in ["W:W31,44:B7,19", "B:WK32,40:B11,K28", "W:W12:B45"] {
            let p = Position::parse(text).unwrap();
            let features = Features::of(p);
            crate::nnue_model::validate_features(features.as_slice()).unwrap();
            assert_eq!(active(p), crate::nnue_model::active(features.as_slice()));
        }
        let p = Position::parse("B:W12,K32:B45,K28").unwrap();
        assert_eq!(Features::of(p).as_slice(), &[11, 94, 131, 177]);
    }

    #[test]
    fn cached_engine_correction_equals_direct_integer_model_across_siblings() {
        let model = model();
        let neural = NeuralEvaluator::new(model.clone()).unwrap();
        for text in ["W:WK32,40:B11,K28", "B:W12:B45", "W:W31,44:B7,19",
                     "W:WK14:B18,K35", "B:WK32,40:B11,K28"] {
            let p = Position::parse(text).unwrap();
            assert_eq!(neural.evaluate(p), model.predict(Features::of(p).as_slice(), active(p)));
        }
    }

    #[test]
    fn correction_is_white_relative_and_zero_model_is_disabled() {
        let p = Position::parse("W:WK32,40:B11,K28").unwrap();
        let mut black = p;
        black.turn = 1;
        let neural = NeuralEvaluator::new(model()).unwrap();
        assert_eq!(neural.evaluate(p), neural.evaluate(black));
        assert!(NeuralEvaluator::new(Model::zero()).is_none());
    }
}
