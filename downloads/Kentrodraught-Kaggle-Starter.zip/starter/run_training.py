"""Portable Kaggle launcher: native Rust fits weights; Python schedules/audits.

The supplied corpus/model pair was already fitted in local round 13. Default
notebook work is preflight; fitting that pair is explicitly a reproduction.
Optimizer state is never restored and offline checks never claim match strength.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import queue
import shutil
import signal
import subprocess
import sys
import threading
import time

from portable_audit import audit, sha

TRIALS = [(173, .02), (997, .02), (173, .1), (997, .1)]
TRANSFERRED_CORPUS_SHA = '77f695ef0337ba3219b56663f2bbe68d0ff6cdc360871b23ebe4f783c83f9b9f'
TRANSFERRED_MODEL_SHA = '07002b819ddc3dbef3ddf003bd41587475cee5fddb257df2f73cbad517cf2aae'


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)


def plan(root, output, workers):
    root, output = Path(root).resolve(), Path(output).resolve()
    manifest_path = root / 'data/manifest.json'
    manifest = json.loads(manifest_path.read_text())
    corpus, sidecar, model = [root / p for p in
                              ['data/corpus.bin', 'data/true-outcomes.npz', 'model/eval_nnue.nnk']]
    if (manifest.get('state') != 'completed'
            or not manifest.get('leakage_check', {}).get('passed')
            or not manifest.get('placement_orbit_isolation', {}).get('passed')):
        raise ValueError('The transferred corpus must be completed and orbit isolated')
    if sha(corpus) != manifest['sha256'] or sha(sidecar) != manifest['true_outcomes']['sha256']:
        raise ValueError('Transferred corpus or sidecar hash differs')
    if model.stat().st_size != 13016 or model.read_bytes()[:8] != b'NNKMOD01':
        raise ValueError('Transferred warm model format differs')
    # Bind the model to the qualified evidence, rather than accepting any 13KB file.
    evidence = root / 'evidence/latest_validation.json'
    if evidence.exists():
        record = json.loads(evidence.read_text())
        if not record.get('qualified') or not record.get('state', '').startswith('completed'):
            raise ValueError('Transferred champion has no completed qualification')
        expected = record['candidates'][record['selected']]['model_sha256']
        if sha(model) != expected:
            raise ValueError('Transferred model differs from the qualified champion')
    cpus = sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else list(range(os.cpu_count() or 1))
    if not 1 <= workers <= 4:
        raise ValueError('Use between one and four native workers')
    cpus = cpus[:min(workers, len(cpus))]
    trainer = root / 'trainer'
    files = [trainer / 'Cargo.toml', trainer / 'Cargo.lock', *sorted((trainer / 'src').glob('*.rs')),
             Path(__file__).resolve(), Path(__file__).with_name('portable_audit.py').resolve()]
    return dict(schema_version=1, method='native_Rust_champion_weight_fine_tuning',
                corpus=str(corpus), corpus_sha256=sha(corpus), records=manifest['records'],
                sidecar=str(sidecar), sidecar_sha256=sha(sidecar),
                model=str(model), initial_weights_sha256=sha(model),
                trainer_manifest=str(trainer / 'Cargo.toml'), source_hashes={str(p):sha(p) for p in files},
                output=str(output), cpu_ids=cpus, trials=[dict(seed=s, anchor=a) for s, a in TRIALS],
                epochs=12, batch=256, learning_rate=.003, l2=.00001, gradient_clip=10.,
                objective_group_mix=[.7, .2, .1], minimum_primary_bce_improvement=.0001,
                active_anchor_rms_limit_internal=150, correction_cap_internal=500,
                initializer='exact qualified model bytes; fresh Adam moments and step counter',
                selection='native eligibility plus strict held-out trueMC gain over initializer AND core; rank primary BCE',
                python_role='scheduling, hashes and fixed-prediction audit only',
                accelerator='CPU; no GPU or TPU kernels are implemented',
                playing_strength_validated=False)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--output', type=Path, default=Path('/kaggle/working/rust-training'))
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--dry-run', action='store_true', help='verify input hashes and print the plan; no build or fitting')
    parser.add_argument('--check-only', action='store_true', help='build/test Rust and validate the corpus; no fitting')
    parser.add_argument('--purpose', choices=['reproduce', 'train-new'],
                        help='required for fitting: transferred round-13 inputs were already fitted locally')
    parser.add_argument('--max-seconds', type=float, help='optional caller-set wall-time limit; no default compute limit')
    args = parser.parse_args(argv)
    if args.max_seconds is not None and args.max_seconds <= 0:
        parser.error('--max-seconds must be positive')
    registration = plan(args.root, args.output, args.workers)
    baseline_pair = (registration['corpus_sha256'] == TRANSFERRED_CORPUS_SHA
                     and registration['initial_weights_sha256'] == TRANSFERRED_MODEL_SHA)
    registration.update(purpose='preflight' if args.check_only else args.purpose,
                        transferred_pair_already_fitted_locally=baseline_pair)
    if not args.dry_run and not args.check_only:
        if args.purpose is None:
            parser.error('fitting requires --purpose reproduce or --purpose train-new')
        if baseline_pair and args.purpose != 'reproduce':
            parser.error('the supplied model/corpus already completed all four fits in round13; use --purpose reproduce or prepare a genuinely new corpus')
    if args.dry_run:
        print(json.dumps(registration, indent=2)); return 0
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError('Preserve previous evidence; choose a new output directory')
    output.mkdir(parents=True)
    atomic(output / 'preregistered-plan.json', registration)
    status = dict(state='building_native_Rust', started=time.time(), actual_optimizer='Rust',
                  completed_trials=0, qualified=False, playing_strength_validated=False,
                  target_reached=False, cpu_ids=registration['cpu_ids'])
    atomic(output / 'status.json', status)
    environment = os.environ.copy()
    environment.update(CARGO_TARGET_DIR=str(output / 'native-target'), CARGO_BUILD_JOBS='1',
                       OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    environment['PATH'] = str(Path.home() / '.cargo/bin') + os.pathsep + environment.get('PATH', '')
    children, lock, stop = [], threading.Lock(), threading.Event()
    received_signal = []
    started = time.monotonic()

    def terminate():
        stop.set()
        with lock:
            for child in children:
                if child.poll() is None:
                    try:
                        child.terminate()
                    except ProcessLookupError:
                        pass
    def on_signal(signum, frame):
        # Never raise between Popen and child registration, or take a lock in
        # an asynchronous handler. The normal polling loop owns cleanup.
        received_signal.append(signum)
        stop.set()

    signal.signal(signal.SIGTERM, on_signal)
    signal.signal(signal.SIGINT, on_signal)

    def checked(command, logfile, cpu=None):
        if stop.is_set():
            raise RuntimeError('Training stopped')
        if cpu is not None:
            if not shutil.which('taskset'):
                raise RuntimeError('taskset is required to honor the recorded CPU affinity')
            command = ['taskset', '-c', str(cpu), *command]
        with Path(logfile).open('wb') as stream:
            # Keep signal/cleanup tracking synchronized with process creation.
            with lock:
                if stop.is_set():
                    raise RuntimeError('Training stopped')
                child = subprocess.Popen([str(x) for x in command], cwd=args.root,
                                         env=environment, stdout=stream, stderr=subprocess.STDOUT)
                children.append(child)
            while child.poll() is None:
                if args.max_seconds and time.monotonic() - started > args.max_seconds:
                    terminate(); raise TimeoutError('Caller-set wall-time limit reached')
                if stop.wait(.25):
                    raise RuntimeError('Training stopped')
            if child.returncode:
                raise subprocess.CalledProcessError(child.returncode, command)

    try:
        manifest = registration['trainer_manifest']
        checked(['cargo', 'test', '--release', '--offline', '--locked', '--manifest-path', manifest,
                 '--lib', '--tests', '-j1'], output / 'rust-tests.log')
        checked(['cargo', 'clippy', '--release', '--offline', '--locked', '--manifest-path', manifest,
                 '--lib', '--bin', 'native-nnue', '--tests', '--', '-D', 'warnings'], output / 'clippy.log')
        checked(['cargo', 'build', '--release', '--offline', '--locked', '--manifest-path', manifest,
                 '--bin', 'native-nnue', '-j1'], output / 'build.log')
        binary = output / 'native-target/release/native-nnue'
        status.update(native_binary=str(binary), native_binary_sha256=sha(binary), state='checking_corpus')
        atomic(output / 'status.json', status)
        checked([binary, 'check', registration['corpus'], output / 'corpus-check.json'], output / 'check.log')
        if not json.loads((output / 'corpus-check.json').read_text())['training_ready']:
            raise ValueError('Native corpus checker rejected training readiness')
        if args.check_only:
            status.update(state='completed_preflight_only', finished=time.time(),
                          genuine_native_training_completed=False, completed_trials=0,
                          next_required='prepare and verify new deep-teaching targets before genuinely new training')
            atomic(output / 'status.json', status)
            print(json.dumps(status, indent=2)); return 0
        checked([binary, 'predict', registration['model'], registration['corpus'],
                 output / 'initial-predictions.bin'], output / 'initial-predict.log')
        cpus = queue.Queue()
        for cpu in registration['cpu_ids']:
            cpus.put(cpu)
        status['state'] = 'native_Rust_fitting'; atomic(output / 'status.json', status)

        def fit(trial):
            seed, anchor = trial['seed'], trial['anchor']
            name = f'seed{seed}-anchor{str(anchor).replace(".", "")}'
            destination = output / name; destination.mkdir()
            cpu = cpus.get()
            try:
                if sha(registration['model']) != registration['initial_weights_sha256']:
                    raise ValueError('The registered warm initializer changed')
                checked([binary, 'train', registration['corpus'], destination, '--init-model', registration['model'],
                         '--epochs', '12', '--batch', '256', '--lr', '.003', '--seed', str(seed),
                         '--anchor', str(anchor)], destination / 'train.log', cpu=cpu)
                report = json.loads((destination / 'report.json').read_text())
                if (sha(destination / 'epoch-000.nnk') != registration['initial_weights_sha256']
                        or report.get('initialization', {}).get('mode') != 'warm_start'
                        or report['initialization'].get('optimizer_state_restored') is not False):
                    raise ValueError('Native fit did not preserve the exact warm initializer')
                return dict(id=name, output=str(destination), cpu=cpu, seed=seed, anchor=anchor,
                            native_eligible=report['selection']['eligible_checkpoint_found'],
                            selected_epoch=report['selection']['selected_epoch'],
                            primary_validation_bce=report['selected_metrics']['validation']['primary']['bce'],
                            weights_sha256=sha(destination / 'selected.nnk'))
            finally:
                cpus.put(cpu)

        with ThreadPoolExecutor(max_workers=len(registration['cpu_ids'])) as executor:
            futures = [executor.submit(fit, trial) for trial in registration['trials']]
            trials = []
            for future in futures:
                trials.append(future.result())
                status.update(completed_trials=len(trials), trials=trials)
                atomic(output / 'status.json', status)
        status['state'] = 'fixed_prediction_true_outcome_audits'; atomic(output / 'status.json', status)
        for trial in trials:
            destination = Path(trial['output'])
            prediction_path = destination / 'predictions.bin'
            checked([binary, 'predict', destination / 'selected.nnk', registration['corpus'], prediction_path],
                    destination / 'predict.log')
            gate = audit(args.root / 'data/manifest.json', registration['sidecar'], prediction_path,
                         output / 'initial-predictions.bin')
            trial['true_outcome_gate'] = gate
            trial['eligible'] = bool(trial['native_eligible'] and gate['eligible'])
            atomic(destination / 'true-outcome-audit.json', gate)
        ranked = sorted([trial for trial in trials if trial['eligible']],
                        key=lambda trial: (trial['primary_validation_bce'], trial['id']))
        for path, checksum in registration['source_hashes'].items():
            if sha(path) != checksum:
                raise ValueError('A registered training source changed')
        if (sha(registration['corpus']) != registration['corpus_sha256']
                or sha(registration['sidecar']) != registration['sidecar_sha256']
                or sha(registration['model']) != registration['initial_weights_sha256']):
            raise ValueError('A registered training input changed')
        chosen = Path(ranked[0]['output']) / 'selected.nnk' if ranked else Path(registration['model'])
        shutil.copyfile(chosen, output / 'selected.nnk')
        status.update(state='completed_offline_only', finished=time.time(),
                      elapsed_seconds=time.monotonic() - started, trials=trials, ranked=ranked,
                      selected_model=str(output / 'selected.nnk'), selected_weights_sha256=sha(output / 'selected.nnk'),
                      selection_reason='best offline-eligible warm checkpoint' if ranked else 'retained exact initial champion',
                      genuine_native_training_completed=True, next_required='engine parity, tactics, defense and fresh one-second matches')
        atomic(output / 'status.json', status)
        print(json.dumps(status, indent=2)); return 0
    except BaseException as error:
        terminate()
        with lock:
            tracked = list(children)
        for child in tracked:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(timeout=10)
        status.update(state='interrupted' if received_signal or isinstance(error, KeyboardInterrupt) else 'failed_preserved',
                      error=f'{type(error).__name__}: {error}', finished=time.time(), target_reached=False)
        atomic(output / 'status.json', status)
        raise


if __name__ == '__main__':
    raise SystemExit(main())
