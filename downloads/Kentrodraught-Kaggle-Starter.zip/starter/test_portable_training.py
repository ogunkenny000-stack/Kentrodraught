import contextlib
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest import mock

import numpy as np

import portable_audit as a
import run_training as r


class PortableTrainingTests(unittest.TestCase):
    def fixture(self, root):
        root = Path(root)
        for name in ['data', 'model', 'trainer/src', 'evidence']:
            (root / name).mkdir(parents=True)
        (root / 'model/eval_nnue.nnk').write_bytes(b'NNKMOD01' + bytes(13008))
        (root / 'data/corpus.bin').write_bytes(b'NNKCOR01' + struct.pack('<Q', 2))
        np.savez(root / 'data/true-outcomes.npz', corpus_record_index=np.array([0, 1], dtype=np.uint64),
                 baseline_logit=np.array([0., 0.]), mc=np.array([1., 0.]),
                 mc_weight=np.array([1., 0.]), unknown_weight=np.array([0., 1000.]))
        m = dict(state='completed', records=2, sha256=a.sha(root / 'data/corpus.bin'),
                 leakage_check=dict(passed=True), placement_orbit_isolation=dict(passed=True),
                 true_outcomes=dict(sha256=a.sha(root / 'data/true-outcomes.npz')),
                 blocks=dict(V=dict(record_start=0, records=2)))
        (root / 'data/manifest.json').write_text(json.dumps(m))
        (root / 'trainer/Cargo.toml').write_text('[package]\nname="fixture"\n')
        (root / 'trainer/Cargo.lock').write_text('# fixture\n')
        (root / 'trainer/src/lib.rs').write_text('// fixture\n')
        e = dict(qualified=True, state='completed_below_target', selected='nnue',
                 candidates=dict(nnue=dict(model_sha256=a.sha(root / 'model/eval_nnue.nnk'))))
        (root / 'evidence/latest_validation.json').write_text(json.dumps(e))
        return m

    def prediction(self, path, values, count=None):
        Path(path).write_bytes(b'NNKPRD01' + struct.pack('<Q', len(values) if count is None else count)
                               + np.asarray(values, dtype='<i2').tobytes())

    def test_outcome_audit_requires_improvement_and_ignores_cutoff_mass(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory); self.fixture(p)
            self.prediction(p/'initial.bin', [100, 0])
            self.prediction(p/'new.bin', [200, -30000])
            gate = a.audit(p/'data/manifest.json', p/'data/true-outcomes.npz', p/'new.bin', p/'initial.bin')
            self.assertTrue(gate['eligible']); self.assertEqual(gate['primary_mc_records'], 1)
            self.assertEqual(gate['cutoff_records_excluded'], 1)
            self.prediction(p/'new.bin', [100, 30000])
            self.assertFalse(a.audit(p/'data/manifest.json', p/'data/true-outcomes.npz', p/'new.bin', p/'initial.bin')['eligible'])

    def test_changed_predictions_or_sidecar_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory); self.fixture(p)
            self.prediction(p/'initial.bin', [100, 0]); self.prediction(p/'new.bin', [200, 0], count=3)
            with self.assertRaises(ValueError):
                a.audit(p/'data/manifest.json', p/'data/true-outcomes.npz', p/'new.bin', p/'initial.bin')
            self.prediction(p/'new.bin', [200, 0])
            with (p/'data/true-outcomes.npz').open('ab') as stream: stream.write(b'changed')
            with self.assertRaises(ValueError):
                a.audit(p/'data/manifest.json', p/'data/true-outcomes.npz', p/'new.bin', p/'initial.bin')

    def test_dry_run_uses_available_affinity_and_never_spawns(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory); self.fixture(p)
            with mock.patch.object(r.os, 'sched_getaffinity', return_value={8, 10}), \
                    mock.patch.object(r.subprocess, 'Popen', side_effect=AssertionError('must not spawn')):
                text = io.StringIO()
                with contextlib.redirect_stdout(text):
                    self.assertEqual(r.main(['--root', str(p), '--output', str(p/'out'), '--dry-run']), 0)
                self.assertEqual(json.loads(text.getvalue())['cpu_ids'], [8, 10])
                self.assertFalse((p/'out').exists())

    def test_champion_hash_mismatch_and_invalid_workers_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory); self.fixture(p)
            with self.assertRaises(ValueError): r.plan(p, p/'out', 0)
            model = p/'model/eval_nnue.nnk'; model.write_bytes(model.read_bytes()[:-1] + b'x')
            with self.assertRaises(ValueError): r.plan(p, p/'out', 4)

    def test_transferred_pair_cannot_be_claimed_new_training(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory); self.fixture(p)
            with mock.patch.object(r, 'TRANSFERRED_CORPUS_SHA', a.sha(p/'data/corpus.bin')), \
                    mock.patch.object(r, 'TRANSFERRED_MODEL_SHA', a.sha(p/'model/eval_nnue.nnk')), \
                    contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    r.main(['--root', str(p), '--output', str(p/'out'), '--purpose', 'train-new'])
            self.assertFalse((p/'out').exists())

    def test_notebook_syntax_and_reproduction_disabled(self):
        path = Path(__file__).with_name('Kaggle_Rust_Training.ipynb')
        notebook = json.loads(path.read_text())
        sources = []
        for cell in notebook['cells']:
            if cell['cell_type'] == 'code':
                source = ''.join(cell['source']); sources.append(source); compile(source, str(path), 'exec')
        self.assertTrue(any('RUN_BASELINE_REPRODUCTION = False' in s for s in sources))
        self.assertTrue(any("'--check-only'" in s for s in sources))


if __name__ == '__main__': unittest.main()
