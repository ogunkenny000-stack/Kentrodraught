# Nigerian Draughts — Python PDN Player

Watch the ten recorded games between the Rust build uploaded to GitHub and the
original C++ engine. The player runs offline, using Python and Tkinter. No pip
packages, engine binaries, model files, or internet connection are needed.

## Run

1. Extract the entire ZIP into one folder.
2. Install Python **3.10 or newer** if needed.
3. On **Windows**, double-click `run_player.bat`.
4. On **Linux or macOS**, open a terminal in the extracted folder and run:

   ```sh
   python3 pdn_player.py
   ```

   On Windows you can also run `py -3 pdn_player.py`.

Python from python.org normally includes Tkinter on Windows and macOS. On
Debian/Ubuntu, install the desktop component with `sudo apt install python3-tk`.
This is a desktop viewer; it needs a graphical display.

## Watch a game

- Choose a game in the list at the top right.
- Use **Next / Back** or **Right / Left arrow** to move one turn at a time.
- Click **Play** or press **Space** for autoplay; select seconds per move beside it.
- Drag the timeline or click any recorded move to jump directly to that position.
- Use **Start / End** or **Home / End** to jump to the beginning or finish.
- Click **Flip board** or press **F** to watch from Black's side.
- **K** marks a king. Gold highlights and arrows show the last move and its landing
  path; red outlines mark captured squares.
- The sidebar shows player names, the recorded result, material counts, and the
  last move's reported evaluation, depth, and elapsed thinking time.

Evaluations are shown from the **player who made that move's perspective**.
They are the engines' recorded opinions, not probabilities or independent proofs.
Forced C++ moves with a score but no searched depth are labeled as static scores.

## Game files

- `games/all-games.pdn` — all ten games; this opens automatically.
- `games/game-01.pdn` through `game-10.pdn` — one game per file, **one ply per line**.
- `games/game-01-moves.csv` through `game-10-moves.csv` — one move per row, with
  player, PDN move, original engine notation, captured squares, landing path,
  promotion, evaluation, depth, thinking time, and before/after positions.
- `games/manifest.json` — game summaries and engine checksums.

Open another game with the **Open PDN** button, or:

```sh
python3 pdn_player.py games/game-03.pdn
```

This player implements the supplied **Nigerian 10×10 rules**. It reads PDN
mainlines, comments, setup FENs, and multiple games; analysis variations are
skipped. It rejects illegal or ambiguous moves. Unsupported variants are not
silently replayed with different rules.

## What is recorded

These are the actual fresh ten-game challenge records, not newly generated games.
Rust played each color five times. The thinking limit was one second per move,
with one thread, no book, and no external tablebases. The same five preset
12-ply openings were each played with colors reversed. Those opening moves are
included and labeled; no engine thinking time is attributed to them.

The result was **0 Rust wins, 0 C++ wins, 10 draws**. All games ended under the
original Nigerian material-draw rule: a lone king without men against at most
three opposing pieces is drawn. None reached the 150-ply cutoff.

The engine logs encode captures as origin, final square, and a set of captured
squares. The exported PDNs instead use actual **landing-square paths**. Each
conversion was checked against the recorded challenge positions, and every PDN
was parsed back to verify the full sequence and final board.

## Check files without opening a window

```sh
python3 pdn_player.py --check
python3 -m unittest discover -s tests -v
```

`export_games.py` is the export utility for the original challenge JSON plus its
per-game logs. It is not needed for playback. The viewer and all game data are
self-contained in this ZIP.

License: GPL-3.0-or-later. See `LICENSE` and `NOTICE`.
