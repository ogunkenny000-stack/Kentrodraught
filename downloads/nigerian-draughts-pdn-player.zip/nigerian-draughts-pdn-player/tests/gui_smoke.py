"""Optional desktop smoke check: python tests/gui_smoke.py (requires a display)."""
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from draughts import read_pdn
from pdn_player import Player, tk


def run():
    games = read_pdn((ROOT / 'games/all-games.pdn').read_text(encoding='utf-8'))
    root = tk.Tk()
    errors = []
    root.report_callback_exception = lambda *exc: errors.append(repr(exc))
    app = Player(root, games, ROOT / 'games/all-games.pdn')
    root.update()
    assert len(app.canvas.find_withtag('piece')) == 40
    assert app.ply == 0
    root.focus_force()
    root.event_generate('<Right>')
    root.update()
    assert app.ply == 1
    root.event_generate('<Left>')
    root.update()
    assert app.ply == 0
    app.moves.selection_set('27')
    root.update()
    assert app.ply == 27
    app.timeline.set(5)
    root.update()
    assert app.ply == 5
    app.go(0)
    root.update()
    before = app.canvas.coords(app.canvas.find_withtag('square-1')[0])
    app.flip()
    root.update()
    after = app.canvas.coords(app.canvas.find_withtag('square-1')[0])
    assert abs((before[0] + before[2] + after[0] + after[2]) / 2 - app.canvas.winfo_width()) < 1
    app.flip()
    for index, game in enumerate(games):
        app.choose(index)
        root.update()
        assert app.ply == 0 and len(app.canvas.find_withtag('piece')) == 40
        app.go(len(game.turns))
        root.update()
        expected = sum(p != 'e' for p in game.positions[-1].board)
        assert len(app.canvas.find_withtag('piece')) == expected
        assert len(app.canvas.find_withtag('king')) == sum(p in 'WB' for p in game.positions[-1].board)
        assert app.play_button.instate(['disabled'])
        assert 'End of game' in app.turn_var.get()
    app.choose(0)
    app.speed.set('0.005')
    app.toggle_play()
    deadline = time.monotonic() + 2
    while app.ply < 4 and time.monotonic() < deadline:
        root.update()
        time.sleep(.003)
    app.stop()
    assert app.ply >= 4 and app.timer is None
    stopped = app.ply
    root.update()
    assert app.ply == stopped
    app.go(len(app.game.turns) - 1)
    app.toggle_play()
    root.update()
    assert app.ply == len(app.game.turns) and not app.playing and app.timer is None
    with patch('pdn_player.filedialog.askopenfilename', return_value=str(ROOT / 'games/game-03.pdn')):
        app.open_file()
    root.update()
    assert len(app.games) == 1 and len(app.game.turns) == 113
    app.games = games
    app.update_choices()
    app.choose(1)
    app.go(76)
    app.speed.set('1.0')
    root.update()
    assert not errors, errors
    return app, root, {'status': 'passed', 'games_rendered': 10,
                       'checks': ['keyboard', 'move selection', 'timeline', 'board flip',
                                  'piece and king rendering', 'all recorded final positions',
                                  'autoplay and pause', 'end boundary', 'open individual PDN'],
                       'callback_errors': errors}


if __name__ == '__main__':
    app, root, report = run()
    print(json.dumps(report, indent=2))
    app.close()
