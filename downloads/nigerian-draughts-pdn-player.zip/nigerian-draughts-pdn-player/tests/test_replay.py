"""Capture, notation, and full-game regression checks; no third-party dependencies."""
import csv
import json
from pathlib import Path
import unittest

from draughts import Move, Position, START, coordinates, read_pdn, square_at

ROOT = Path(__file__).resolve().parent.parent


class RulesAndPdn(unittest.TestCase):
    def test_square_numbering_and_standard_start(self):
        self.assertEqual(coordinates(1), (0, 1))
        self.assertEqual(coordinates(50), (9, 8))
        for square in range(1, 51):
            self.assertEqual(square_at(*coordinates(square)), square)
        position = Position.parse()
        self.assertEqual(len(position.legal_moves()), 9)
        self.assertEqual(Position.parse(position.fen), position)

    def test_backward_man_capture_is_compulsory(self):
        position = Position.parse('W:W28,36:B32')
        moves = position.legal_moves()
        self.assertTrue(moves)
        self.assertTrue(all(m.captured for m in moves))
        move = position.find_pdn('28x37')
        self.assertEqual(move.captured, (32,))

    def test_engine_capture_notation_is_converted(self):
        position = Position.parse('W:W28:B23')
        move = position.find_hub('28x19x23')
        self.assertEqual(move.pdn, '28x19')
        self.assertEqual(move.captured, (23,))
        self.assertEqual(position.play(move).board[18], 'w')
        with self.assertRaises(ValueError):
            position.find_pdn('28x19x23')

    def test_promotion_occurs_at_turn_end(self):
        position = Position.parse('W:W12:B7,8')
        move = position.find_pdn('12x1')
        self.assertEqual(position.play(move).board[0], 'W')
        # A man touching the promotion row in the middle of a capture is not
        # crowned if the whole move ends elsewhere.
        position = Position.parse('W:W14:B8,9')
        move = position.find_pdn('14x3x12')
        self.assertEqual(position.play(move).board[11], 'w')
        self.assertEqual(position.play(move).material('W'), (1, 0))

    def test_canonical_subset_ambiguity_witness(self):
        position = Position.parse('BbbeeeWeewweeeeebeeeeeeeeeeeewBebeeeeeeeeewbWbBeeeB')
        short = position.find_hub('50x47x42x44')
        long = position.find_hub('50x47x9x10x29x42x44')
        self.assertEqual(set(short.captured), {42, 44})
        self.assertEqual(set(long.captured), {9, 10, 29, 42, 44})
        self.assertEqual(position.find_pdn(short.pdn).hub, short.hub)
        self.assertEqual(position.find_pdn(long.pdn).hub, long.hub)
        with self.assertRaises(ValueError):
            position.find_pdn('50x47')

    def test_original_material_draw_rule(self):
        self.assertTrue(Position.parse('W:WK3:B4,26,28').material_draw)
        self.assertFalse(Position.parse('W:WK3:B4,26,28,30').material_draw)

    def test_comments_variations_numbers_and_fen(self):
        games = read_pdn('''[Event "Test"]
[Variant "Nigerian"]
[Result "*"]
1.33-28! {[%score_mover 0.12]} (1. 34-29 (1... 20-25))
1...19-23 $1 ; a comment
2.28x19 *
''')
        self.assertEqual(len(games), 1)
        self.assertEqual([t.token for t in games[0].turns], ['33-28', '19-23', '28x19'])
        self.assertEqual(games[0].turns[0].annotation('score_mover'), '0.12')
        fen_game = read_pdn('[SetUp "1"]\n[FEN "B:W31:B20"]\n1... 20-25 *')[0]
        self.assertEqual(fen_game.positions[0].turn, 'B')
        self.assertEqual(fen_game.positions[-1].board[24], 'b')

    def test_invalid_and_unsupported_files_fail_clearly(self):
        for text in ['1. 33-50 *', '[Variant "English"]\n1.33-28 *',
                     '[Result "1-0"]\n1.33-28 0-1', '1.33-28 (1...19-23 *',
                     '[PlyCount "4"]\n1.33-28 *', '[FEN "W:WK3:B26,28"]\n1.3-8 *']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                read_pdn(text)


class RecordedGames(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.games = read_pdn((ROOT / 'games/all-games.pdn').read_text(encoding='utf-8'))
        cls.expected = json.loads((ROOT / 'tests/recorded-final-positions.json').read_text())

    def test_all_ten_recorded_final_boards_and_lengths(self):
        self.assertEqual(len(self.games), 10)
        self.assertEqual(sum(len(g.turns) for g in self.games), 1253)
        for game, expected in zip(self.games, self.expected):
            with self.subTest(game=expected['game']):
                self.assertEqual(game.positions[0].hub, START)
                self.assertEqual(len(game.turns), expected['plies'])
                self.assertEqual(game.positions[-1].hub, expected['position'])
                self.assertTrue(game.positions[-1].material_draw)
                self.assertEqual(game.tags['Result'], '1/2-1/2')

    def test_every_csv_row_and_individual_pdn_matches(self):
        for number, game in enumerate(self.games, 1):
            individual = read_pdn((ROOT / f'games/game-{number:02d}.pdn').read_text(encoding='utf-8'))
            self.assertEqual([p.hub for p in individual[0].positions], [p.hub for p in game.positions])
            with (ROOT / f'games/game-{number:02d}-moves.csv').open(encoding='utf-8', newline='') as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), len(game.turns))
            for ply, (row, turn) in enumerate(zip(rows, game.turns), 1):
                with self.subTest(game=number, ply=ply):
                    self.assertEqual(row['pdn_move'], turn.token)
                    self.assertEqual(Position.parse(row['position_before']), game.positions[ply - 1])
                    self.assertEqual(Position.parse(row['position_after']), game.positions[ply])


if __name__ == '__main__':
    unittest.main()
