#!/usr/bin/env python3
"""An offline Python/Tkinter player for the included Nigerian draughts PDNs."""
import argparse
from pathlib import Path
import sys

from draughts import coordinates, read_pdn

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk, font as tkfont
except ImportError:
    tk = None

HERE = Path(__file__).resolve().parent
DEFAULT = HERE / 'games' / 'all-games.pdn'


class Player:
    def __init__(self, root, games, path):
        self.root, self.games, self.path = root, games, path
        self.index = self.ply = 0
        self.playing = self.flipped = self.rendering = False
        self.timer = None
        self.game = games[0]
        root.title('Nigerian Draughts - Match Replay')
        root.geometry('1190x810')
        root.minsize(900, 660)
        root.configure(bg='#111b24')
        self.font_family = tkfont.nametofont('TkDefaultFont').actual('family')
        style = ttk.Style(root)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('.', font=(self.font_family, 10), background='#192631', foreground='#edf1f4')
        style.configure('TFrame', background='#192631')
        style.configure('TLabel', background='#192631', foreground='#edf1f4')
        style.configure('Heading.TLabel', font=(self.font_family, 17, 'bold'))
        style.configure('Muted.TLabel', foreground='#a7b6c2')
        style.configure('TButton', padding=(10, 7), background='#304655')
        style.map('TButton', background=[('active', '#426072')], foreground=[('disabled', '#71818b')])
        style.configure('Accent.TButton', background='#287a71', foreground='white')
        style.configure('Treeview', background='#14212b', fieldbackground='#14212b',
                        foreground='#e7eef3', rowheight=27, borderwidth=0)
        style.configure('Treeview.Heading', background='#304655', foreground='#edf1f4', padding=5)
        style.map('Treeview', background=[('selected', '#32635f')])
        style.configure('TCombobox', fieldbackground='#e9eef0', foreground='#15212b')
        root.columnconfigure(0, weight=1)
        root.rowconfigure(1, weight=1)
        header = ttk.Frame(root, padding=(18, 14))
        header.grid(row=0, column=0, sticky='ew')
        header.columnconfigure(0, weight=1)
        ttk.Label(header, text='NIGERIAN DRAUGHTS', style='Heading.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(header, text='Move-by-move match replay', style='Muted.TLabel').grid(row=1, column=0, sticky='w', pady=(3, 0))
        ttk.Button(header, text='Open PDN...', command=self.open_file).grid(row=0, column=1, rowspan=2, padx=(12, 0))
        body = ttk.Frame(root, padding=(12, 10))
        body.grid(row=1, column=0, sticky='nsew', pady=(1, 0))
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2, minsize=335)
        body.rowconfigure(0, weight=1)
        board_panel = ttk.Frame(body)
        board_panel.grid(row=0, column=0, sticky='nsew', padx=(0, 14))
        board_panel.columnconfigure(0, weight=1)
        board_panel.rowconfigure(1, weight=1)
        self.turn_var = tk.StringVar()
        ttk.Label(board_panel, textvariable=self.turn_var, font=(self.font_family, 12, 'bold')).grid(row=0, column=0, sticky='w', padx=8, pady=(0, 4))
        self.canvas = tk.Canvas(board_panel, width=660, height=660, bg='#111b24', highlightthickness=0)
        self.canvas.grid(row=1, column=0, sticky='nsew')
        self.canvas.bind('<Configure>', lambda event: self.draw_board())
        self.material_var = tk.StringVar()
        ttk.Label(board_panel, textvariable=self.material_var, style='Muted.TLabel').grid(row=2, column=0, sticky='w', pady=(6, 4), padx=8)
        self.move_var = tk.StringVar()
        ttk.Label(board_panel, textvariable=self.move_var).grid(row=3, column=0, sticky='w', padx=8)
        side = ttk.Frame(body)
        side.grid(row=0, column=1, sticky='nsew')
        side.columnconfigure(0, weight=1)
        side.rowconfigure(5, weight=1)
        self.game_choice = ttk.Combobox(side, state='readonly', width=40)
        self.game_choice.grid(row=0, column=0, sticky='ew')
        self.game_choice.bind('<<ComboboxSelected>>', lambda event: self.choose(self.game_choice.current()))
        nav = ttk.Frame(side)
        nav.grid(row=1, column=0, sticky='ew', pady=7)
        nav.columnconfigure((0, 1), weight=1)
        self.previous_game = ttk.Button(nav, text='< Previous game', command=lambda: self.choose(self.index - 1))
        self.previous_game.grid(row=0, column=0, sticky='ew', padx=(0, 4))
        self.next_game = ttk.Button(nav, text='Next game >', command=lambda: self.choose(self.index + 1))
        self.next_game.grid(row=0, column=1, sticky='ew')
        self.players_var = tk.StringVar()
        ttk.Label(side, textvariable=self.players_var, wraplength=395).grid(row=2, column=0, sticky='w', pady=(2, 7))
        self.result_var = tk.StringVar()
        ttk.Label(side, textvariable=self.result_var, foreground='#80d3b4', wraplength=395).grid(row=3, column=0, sticky='w', pady=(0, 8))
        self.search_var = tk.StringVar()
        ttk.Label(side, textvariable=self.search_var, style='Muted.TLabel', wraplength=395, justify='left').grid(row=4, column=0, sticky='ew', pady=(0, 8))
        table = ttk.Frame(side)
        table.grid(row=5, column=0, sticky='nsew')
        table.columnconfigure(0, weight=1)
        table.rowconfigure(0, weight=1)
        self.moves = ttk.Treeview(table, columns=('turn', 'side', 'move', 'score'), show='headings', selectmode='browse')
        for column, title, width in [('turn', 'Turn', 48), ('side', 'Side', 62), ('move', 'Move', 160), ('score', 'Eval*', 64)]:
            self.moves.heading(column, text=title)
            self.moves.column(column, width=width, minwidth=width, stretch=(column == 'move'), anchor='w')
        self.moves.grid(row=0, column=0, sticky='nsew')
        scroll = ttk.Scrollbar(table, orient='vertical', command=self.moves.yview)
        scroll.grid(row=0, column=1, sticky='ns')
        hscroll = ttk.Scrollbar(table, orient='horizontal', command=self.moves.xview)
        hscroll.grid(row=1, column=0, sticky='ew')
        self.moves.configure(yscrollcommand=scroll.set, xscrollcommand=hscroll.set)
        self.moves.tag_configure('opening', foreground='#a0b0bb')
        self.moves.bind('<<TreeviewSelect>>', self.select_move)
        ttk.Label(side, text='* Reported score for the player who moved.\nGray moves are the preset opening.', style='Muted.TLabel').grid(row=6, column=0, sticky='w', pady=(6, 0))
        controls = ttk.Frame(root, padding=(18, 10))
        controls.grid(row=2, column=0, sticky='ew')
        controls.columnconfigure(0, weight=1)
        self.progress_var = tk.StringVar()
        ttk.Label(controls, textvariable=self.progress_var).grid(row=0, column=0, sticky='w')
        self.scrub_var = tk.IntVar(value=0)
        self.timeline = tk.Scale(controls, from_=0, to=1, orient='horizontal', resolution=1,
                                 showvalue=False, variable=self.scrub_var, command=self.scrub,
                                 bg='#192631', fg='#e7eef3', troughcolor='#304655',
                                 activebackground='#80d3b4', highlightthickness=0, borderwidth=0)
        self.timeline.grid(row=1, column=0, sticky='ew', pady=(2, 8))
        buttons = ttk.Frame(controls)
        buttons.grid(row=2, column=0, sticky='ew')
        self.first_button = ttk.Button(buttons, text='|< Start', command=lambda: self.go(0))
        self.first_button.pack(side='left', padx=(0, 5))
        self.back_button = ttk.Button(buttons, text='< Back', command=lambda: self.go(self.ply - 1))
        self.back_button.pack(side='left', padx=(0, 5))
        self.play_button = ttk.Button(buttons, text='Play', style='Accent.TButton', command=self.toggle_play)
        self.play_button.pack(side='left', padx=(0, 5))
        self.forward_button = ttk.Button(buttons, text='Next >', command=lambda: self.go(self.ply + 1))
        self.forward_button.pack(side='left', padx=(0, 5))
        self.last_button = ttk.Button(buttons, text='End >|', command=lambda: self.go(len(self.game.turns)))
        self.last_button.pack(side='left', padx=(0, 12))
        ttk.Button(buttons, text='Flip board', command=self.flip).pack(side='right')
        self.speed = tk.StringVar(value='1.0')
        ttk.Combobox(buttons, textvariable=self.speed, values=('0.25', '0.5', '1.0', '2.0'),
                     width=5, state='readonly').pack(side='right', padx=(5, 12))
        ttk.Label(buttons, text='Seconds / move').pack(side='right')
        ttk.Label(root, text='Left / Right  Move     Space  Play / pause     Home / End  Start / finish     F  Flip     Click a move to jump',
                  style='Muted.TLabel', padding=(18, 8)).grid(row=3, column=0, sticky='ew')
        for sequence, action in [('<Left>', lambda: self.go(self.ply - 1)), ('<Right>', lambda: self.go(self.ply + 1)),
                                 ('<Home>', lambda: self.go(0)), ('<End>', lambda: self.go(len(self.game.turns))),
                                 ('<space>', self.toggle_play), ('<f>', self.flip), ('<Control-o>', self.open_file)]:
            root.bind(sequence, lambda event, fn=action: (fn(), 'break')[1])
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.update_choices()
        self.choose(0)

    def update_choices(self):
        self.game_choice['values'] = tuple(
            f"Game {i + 1:02d} · {g.tags.get('White', 'White').split(' (')[0]} vs {g.tags.get('Black', 'Black').split(' (')[0]}"
            for i, g in enumerate(self.games))

    def choose(self, index):
        if not 0 <= index < len(self.games):
            return
        self.stop()
        self.index, self.ply = index, 0
        self.game = self.games[index]
        self.game_choice.current(index)
        self.players_var.set(f"White: {self.game.tags.get('White', 'White')}\nBlack: {self.game.tags.get('Black', 'Black')}")
        result = self.game.tags.get('Result', '*')
        label = {'1/2-1/2': 'Draw', '1-0': 'White won', '0-1': 'Black won', '*': 'Unfinished'}.get(result, result)
        reason = self.game.tags.get('Termination', '')
        self.result_var.set(f'Recorded result: {label}' + (f' · {reason}' if reason else ''))
        self.previous_game.state(['disabled'] if index == 0 else ['!disabled'])
        self.next_game.state(['disabled'] if index == len(self.games) - 1 else ['!disabled'])
        self.timeline.configure(to=len(self.game.turns))
        self.moves.delete(*self.moves.get_children())
        self.moves.insert('', 'end', iid='0', values=('', '', 'Starting position', ''))
        opening = int(self.game.tags.get('OpeningPlyCount', 0))
        for i, turn in enumerate(self.game.turns, 1):
            side = self.game.positions[i - 1].turn
            number = (i + (1 if self.game.positions[0].turn == 'W' else 2)) // 2
            prefix = f'{number}.' if side == 'W' else f'{number}...'
            self.moves.insert('', 'end', iid=str(i), values=(prefix, 'White' if side == 'W' else 'Black',
                              turn.token, turn.annotation('score_mover') or '-'), tags=('opening',) if i <= opening else ())
        self.render()

    def go(self, ply, stop=True):
        if stop:
            self.stop()
        self.ply = max(0, min(int(ply), len(self.game.turns)))
        self.render()

    def render(self):
        self.rendering = True
        self.scrub_var.set(self.ply)
        self.moves.selection_set(str(self.ply))
        self.moves.see(str(self.ply))
        self.rendering = False
        position = self.game.positions[self.ply]
        wm, wk = position.material('W')
        bm, bk = position.material('B')
        self.material_var.set(f'White: {wm} men · {wk} kings     |     Black: {bm} men · {bk} kings')
        self.progress_var.set(f'Game {self.index + 1} / {len(self.games)}     ·     Ply {self.ply} / {len(self.game.turns)}')
        if self.ply == len(self.game.turns):
            self.turn_var.set('End of game · ' + self.result_var.get().removeprefix('Recorded result: '))
        else:
            side = 'White' if position.turn == 'W' else 'Black'
            self.turn_var.set(f"{side} to move · {self.game.tags.get(side, side)}")
        if self.ply:
            turn = self.game.turns[self.ply - 1]
            taken = ', '.join(map(str, turn.move.captured))
            self.move_var.set(f'Last move: {turn.token}' + (f'   ·   Captured: {taken}' if taken else ''))
            score, depth, seconds = (turn.annotation(name) for name in ('score_mover', 'depth', 'seconds'))
            if self.ply <= int(self.game.tags.get('OpeningPlyCount', 0)):
                self.search_var.set('Preset opening move · no engine search was run.')
            elif score is not None:
                label = 'Search score' if depth is not None else 'Static score (forced move)'
                self.search_var.set(f'{label}: {score} for the player who moved\n' +
                                    (f'Depth {depth}' if depth is not None else 'No search depth reported') +
                                    (f' · {float(seconds):.3f}s' if seconds else ''))
            else:
                self.search_var.set('No evaluation was recorded for this move.')
        else:
            self.move_var.set('Starting position · White pieces begin at the bottom.')
            self.search_var.set('Choose a move, press Next, or start autoplay.')
        for button in (self.first_button, self.back_button):
            button.state(['disabled'] if self.ply == 0 else ['!disabled'])
        for button in (self.forward_button, self.last_button, self.play_button):
            button.state(['disabled'] if self.ply == len(self.game.turns) else ['!disabled'])
        self.draw_board()

    def draw_board(self):
        canvas = self.canvas
        canvas.delete('all')
        width, height = canvas.winfo_width(), canvas.winfo_height()
        size = min(width, height) - 20
        if size <= 0:
            return
        unit = size / 10
        left, top = (width - size) / 2, (height - size) / 2
        position = self.game.positions[self.ply]
        last = self.game.turns[self.ply - 1].move if self.ply else None

        def box(row, col):
            if self.flipped:
                row, col = 9 - row, 9 - col
            x, y = left + col * unit, top + row * unit
            return x, y, x + unit, y + unit

        def center(square):
            x, y, _, _ = box(*coordinates(square))
            return x + unit / 2, y + unit / 2

        for row in range(10):
            for col in range(10):
                playable = (row + col) % 2 == 1
                square = row * 5 + col // 2 + 1 if playable else None
                fill = '#648575' if playable else '#ece4cf'
                if last and square in (last.origin, last.destination):
                    fill = '#b59b58'
                rect = box(row, col)
                canvas.create_rectangle(*rect, fill=fill, outline=fill)
                if playable:
                    canvas.create_text(rect[0] + 4, rect[1] + 3, text=str(square), anchor='nw',
                                       fill='#e3eadb', font=(self.font_family, max(7, int(unit * .14))))
                if last and square in last.captured:
                    inset = unit * .05
                    canvas.create_rectangle(rect[0] + inset, rect[1] + inset, rect[2] - inset, rect[3] - inset,
                                            outline='#d7806e', width=2)
        if last:
            points = [value for square in last.path for value in center(square)]
            canvas.create_line(*points, fill='#ffe09a', width=max(2, unit * .045), arrow=tk.LAST,
                               arrowshape=(10, 13, 5), tags='last-path')
        for square, piece in enumerate(position.board, 1):
            if piece == 'e':
                continue
            x, y = center(square)
            radius = unit * .36
            white = piece.upper() == 'W'
            canvas.create_oval(x - radius, y - radius + 2, x + radius, y + radius + 2,
                               fill='#26382d', outline='')
            canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                               fill='#faf6e9' if white else '#202b35',
                               outline='#fffdf6' if white else '#101820', width=2,
                               tags=('piece', 'white-piece' if white else 'black-piece', f'square-{square}'))
            inset = radius * .75
            canvas.create_oval(x - inset, y - inset, x + inset, y + inset,
                               outline='#ccbd9c' if white else '#58616b', width=1)
            if piece.isupper():
                canvas.create_text(x, y, text='K', fill='#8f6222' if white else '#efc76a',
                                   font=(self.font_family, max(10, int(unit * .31)), 'bold'), tags='king')

    def scrub(self, value):
        target = int(float(value))
        if not self.rendering and target != self.ply:
            self.go(target)

    def select_move(self, event=None):
        selection = self.moves.selection()
        if selection and int(selection[0]) != self.ply:
            self.go(int(selection[0]))

    def stop(self):
        self.playing = False
        if self.timer is not None:
            self.root.after_cancel(self.timer)
            self.timer = None
        if hasattr(self, 'play_button'):
            self.play_button.configure(text='Play')

    def toggle_play(self):
        if self.playing:
            self.stop()
        elif self.ply < len(self.game.turns):
            self.playing = True
            self.play_button.configure(text='Pause')
            self.tick()

    def tick(self):
        self.timer = None
        if not self.playing:
            return
        if self.ply >= len(self.game.turns):
            self.stop()
            return
        self.go(self.ply + 1, stop=False)
        if self.ply >= len(self.game.turns):
            self.stop()
        else:
            self.timer = self.root.after(int(float(self.speed.get()) * 1000), self.tick)

    def flip(self):
        self.flipped = not self.flipped
        self.draw_board()

    def open_file(self):
        self.stop()
        path = filedialog.askopenfilename(title='Open Nigerian draughts PDN', initialdir=str(self.path.parent),
                                          filetypes=[('PDN games', '*.pdn'), ('All files', '*')])
        if not path:
            return
        try:
            games = read_pdn(Path(path).read_text(encoding='utf-8-sig'))
        except (OSError, ValueError, UnicodeError) as exc:
            messagebox.showerror('Cannot open this PDN', str(exc))
            return
        self.games, self.path = games, Path(path)
        self.update_choices()
        self.choose(0)

    def close(self):
        self.stop()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('file', nargs='?', type=Path, default=DEFAULT, help='PDN to open (default: included ten games)')
    parser.add_argument('--check', action='store_true', help='Validate all moves without opening a window')
    args = parser.parse_args()
    try:
        games = read_pdn(args.file.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError, UnicodeError) as exc:
        print(f'Cannot open PDN: {exc}', file=sys.stderr)
        return 1
    if args.check:
        for i, game in enumerate(games, 1):
            print(f"Game {i:02d}: {len(game.turns)} plies OK · {game.tags.get('Result', '*')}")
        print(f'Validated {len(games)} games and {sum(len(g.turns) for g in games)} moves.')
        return 0
    if tk is None:
        print('Tkinter is missing. On Debian/Ubuntu install python3-tk. On Windows/macOS use Python from python.org.', file=sys.stderr)
        return 1
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(f'Cannot open a desktop window: {exc}\nRun this player on a computer with a desktop, or use --check for validation.', file=sys.stderr)
        return 1
    Player(root, games, args.file)
    root.mainloop()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
