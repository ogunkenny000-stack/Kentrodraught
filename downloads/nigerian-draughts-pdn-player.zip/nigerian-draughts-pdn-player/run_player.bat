@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
    python pdn_player.py %*
) else (
    py -3 pdn_player.py %*
)
if errorlevel 1 pause
