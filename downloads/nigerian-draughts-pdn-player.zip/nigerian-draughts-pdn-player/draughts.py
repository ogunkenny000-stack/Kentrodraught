"""Nigerian draughts replay rules and PDN mainline reader. GPL-3.0-or-later.

Capture continuation follows the supplied SCAN C++ fork, including its grouped
flying-king landing test. Source attribution and license are in LICENSE/NOTICE.
"""
from dataclasses import dataclass, field
import re

START = "W" + "b" * 20 + "e" * 10 + "w" * 20
DIRECTIONS = ((-1, -1), (-1, 1), (1, -1), (1, 1))


def coordinates(square):
    if not 1 <= square <= 50:
        raise ValueError(f"Square {square} is outside 1–50")
    row, col = divmod(square - 1, 5)
    return row, col * 2 + (1 - row % 2)


def square_at(row, col):
    if 0 <= row < 10 and 0 <= col < 10 and (row + col) % 2:
        return row * 5 + col // 2 + 1
    return None


def step(square, direction):
    row, col = coordinates(square)
    dr, dc = DIRECTIONS[direction]
    return square_at(row + dr, col + dc)


@dataclass(frozen=True)
class Move:
    path: tuple
    captured: tuple = ()

    @property
    def origin(self):
        return self.path[0]

    @property
    def destination(self):
        return self.path[-1]

    @property
    def pdn(self):
        return ("x" if self.captured else "-").join(map(str, self.path))

    @property
    def hub(self):
        if not self.captured:
            return f"{self.origin}-{self.destination}"
        return "x".join(map(str, (self.origin, self.destination, *sorted(self.captured))))


@dataclass(frozen=True)
class Position:
    turn: str
    board: tuple

    @classmethod
    def parse(cls, text=START):
        text = text.strip()
        if ":" not in text:
            if len(text) != 51 or text[0] not in "WB" or any(c not in "wbWBe" for c in text[1:]):
                raise ValueError("Expected a 51-character HUB position or a PDN FEN")
            return cls(text[0], tuple(text[1:]))
        parts = text.split(":")
        if len(parts) != 3 or parts[0] not in "WB":
            raise ValueError("FEN must have a turn and both sides, e.g. W:W31-50:B1-20")
        board = ["e"] * 50
        sides = set()
        for side in parts[1:]:
            if not side or side[0] not in "WB" or side[0] in sides:
                raise ValueError("Missing or repeated FEN side")
            sides.add(side[0])
            for token in filter(None, side[1:].split(",")):
                king = token.startswith("K")
                token = token[1:] if king else token
                match = re.fullmatch(r"(\d+)(?:-(\d+))?", token)
                if not match:
                    raise ValueError(f"Invalid FEN piece: {token}")
                start, end = int(match[1]), int(match[2] or match[1])
                if not 1 <= start <= end <= 50:
                    raise ValueError("Invalid FEN square range")
                for square in range(start, end + 1):
                    if board[square - 1] != "e":
                        raise ValueError("Overlapping FEN pieces")
                    board[square - 1] = side[0] if king else side[0].lower()
        return cls(parts[0], tuple(board))

    @property
    def hub(self):
        return self.turn + "".join(self.board)

    @property
    def fen(self):
        groups = []
        for side in "WB":
            pieces = [("K" if p.isupper() else "") + str(i)
                      for i, p in enumerate(self.board, 1) if p != "e" and p.upper() == side]
            groups.append(side + ",".join(pieces))
        return self.turn + ":" + ":".join(groups)

    @property
    def material_draw(self):
        for side, other in (("W", "B"), ("B", "W")):
            if self.board.count(side) == 1 and self.board.count(side.lower()) == 0:
                if sum(p != "e" and p.upper() == other for p in self.board) <= 3:
                    return True
        return False

    def material(self, side):
        return self.board.count(side.lower()), self.board.count(side)

    def play(self, move):
        board = list(self.board)
        piece = board[move.origin - 1]
        if piece == "e" or piece.upper() != self.turn:
            raise ValueError("Move starts without a piece of the side to move")
        board[move.origin - 1] = "e"
        for square in move.captured:
            victim = board[square - 1]
            if victim == "e" or victim.upper() == self.turn:
                raise ValueError("Capture does not name an opposing piece")
            board[square - 1] = "e"
        if board[move.destination - 1] != "e":
            raise ValueError("Move ends on an occupied square")
        row, _ = coordinates(move.destination)
        if (piece == "w" and row == 0) or (piece == "b" and row == 9):
            piece = piece.upper()
        board[move.destination - 1] = piece
        return Position("B" if self.turn == "W" else "W", tuple(board))

    def legal_moves(self):
        """Keep captured pieces as blockers; promote only after the whole turn."""
        captures = []
        own = [i for i, p in enumerate(self.board, 1) if p != "e" and p.upper() == self.turn]
        enemies = {i for i, p in enumerate(self.board, 1) if p != "e" and p.upper() != self.turn}
        for origin in own:
            free = {i for i, p in enumerate(self.board, 1) if p == "e"} | {origin}

            def man_chain(current, path, taken):
                found = False
                for direction in range(4):
                    victim = step(current, direction)
                    landing = step(victim, direction) if victim is not None else None
                    if victim in enemies and victim not in taken and landing in free:
                        found = True
                        man_chain(landing, path + (landing,), taken + (victim,))
                if not found and taken:
                    captures.append(Move(path, taken))

            def king_targets(current, taken):
                for direction in range(4):
                    square = step(current, direction)
                    while square in free:
                        square = step(square, direction)
                    if square in enemies and square not in taken and step(square, direction) in free:
                        yield square, direction

            def king_after(victim, direction, path, taken):
                taken = taken + (victim,)
                landings = []
                square = step(victim, direction)
                while square in free:
                    landings.append(square)
                    square = step(square, direction)
                continued = False
                for landing in landings:
                    for target, new_direction in king_targets(landing, taken):
                        if new_direction == direction and landing != landings[0]:
                            continue
                        continued = True
                        king_after(target, new_direction, path + (landing,), taken)
                # The C++ fork groups all landings beyond this captured piece.
                if not continued:
                    captures.extend(Move(path + (landing,), taken) for landing in landings)

            if self.board[origin - 1].islower():
                man_chain(origin, (origin,), ())
            else:
                for victim, direction in king_targets(origin, ()):
                    king_after(victim, direction, (origin,), ())
        if captures:
            return sorted(set(captures), key=lambda m: (m.path, m.captured))
        quiets = []
        for origin in own:
            piece = self.board[origin - 1]
            directions = range(4) if piece.isupper() else (range(2) if self.turn == "W" else range(2, 4))
            for direction in directions:
                square = step(origin, direction)
                while square is not None and self.board[square - 1] == "e":
                    quiets.append(Move((origin, square)))
                    if piece.islower():
                        break
                    square = step(square, direction)
        return quiets

    def find_hub(self, token):
        if not re.fullmatch(r"\d+(?:-\d+|(?:x\d+)+)", token):
            raise ValueError(f"Invalid engine move: {token}")
        numbers = tuple(map(int, re.split("[-x]", token)))
        capture = "x" in token
        wanted = set(numbers[2:])
        matches = [m for m in self.legal_moves() if m.origin == numbers[0] and
                   m.destination == numbers[1] and bool(m.captured) == capture and
                   (not wanted or set(m.captured) == wanted)]
        keys = {m.hub for m in matches}
        if len(keys) != 1:
            raise ValueError(f"Illegal or ambiguous engine move: {token}")
        return min(matches, key=lambda m: m.path)

    def find_pdn(self, token):
        token = token.replace(":", "x").replace("X", "x")
        if not re.fullmatch(r"\d+(?:-\d+|(?:x\d+)+)", token):
            raise ValueError(f"Invalid PDN move: {token}")
        numbers = tuple(map(int, re.split("[-x]", token)))
        if any(not 1 <= n <= 50 for n in numbers):
            raise ValueError("PDN squares must be between 1 and 50")
        capture = "x" in token
        matches = [m for m in self.legal_moves() if bool(m.captured) == capture and
                   (m.path == numbers or (len(numbers) == 2 and m.origin == numbers[0] and
                                         m.destination == numbers[1]))]
        if len({m.hub for m in matches}) != 1:
            raise ValueError(f"Illegal or ambiguous PDN move {token}; use the full landing path")
        return min(matches, key=lambda m: m.path)


@dataclass
class Turn:
    token: str
    comment: str = ""
    move: Move | None = None

    def annotation(self, name):
        found = re.search(r"\[%" + re.escape(name) + r"\s+([^\]]+)\]", self.comment)
        return found[1].strip() if found else None


@dataclass
class Game:
    tags: dict = field(default_factory=dict)
    turns: list = field(default_factory=list)
    positions: list = field(default_factory=list)

    def prepare(self):
        variant = self.tags.get("Variant", "Nigerian").lower()
        if variant not in ("nigerian", "nigerian draughts"):
            raise ValueError(f"This player supports the Nigerian variant; file says {variant}")
        if self.tags.get("BoardSize", "10") not in ("10", "10x10"):
            raise ValueError("This player uses a 10×10 board")
        position = Position.parse(self.tags.get("FEN", START))
        self.positions = [position]
        for index, turn in enumerate(self.turns, 1):
            try:
                if position.material_draw:
                    raise ValueError("Moves continue after the Nigerian material draw")
                turn.move = position.find_pdn(turn.token)
                position = position.play(turn.move)
            except ValueError as exc:
                raise ValueError(f"Game {self.tags.get('Round', '?')}, ply {index}: {exc}") from exc
            self.positions.append(position)
        count = self.tags.get("PlyCount")
        if count is not None and int(count) != len(self.turns):
            raise ValueError("PDN PlyCount does not match its moves")
        return self


TOKEN = re.compile(r'\[(?:[^"\]]|"(?:\\.|[^"\\])*")*\]|\{[^}]*\}|;[^\n]*|\(|\)|1/2-1/2|1-0|0-1|\*|\d+\.(?:\.\.)?|\$\d+|\d+(?:[-xX:]\d+)+[!?]*|\S+', re.S)
TAG = re.compile(r'^\[([A-Za-z][A-Za-z0-9_]*)\s+"((?:\\.|[^"\\])*)"\]$')
RESULTS = {"1-0", "0-1", "1/2-1/2", "*"}


def read_pdn(text):
    """Read mainlines, comments, FEN starts, NAGs and multiple games; skip variations."""
    games, game, variation = [], Game(), 0
    for match in TOKEN.finditer(text.lstrip("\ufeff")):
        token = match[0]
        if token == "(":
            variation += 1
            continue
        if token == ")":
            variation -= 1
            if variation < 0:
                raise ValueError("Unmatched PDN variation parenthesis")
            continue
        if variation:
            continue
        if token.startswith("["):
            tag = TAG.fullmatch(token)
            if not tag:
                raise ValueError(f"Invalid PDN header: {token}")
            if game.turns:
                games.append(game.prepare())
                game = Game()
            game.tags[tag[1]] = re.sub(r'\\([\\"])', r'\1', tag[2])
        elif token.startswith(("{", ";")):
            if game.turns:
                comment = token[1:-1] if token.startswith("{") else token[1:]
                game.turns[-1].comment += " " + comment.strip()
        elif token in RESULTS:
            if game.tags.get("Result", token) != token:
                raise ValueError("PDN header and movetext results disagree")
            game.tags["Result"] = token
            games.append(game.prepare())
            game = Game()
        elif re.fullmatch(r"\d+\.(?:\.\.)?|\$\d+|[!?]+", token):
            continue
        elif re.fullmatch(r"\d+(?:[-xX:]\d+)+[!?]*", token):
            game.turns.append(Turn(token.rstrip("!?")))
        else:
            raise ValueError(f"Unexpected PDN text: {token[:70]}")
    if variation:
        raise ValueError("Unclosed PDN variation")
    if game.turns or game.tags:
        games.append(game.prepare())
    if not games:
        raise ValueError("No games found in the PDN file")
    return games
