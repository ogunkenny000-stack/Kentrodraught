"""Export the recorded challenge; verify each conversion against its recorded boards."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re

from draughts import Position, read_pdn


def export(report_path, output):
    report = json.loads(report_path.read_text())
    if report['status'] != 'completed' or len(report['games']) != 10:
        raise ValueError('Expected the complete ten-game challenge')
    output.mkdir(parents=True, exist_ok=True)
    combined, summaries = [], []
    total = 0
    for game in report['games']:
        number = game['number']
        opening = report['openings'][game['pair'] - 1]
        records = [{'move': m, 'opening': True} for m in opening['moves']] + game['moves']
        source_log = report_path.parent / f'game-{number:02d}' / f'game-{number:02d}.log'
        logged = {int(ply): position for ply, position in
                  re.findall(r'^ply=(\d+) engine=\S+ position=(\S+)$', source_log.read_text(), re.M)}
        names = {'candidate': 'Rust (GitHub build)', 'cpp': 'Original C++'}
        tags = {
            'Event': 'Rust vs C++ challenge', 'Site': 'Cloud challenge', 'Date': '2026.10.23',
            'Round': str(number), 'White': names[game['white']], 'Black': names[game['black']],
            'Result': game['result'], 'Variant': 'Nigerian', 'BoardSize': '10',
            'PlyCount': str(len(records)), 'OpeningPlyCount': str(len(opening['moves'])),
            'MoveTime': '1.0 seconds per searched move', 'Termination': game['reason'],
            'WhiteEngineSHA256': report['binaries'][game['white']]['sha256'],
            'BlackEngineSHA256': report['binaries'][game['black']]['sha256'],
        }
        def escape(value):
            return value.replace('\\', '\\\\').replace('"', '\\"')
        lines = [f'[{key} "{escape(value)}"]' for key, value in tags.items()] + ['']
        position = Position.parse()
        rows, expected_positions = [], [position.hub]
        for ply, record in enumerate(records, 1):
            before = position
            if ply in logged:
                assert before.hub == logged[ply], (number, ply, 'recorded board mismatch')
            move = position.find_hub(record['move'])
            position = position.play(move)
            expected_positions.append(position.hub)
            if ply == len(opening['moves']):
                assert position.hub == opening['position']
            if ply + 1 in logged:
                assert position.hub == logged[ply + 1], (number, ply, 'successor mismatch')
            side = 'White' if before.turn == 'W' else 'Black'
            engine = 'Preset opening' if record.get('opening') else names[record['engine']]
            info = record.get('info', {})
            comment = 'Preset opening; no engine thinking time' if record.get('opening') else ''
            if info.get('score') is not None:
                comment += f" [%score_mover {info['score']}]"
            if info.get('depth') is not None:
                comment += f" [%depth {info['depth']}]"
            if 'seconds' in record:
                comment += f" [%seconds {record['seconds']:.6f}]"
            move_number = (ply + 1) // 2
            prefix = f'{move_number}.' if before.turn == 'W' else f'{move_number}...'
            lines.append(f'{prefix} {move.pdn}' + (f' {{{comment.strip()}}}' if comment.strip() else ''))
            rows.append({
                'game': number, 'ply': ply, 'move_number': move_number, 'side': side,
                'player': engine, 'pdn_move': move.pdn, 'engine_move': record['move'],
                'captured_squares': ' '.join(map(str, move.captured)),
                'landing_path': ' '.join(map(str, move.path)),
                'promotion': before.board[move.origin - 1].islower() and position.board[move.destination - 1].isupper(),
                'score_for_mover': info.get('score', ''), 'depth': info.get('depth', ''),
                'thinking_seconds': record.get('seconds', ''), 'preset_opening': bool(record.get('opening')),
                'position_before': before.fen, 'position_after': position.fen,
            })
        assert position.hub == game['current_position'], (number, 'wrong final board')
        assert position.material_draw and game['reason'] == 'material draw'
        lines += [game['result'], '']
        pdn = '\n'.join(lines) + '\n'
        reread = read_pdn(pdn)
        assert len(reread) == 1 and [p.hub for p in reread[0].positions] == expected_positions
        (output / f'game-{number:02d}.pdn').write_text(pdn, encoding='utf-8')
        with (output / f'game-{number:02d}-moves.csv').open('w', newline='', encoding='utf-8') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        summaries.append({'game': number, 'white': tags['White'], 'black': tags['Black'],
                          'result': tags['Result'], 'plies': len(rows),
                          'pdn': f'game-{number:02d}.pdn', 'moves': f'game-{number:02d}-moves.csv'})
        combined.append(pdn)
        total += len(rows)
        print(f'Game {number:02d}: verified {len(rows)} plies, final board and PDN round trip', flush=True)
    (output / 'all-games.pdn').write_text('\n'.join(combined), encoding='utf-8')
    assert len(read_pdn('\n'.join(combined))) == 10
    manifest = {'games': summaries, 'total_plies': total, 'summary': report['summary'],
                'binaries': {('rust' if name == 'candidate' else name): {'sha256': data['sha256']}
                             for name, data in report['binaries'].items()},
                'source_report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
                'validation': 'Every position matched recorded challenge boards; proper PDN landing paths round-tripped.'}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).parent / 'games')
    args = parser.parse_args()
    export(args.report, args.output)
