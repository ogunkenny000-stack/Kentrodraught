# Nigerian Draughts - Rust

This clean package contains the current engine, GUI, complete Rust source,
trained evaluation data, and license. Old comparison binaries, research scripts,
and match logs have been removed.

## Run on Linux x86-64

The supplied binaries were optimized for the cloud CPU. Rebuild from source
on other platforms or processors if needed.

    chmod +x bin/scan_nigerian bin/nigerian-draughts-gui
    ./bin/scan_nigerian

For HUB protocol mode:

    ./bin/scan_nigerian hub

For the graphical interface (requires a working X11 display):

    ./bin/nigerian-draughts-gui

## Build from source

Use a Rust toolchain supporting edition 2024. From this folder:

    cd source
    cargo build --release --locked --bin scan_nigerian

To build the GUI, install the platform's X11 development libraries and run:

    cargo build --release --locked --features gui --bin nigerian-draughts-gui

The trained evaluation data is embedded into each executable at compile time.
The source/data/eval_nigerian file is retained so the source can be rebuilt.

The C++ game rules and existing evaluator architecture are preserved.
The supplied source, engine, GUI, and trained weights are unchanged from the
previous package. Only packaging and this README have changed.

Recorded validation: all 335 tactical certificates passed. At one second per
move, the final ten-game C++ comparison was 4 wins, 2 losses, and 4 draws.
The requested seven-win target was not reached in that comparison.

License: GPL-3.0-or-later. See the source LICENSE and source attribution.
