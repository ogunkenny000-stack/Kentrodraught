//! Bounded terminal proof search. Zero is unknown, never evidence of a draw.
//! Every nonzero result follows only legal moves and actual terminal rules.
use crate::board::{Move, Position};
use crate::search::hash;
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Instant,
};

#[derive(Clone, Copy, Default)]
struct Entry {
    key: u64,
    score: i16,
    depth: i16,
    bound: u8,
}
pub struct Prover {
    table: Vec<Entry>,
    buffers: Vec<Vec<Move>>,
    pub nodes: u64,
    deadline: Instant,
    stop: Arc<AtomicBool>,
    node_limit: u64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;
    #[test]
    fn certifies_terminal_win_instead_of_static_advantage() {
        let p = Position::parse("Weeeeeeeeeeeeeeeeeeweeewweeeweebebeeeeweeeeeeeeeeee").unwrap();
        let mut prover = Prover::new(
            Instant::now() + Duration::from_secs(1),
            Arc::new(AtomicBool::new(false)),
            100_000,
        );
        let (m, score) = prover.root(p, 9, &mut Vec::new(), &p.moves()).unwrap();
        assert_eq!(m.to_string(), "28x39x33");
        assert!(score > 8000);
    }
    #[test]
    fn respects_actual_draws_and_full_repetition_history() {
        let draw = Position::parse("W:WK46:B1,2,3").unwrap();
        let live = Position::parse("W:WK46:B1,2,3,4").unwrap();
        let mut prover = Prover::new(
            Instant::now() + Duration::from_secs(1),
            Arc::new(AtomicBool::new(false)),
            100_000,
        );
        assert_eq!(
            prover.solve(draw, 9, -10000, 10000, 0, &mut Vec::new()),
            Some(0)
        );
        assert_eq!(
            prover.solve(live, 9, -10000, 10000, 0, &mut vec![live, live]),
            Some(0)
        );
    }
    #[test]
    fn unfinished_work_never_certifies_a_win() {
        let p = Position::default();
        let mut prover = Prover::new(
            Instant::now() + Duration::from_secs(1),
            Arc::new(AtomicBool::new(false)),
            0,
        );
        assert!(prover.root(p, 9, &mut Vec::new(), &p.moves()).is_none());
    }
}
impl Prover {
    pub fn new(deadline: Instant, stop: Arc<AtomicBool>, node_limit: u64) -> Self {
        Self {
            table: vec![Entry::default(); 65536],
            buffers: (0..80).map(|_| Vec::with_capacity(16)).collect(),
            nodes: 0,
            deadline,
            stop,
            node_limit,
        }
    }
    pub fn root(
        &mut self,
        p: Position,
        depth: i16,
        path: &mut Vec<Position>,
        ordered: &[Move],
    ) -> Option<(Move, i32)> {
        path.push(p);
        for &m in ordered {
            let s = self.solve(p.play(m), depth - 1, -10000, 10000, 1, path);
            if let Some(s) = s {
                if s < -8000 {
                    path.pop();
                    return Some((m, -s));
                }
            } else {
                break;
            }
        }
        path.pop();
        None
    }
    #[allow(clippy::too_many_arguments)]
    fn solve(
        &mut self,
        p: Position,
        depth: i16,
        mut alpha: i32,
        beta: i32,
        ply: usize,
        path: &mut Vec<Position>,
    ) -> Option<i32> {
        if self.nodes >= self.node_limit {
            return None;
        }
        self.nodes += 1;
        if self.nodes & 63 == 0
            && (Instant::now() >= self.deadline || self.stop.load(Ordering::Relaxed))
        {
            return None;
        }
        if p.material_draw() || path.iter().filter(|&&q| q == p).count() >= 2 {
            return Some(0);
        }
        let mut moves = std::mem::take(&mut self.buffers[ply]);
        p.generate(&mut moves);
        if moves.is_empty() {
            self.buffers[ply] = moves;
            return Some(-10000 + ply as i32);
        }
        if ply >= 78 || depth <= 0 && !moves[0].is_capture() {
            self.buffers[ply] = moves;
            return Some(0);
        }
        // Every man move changes the men bitboards or material. Such positions
        // cannot repeat. King positions retain their full path and bypass TT.
        let cache = p.kings == [0, 0];
        let key = hash(p);
        let slot = key as usize & 65535;
        let e = self.table[slot];
        if cache && e.bound != 0 && e.key == key && e.depth == depth {
            let s = if e.score > 8000 {
                i32::from(e.score) - ply as i32
            } else if e.score < -8000 {
                i32::from(e.score) + ply as i32
            } else {
                i32::from(e.score)
            };
            if e.bound == 1 || e.bound == 2 && s >= beta || e.bound == 3 && s <= alpha {
                self.buffers[ply] = moves;
                return Some(s);
            }
        }
        let original = alpha;
        let mut best = -10000;
        path.push(p);
        for &m in &moves {
            let child = self.solve(p.play(m), depth - 1, -beta, -alpha, ply + 1, path);
            let Some(score) = child else {
                path.pop();
                self.buffers[ply] = moves;
                return None;
            };
            best = best.max(-score);
            alpha = alpha.max(best);
            if alpha >= beta {
                break;
            }
        }
        path.pop();
        self.buffers[ply] = moves;
        if cache {
            let score = if best > 8000 {
                best + ply as i32
            } else if best < -8000 {
                best - ply as i32
            } else {
                best
            };
            self.table[slot] = Entry {
                key,
                score: score as i16,
                depth,
                bound: if best >= beta {
                    2
                } else if best <= original {
                    3
                } else {
                    1
                },
            };
        }
        Some(best)
    }
}
