//! SCAN's selective quiet exchange generator, used only at search leaves.
//! These are ordinary legal moves; the mandatory-capture generator is unchanged.
use crate::board::{Move, Position, SPARSE, bits};

const fn mask(file: usize, rank: usize) -> u64 {
    let mut b = 0;
    let mut i = 0;
    while i < 50 {
        if (i % 5) * 2 + 1 - (i / 5) % 2 == file || i / 5 == rank {
            b |= 1 << SPARSE[i];
        }
        i += 1;
    }
    b
}

pub fn generate(p: Position, out: &mut Vec<Move>) {
    let mp = p.men[p.turn];
    let op = p.side(p.turn ^ 1);
    let e = p.empty();
    let weak = ((mp << 7) & (e << 14))
        | ((mp << 6) & (e << 12))
        | ((mp >> 6) & (e >> 12))
        | ((mp >> 7) & (e >> 14));
    let pin = ((mp << 7) & (op << 14))
        | ((mp << 6) & (op << 12))
        | ((mp >> 6) & (op >> 12))
        | ((mp >> 7) & (op >> 14));
    let danger_i = ((op << 6) & (e >> 6)) | ((op >> 6) & (e << 6));
    let danger_j = ((op << 7) & (e >> 7)) | ((op >> 7) & (e << 7));
    if p.turn == 0 {
        let strong = ((mask(1, 8) | (mp >> 12)) & (mp >> 6) & (e << 6))
            | ((mask(8, 8) | (mp >> 14)) & (mp >> 7) & (e << 7));
        let target = strong & !weak;
        let opp_weak = ((op << 6) & (e << 12)) | ((op << 7) & (e << 14));
        let opp_pin = ((op >> 6) & (mp >> 12)) | ((op >> 7) & (mp >> 14));
        let opp_target = op & opp_weak & opp_pin;
        let mut wi = (target >> 6) & (op << 6) & !danger_j;
        let mut wj = (target >> 7) & (op << 7) & !danger_i;
        wi |= !(op << 6) & (op << 7) & ((e & target) >> 7);
        wj |= !(op << 7) & (op << 6) & ((e & target) >> 6);
        wi |= !(op << 6) & (op >> 7) & ((e & target) << 7);
        wj |= !(op << 7) & (op >> 6) & ((e & target) << 6);
        wi |= ((mp & !weak) >> 6) & (opp_target << 6) & !danger_j;
        wj |= ((mp & !weak) >> 7) & (opp_target << 7) & !danger_i;
        wi &= ((mp & !pin) >> 6) & e;
        wj &= ((mp & !pin) >> 7) & e;
        for to in bits(wi) {
            out.push(Move::new(to + 6, to, 0));
        }
        for to in bits(wj) {
            out.push(Move::new(to + 7, to, 0));
        }
    } else {
        let strong = ((mask(1, 1) | (mp << 14)) & (mp << 7) & (e >> 7))
            | ((mask(8, 1) | (mp << 12)) & (mp << 6) & (e >> 6));
        let target = strong & !weak;
        let opp_weak = ((op >> 6) & (e >> 12)) | ((op >> 7) & (e >> 14));
        let opp_pin = ((op << 6) & (mp << 12)) | ((op << 7) & (mp << 14));
        let opp_target = op & opp_weak & opp_pin;
        let mut bi = (target << 6) & (op >> 6) & !danger_j;
        let mut bj = (target << 7) & (op >> 7) & !danger_i;
        bi |= !(op >> 6) & (op >> 7) & ((e & target) << 7);
        bj |= !(op >> 7) & (op >> 6) & ((e & target) << 6);
        bi |= !(op >> 6) & (op << 7) & ((e & target) >> 7);
        bj |= !(op >> 7) & (op << 6) & ((e & target) >> 6);
        bi |= ((mp & !weak) << 6) & (opp_target >> 6) & !danger_j;
        bj |= ((mp & !weak) << 7) & (opp_target >> 7) & !danger_i;
        bi &= ((mp & !pin) << 6) & e;
        bj &= ((mp & !pin) << 7) & e;
        for to in bits(bi) {
            out.push(Move::new(to - 6, to, 0));
        }
        for to in bits(bj) {
            out.push(Move::new(to - 7, to, 0));
        }
    }
}
