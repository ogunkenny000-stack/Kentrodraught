use draughts::{
    board::{Position, perft},
    search::{Limits, Search},
};
use std::{
    collections::HashMap,
    io::{self, BufRead, Write},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    thread::{self, JoinHandle},
    time::Duration,
};

fn output(s: impl AsRef<str>) {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let _ = writeln!(out, "{}", s.as_ref());
    let _ = out.flush();
}
fn fields(line: &str) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    let mut token = String::new();
    let mut quote = false;
    for c in line.chars() {
        if c == '"' {
            quote = !quote;
        } else if c.is_whitespace() && !quote {
            if !token.is_empty() {
                out.push(std::mem::take(&mut token));
            }
        } else {
            token.push(c);
        }
    }
    if quote {
        return Err("unterminated quote".into());
    }
    if !token.is_empty() {
        out.push(token);
    }
    Ok(out)
}
fn params(tokens: &[String]) -> HashMap<&str, &str> {
    tokens
        .iter()
        .map(|s| s.split_once('=').unwrap_or((s, "")))
        .collect()
}
fn finish(
    job: &mut Option<JoinHandle<Search>>,
    engine: &mut Option<Search>,
    stop: &Arc<AtomicBool>,
) {
    if let Some(j) = job.take() {
        stop.store(true, Ordering::Relaxed);
        *engine = Some(j.join().expect("search worker panicked"));
    }
}
fn main() {
    if let Err(e) = run() {
        eprintln!("{e}");
        std::process::exit(1);
    }
}
fn run() -> Result<(), String> {
    let args: Vec<_> = std::env::args().collect();
    if args.get(1).is_some_and(|s| s == "--help") {
        println!(
            "scan_nigerian [hub | perft DEPTH [FEN] | eval FEN]\nNo arguments: Rust terminal game. HUB protocol uses SCAN square numbering."
        );
        return Ok(());
    }
    if args.get(1).is_some_and(|s| s == "perft") {
        let depth = args
            .get(2)
            .ok_or("missing depth")?
            .parse::<u8>()
            .map_err(|_| "bad depth")?;
        if depth > 12 {
            return Err("perft depth must be <=12".into());
        }
        let p = args
            .get(3)
            .map(|s| Position::parse(s))
            .transpose()?
            .unwrap_or_default();
        println!("{}", perft(p, depth));
        return Ok(());
    }
    if args.get(1).is_some_and(|s| s == "eval") {
        let p = Position::parse(args.get(2).ok_or("missing position")?)?;
        println!("{}", draughts::eval::Evaluator::new().evaluate(p));
        return Ok(());
    }
    let hub = args.get(1).is_some_and(|s| s == "hub");
    if args.len() > 1 && !hub {
        return Err("use --help for usage".into());
    }
    let mut engine = Some(Search::new(64));
    let stop = engine.as_ref().unwrap().stop.clone();
    let mut job = None;
    let mut p = Position::default();
    let mut history = Vec::new();
    let mut limits = Limits::default();
    let mut initialized = false;
    if !hub {
        output(
            "Nigerian Draughts — Rust\nCommands: board, moves, play 31-26, go, new, undo, fen <FEN>, time <seconds>, depth <n>, quit.\nSquares use SCAN numbering.",
        );
        output(p.display());
    }
    for line in io::stdin().lock().lines() {
        let line = line.map_err(|e| e.to_string())?;
        let tokens = match fields(&line) {
            Ok(t) => t,
            Err(e) => {
                output(format!("error message=\"{e}\""));
                continue;
            }
        };
        let Some(command) = tokens.first().map(String::as_str) else {
            continue;
        };
        let kv = params(&tokens[1..]);
        if command == "stop" {
            stop.store(true, Ordering::Relaxed);
            continue;
        }
        if command == "ping" {
            output("pong");
            continue;
        }
        if command == "ponder-hit" {
            continue;
        }
        if command == "quit" || command == "q" {
            break;
        }
        finish(&mut job, &mut engine, &stop);
        let result: Result<(), String> = (|| {
            let eng = engine.as_mut().unwrap();
            match command {
                "hub" => {
                    output(concat!(
                        "id name=\"Nigerian Draughts Rust\" version=",
                        env!("CARGO_PKG_VERSION"),
                        " author=\"Rust port; SCAN by Fabien Letouzey\""
                    ));
                    output("param name=variant value=nigerian type=enum values=nigerian");
                    output("param name=eval value=pattern type=enum values=\"pst pattern\"");
                    output("param name=threads value=1 type=int min=1 max=1");
                    output("param name=book value=false type=bool");
                    output("param name=bb-size value=0 type=int min=0 max=0");
                    output("wait");
                }
                "init" => {
                    initialized = true;
                    output("ready");
                }
                "set-param" => {
                    let name = *kv.get("name").ok_or("missing name")?;
                    let value = *kv.get("value").ok_or("missing value")?;
                    match (name, value) {
                        ("variant", "nigerian")
                        | ("book", "false")
                        | ("bb-size", "0")
                        | ("threads", "1")
                        | ("ponder", "false") => (),
                        ("eval", "pattern") => {
                            eng.simple = false;
                            eng.clear();
                        }
                        ("eval", "pst") => {
                            eng.simple = true;
                            eng.clear();
                        }
                        ("tt-size", v) => {
                            let n = v.parse::<u32>().map_err(|_| "bad tt-size")?;
                            if !(16..=24).contains(&n) {
                                return Err("tt-size supported range is 16..24".into());
                            }
                            let simple = eng.simple;
                            let mut new = Search::new(((1usize << n) * 16 / 1024 / 1024).max(1));
                            new.stop = stop.clone();
                            new.simple = simple;
                            *eng = new;
                        }
                        ("book-ply", _) | ("book-margin", _) => (),
                        _ => return Err(format!("unsupported parameter {name}={value}")),
                    }
                }
                "new-game" => {
                    eng.clear();
                }
                "new" => {
                    p = Position::default();
                    history.clear();
                    eng.clear();
                    output(p.display());
                }
                "pos" => {
                    let mut next = if kv.contains_key("start") {
                        Position::default()
                    } else if let Some(s) = kv.get("pos") {
                        Position::parse(s)?
                    } else {
                        Position::default()
                    };
                    let mut past = Vec::new();
                    if let Some(moves) = kv.get("moves") {
                        for text in moves.split_whitespace() {
                            let mv = next.find_move(text)?;
                            past.push(next);
                            next = next.play(mv);
                        }
                    }
                    p = next;
                    history = past;
                    limits = Limits::default();
                }
                "fen" => {
                    p = Position::parse(tokens.get(1).ok_or("missing FEN")?)?;
                    history.clear();
                    output(p.display());
                }
                "level" => {
                    if let Some(d) = kv.get("depth") {
                        limits.depth = d.parse::<u8>().map_err(|_| "invalid depth")?.clamp(1, 96);
                    }
                    if let Some(n) = kv.get("nodes") {
                        limits.nodes = n.parse().map_err(|_| "invalid nodes")?;
                    }
                    if let Some(t) = kv.get("move-time") {
                        limits.time = seconds(t)?;
                    }
                    if let Some(t) = kv.get("time") {
                        let total = seconds(t)?.as_secs_f64();
                        let moves = kv
                            .get("moves")
                            .map(|s| s.parse::<f64>())
                            .transpose()
                            .map_err(|_| "invalid moves")?
                            .unwrap_or(30.)
                            .max(1.);
                        let inc = kv
                            .get("inc")
                            .map(|s| s.parse::<f64>())
                            .transpose()
                            .map_err(|_| "invalid increment")?
                            .unwrap_or(0.);
                        limits.time = Duration::from_secs_f64(
                            (total / moves + inc * 0.8).clamp(0.001, total.max(0.001)),
                        );
                    }
                    for name in kv.keys() {
                        if ![
                            "depth",
                            "nodes",
                            "move-time",
                            "time",
                            "moves",
                            "inc",
                            "think",
                        ]
                        .contains(name)
                        {
                            return Err(format!("unsupported level option {name}"));
                        }
                    }
                }
                "time" => {
                    limits.time = seconds(tokens.get(1).ok_or("missing time")?)?;
                }
                "depth" => {
                    limits.depth = tokens
                        .get(1)
                        .ok_or("missing depth")?
                        .parse::<u8>()
                        .map_err(|_| "bad depth")?
                        .clamp(1, 96);
                }
                "moves" => {
                    output(
                        p.moves()
                            .iter()
                            .map(ToString::to_string)
                            .collect::<Vec<_>>()
                            .join(" "),
                    );
                }
                "board" | "b" => output(p.display()),
                "undo" => {
                    p = history.pop().ok_or("no move to undo")?;
                    output(p.display());
                }
                "play" => {
                    if p.material_draw() {
                        return Err("game is drawn".into());
                    }
                    let mv = p.find_move(tokens.get(1).ok_or("missing move")?)?;
                    history.push(p);
                    p = p.play(mv);
                    output(p.display());
                }
                "go" => {
                    if hub && !initialized {
                        return Err("send init before go".into());
                    }
                    if kv.contains_key("ponder") {
                        return Err("ponder is not supported".into());
                    }
                    stop.store(false, Ordering::Relaxed);
                    let mut worker = engine.take().unwrap();
                    let position = p;
                    let past = history.clone();
                    let limits_now = limits.clone();
                    if hub {
                        job = Some(thread::spawn(move || {
                            let report = worker.run(position, &past, limits_now, |r| {
                                output(format!(
                                    "info depth={} score={:.2} nodes={} time={:.3} draw-preference={:.2} pv={}",
                                    r.depth,
                                    r.score as f64 / 100.,
                                    r.nodes,
                                    r.elapsed.as_secs_f64(),
                                    -f64::from(draughts::search::DRAW_PRESSURE)/100.0,
                                    r.best.map(|m| m.to_string()).unwrap_or_default()
                                ))
                            });
                            output(
                                report
                                    .best
                                    .map(|m| format!("done move={m}"))
                                    .unwrap_or_else(|| "done".into()),
                            );
                            worker
                        }));
                        limits = Limits::default();
                    } else {
                        let report = worker.run(p, &history, limits_now, |r| {
                            output(format!(
                                "depth {} score {} nodes {} time {:.3}s",
                                r.depth,
                                r.score,
                                r.nodes,
                                r.elapsed.as_secs_f64()
                            ))
                        });
                        if let Some(m) = report.best {
                            output(format!("Engine plays {m}"));
                            history.push(p);
                            p = p.play(m);
                            output(p.display());
                        } else {
                            output("Game over");
                        }
                        engine = Some(worker);
                    }
                }
                _ => return Err("unknown command".into()),
            }
            Ok(())
        })();
        if let Err(e) = result {
            output(format!("error message=\"{}\"", e.replace('"', "'")));
        }
    }
    finish(&mut job, &mut engine, &stop);
    Ok(())
}
fn seconds(s: &str) -> Result<Duration, String> {
    let t = s.parse::<f64>().map_err(|_| "invalid time")?;
    if !t.is_finite() || !(0.0..=86400.).contains(&t) {
        return Err("time must be finite, 0..86400 seconds".into());
    }
    Ok(Duration::from_secs_f64(t))
}
