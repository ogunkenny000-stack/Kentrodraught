use std::fmt;

pub const SQUARES: u64 = 0x7DF3EF9F7CFBE7DF;
pub const SPARSE: [u8; 50] = [
    0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 26, 27, 28, 29, 30, 32,
    33, 34, 35, 36, 39, 40, 41, 42, 43, 45, 46, 47, 48, 49, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62,
];
pub const DIRS: [i8; 4] = [-7, -6, 6, 7];
const RAYS: [[u64; 4]; 63] = {
    let mut rays = [[0; 4]; 63];
    let mut from = 0;
    while from < 63 {
        if SQUARES & (1 << from) != 0 {
            let mut d = 0;
            while d < 4 {
                let mut q = from as i16 + DIRS[d] as i16;
                while q >= 0 && q < 63 && SQUARES & (1 << q) != 0 {
                    rays[from][d] |= 1 << q;
                    q += DIRS[d] as i16;
                }
                d += 1;
            }
        }
        from += 1;
    }
    rays
};
struct CaptureGeometry {
    adjacent: [u64; 63],
    man: [u64; 63],
    king: [u64; 63],
    path: [[u64; 63]; 63],
    direction: [[u8; 63]; 63],
}
// Geometry is immutable and computed once at compile time. A capture path
// contains the intervening squares plus the first required landing square;
// it deliberately excludes the enemy being jumped.
static CAPTURE_GEOMETRY: CaptureGeometry = {
    let mut g = CaptureGeometry {
        adjacent: [0; 63],
        man: [0; 63],
        king: [0; 63],
        path: [[0; 63]; 63],
        direction: [[0; 63]; 63],
    };
    let mut from = 0;
    while from < 63 {
        if SQUARES & (1 << from) != 0 {
            let mut dir = 0;
            while dir < 4 {
                let step = DIRS[dir] as i16;
                let mut q = from as i16 + step;
                let mut before = 0;
                while q >= 0 && q < 63 && SQUARES & (1 << q) != 0 {
                    if q == from as i16 + step {
                        g.adjacent[from] |= 1 << q;
                    }
                    let next = q + step;
                    if next >= 0 && next < 63 && SQUARES & (1 << next) != 0 {
                        g.king[from] |= 1 << q;
                        g.path[from][q as usize] = before | (1 << next);
                        g.direction[from][q as usize] = dir as u8;
                        if q == from as i16 + step {
                            g.man[from] |= 1 << q;
                        }
                    }
                    before |= 1 << q;
                    q = next;
                }
                dir += 1;
            }
        }
        from += 1;
    }
    g
};
/// Empty king destinations, truncated at the first blocker in each direction.
#[inline]
pub fn king_quiets(from: u8, empty: u64) -> u64 {
    let mut attacks = 0;
    for d in 0..4 {
        attacks |= king_ray(from, d, empty);
    }
    attacks
}
#[inline]
fn king_ray(from: u8, d: usize, empty: u64) -> u64 {
    let ray = RAYS[from as usize][d];
    let blockers = ray & !empty;
    if blockers == 0 {
        ray
    } else {
        let q = if d < 2 {
            63 - blockers.leading_zeros()
        } else {
            blockers.trailing_zeros()
        };
        ray & !RAYS[q as usize][d] & !(1 << q)
    }
}
#[inline]
pub fn bits(mut b: u64) -> impl Iterator<Item = u8> {
    std::iter::from_fn(move || {
        if b == 0 {
            None
        } else {
            let s = b.trailing_zeros() as u8;
            b &= b - 1;
            Some(s)
        }
    })
}
pub fn valid(s: i16) -> bool {
    (0..63).contains(&s) && SQUARES & (1u64 << s) != 0
}
const DENSE: [u8; 63] = {
    let mut table = [255; 63];
    let mut i = 0;
    while i < 50 {
        table[SPARSE[i] as usize] = i as u8;
        i += 1;
    }
    table
};
pub fn dense(s: u8) -> usize {
    let d = DENSE[s as usize];
    assert!(d != 255, "valid square");
    d as usize
}
pub fn rank(s: u8) -> usize {
    dense(s) / 5
}
/// Promotion rows in SCAN's sparse numbering, for valid playable squares.
#[inline]
pub fn is_promotion(square: u8, side: usize) -> bool {
    if side == 0 { square < 5 } else { square >= 58 }
}
pub fn file(s: u8) -> usize {
    let d = dense(s);
    (d % 5) * 2 + (1 - d / 5 % 2)
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct Move(u64);
const CAPTURE_BITS: u64 = (1u64 << 50) - 1;
impl Move {
    /// Lexicographic layout: 6-bit origin, 6-bit destination, two reserved bits, 50-bit captures.
    /// Native BMI2 builds use bit extraction/deposit; other builds use scalar code.
    #[inline]
    pub fn new(from: u8, to: u8, caps: u64) -> Self {
        let captured = pack_captures(caps);
        Self((from as u64) << 58 | (to as u64) << 52 | captured)
    }
    #[inline]
    pub fn from(self) -> u8 {
        (self.0 >> 58) as u8
    }
    #[inline]
    pub fn to(self) -> u8 {
        ((self.0 >> 52) & 63) as u8
    }
    #[inline]
    pub fn is_capture(self) -> bool {
        self.0 << 14 != 0
    }
    #[inline]
    pub fn capture_count(self) -> u32 {
        (self.0 << 14).count_ones()
    }
    #[inline]
    pub fn order_key(self) -> (u8, u8, u64) {
        (self.from(), self.to(), self.0 & CAPTURE_BITS)
    }
    #[inline]
    pub fn caps(self) -> u64 {
        unpack_captures(self.0)
    }
    pub fn conversion(self, p: Position) -> bool {
        self.is_capture() || p.men[p.turn] & (1 << self.from()) != 0
    }
}
#[inline]
fn pack_captures(caps: u64) -> u64 {
    #[cfg(all(target_arch = "x86_64", target_feature = "bmi2"))]
    {
        // SAFETY: this branch only exists when the compiler's target explicitly
        // guarantees BMI2. The intrinsic accepts every pair of u64 values.
        unsafe { std::arch::x86_64::_pext_u64(caps, SQUARES) }
    }
    #[cfg(not(all(target_arch = "x86_64", target_feature = "bmi2")))]
    {
        let mut captured = 0;
        if caps != 0 {
            for rank in 0..10 {
                captured |= ((caps >> SPARSE[rank * 5]) & 31) << (rank * 5);
            }
        }
        captured
    }
}
#[inline]
fn unpack_captures(raw: u64) -> u64 {
    #[cfg(all(target_arch = "x86_64", target_feature = "bmi2"))]
    {
        // SAFETY: BMI2 is guaranteed by this build target, as above.
        unsafe { std::arch::x86_64::_pdep_u64(raw, SQUARES) }
    }
    #[cfg(not(all(target_arch = "x86_64", target_feature = "bmi2")))]
    {
        let captured = raw & CAPTURE_BITS;
        let mut caps = 0;
        if captured != 0 {
            for rank in 0..10 {
                caps |= ((captured >> (rank * 5)) & 31) << SPARSE[rank * 5];
            }
        }
        caps
    }
}
impl fmt::Display for Move {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "{}{}{}",
            dense(self.from()) + 1,
            if self.caps() == 0 { '-' } else { 'x' },
            dense(self.to()) + 1
        )?;
        for s in bits(self.caps()) {
            write!(f, "x{}", dense(s) + 1)?;
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Position {
    pub men: [u64; 2],
    pub kings: [u64; 2],
    pub turn: usize,
}
impl Default for Position {
    fn default() -> Self {
        Self {
            men: [0x7DF3EF8000000000, 0xFBE7DF],
            kings: [0; 2],
            turn: 0,
        }
    }
}
impl Position {
    #[inline]
    pub fn side(self, s: usize) -> u64 {
        self.men[s] | self.kings[s]
    }
    #[inline]
    pub fn all(self) -> u64 {
        self.side(0) | self.side(1)
    }
    #[inline]
    pub fn empty(self) -> u64 {
        SQUARES & !self.all()
    }
    pub fn hub(self) -> String {
        let mut s = String::from(if self.turn == 0 { "W" } else { "B" });
        for q in SPARSE {
            let b = 1 << q;
            s.push(if self.men[0] & b != 0 {
                'w'
            } else if self.men[1] & b != 0 {
                'b'
            } else if self.kings[0] & b != 0 {
                'W'
            } else if self.kings[1] & b != 0 {
                'B'
            } else {
                'e'
            });
        }
        s
    }
    pub fn parse(s: &str) -> Result<Self, String> {
        if s.contains(':') {
            return Self::fen(s);
        }
        if s.len() != 51 || !s.is_ascii() {
            return Err("position must have 51 ASCII characters".into());
        }
        let mut p = Self {
            men: [0; 2],
            kings: [0; 2],
            turn: match s.as_bytes()[0] {
                b'W' => 0,
                b'B' => 1,
                _ => return Err("bad turn".into()),
            },
        };
        for (i, c) in s.bytes().skip(1).enumerate() {
            let b = 1 << SPARSE[i];
            match c {
                b'w' => p.men[0] |= b,
                b'b' => p.men[1] |= b,
                b'W' => p.kings[0] |= b,
                b'B' => p.kings[1] |= b,
                b'e' => (),
                _ => return Err("bad piece".into()),
            }
        }
        p.validate()?;
        Ok(p)
    }
    pub fn fen(s: &str) -> Result<Self, String> {
        let mut fields = s.split(':');
        let turn = match fields.next() {
            Some("W") => 0,
            Some("B") => 1,
            _ => return Err("bad turn".into()),
        };
        let mut p = Self {
            men: [0; 2],
            kings: [0; 2],
            turn,
        };
        let mut sides = 0;
        for field in fields {
            let side = match field.as_bytes().first() {
                Some(b'W') => 0,
                Some(b'B') => 1,
                _ => return Err("bad side".into()),
            };
            if sides & (1 << side) != 0 {
                return Err("duplicate side".into());
            }
            sides |= 1 << side;
            for token in field[1..].split(',').filter(|x| !x.is_empty()) {
                let (king, t) = if let Some(t) = token.strip_prefix('K') {
                    (true, t)
                } else {
                    (false, token)
                };
                let mut ns = t.split('-');
                let a = ns
                    .next()
                    .unwrap_or("")
                    .parse::<usize>()
                    .map_err(|_| "bad square")?;
                let b = ns
                    .next()
                    .map(|x| x.parse::<usize>())
                    .transpose()
                    .map_err(|_| "bad range")?
                    .unwrap_or(a);
                if a == 0 || b > 50 || a > b || ns.next().is_some() {
                    return Err("bad range".into());
                }
                for q in a..=b {
                    let bit = 1 << SPARSE[q - 1];
                    if p.all() & bit != 0 {
                        return Err("overlapping pieces".into());
                    }
                    if king {
                        p.kings[side] |= bit;
                    } else {
                        p.men[side] |= bit;
                    }
                }
            }
        }
        p.validate()?;
        Ok(p)
    }
    fn validate(self) -> Result<(), String> {
        if self.men[0] & 0x1F != 0 || self.men[1] & 0x7C00000000000000 != 0 {
            return Err("man on promotion row".into());
        }
        if self.side(self.turn ^ 1) == 0 {
            return Err("opponent must have a piece".into());
        }
        Ok(())
    }
    #[inline]
    pub fn play(self, m: Move) -> Self {
        let mut p = self;
        let s = p.turn;
        let delta = (1 << m.from()) ^ (1 << m.to());
        if p.kings[s] & (1 << m.from()) != 0 {
            p.kings[s] ^= delta;
        } else if is_promotion(m.to(), s) {
            p.men[s] &= !(1 << m.from());
            p.kings[s] |= 1 << m.to();
        } else {
            p.men[s] ^= delta;
        }
        p.men[s ^ 1] &= !m.caps();
        p.kings[s ^ 1] &= !m.caps();
        p.turn ^= 1;
        p
    }
    /// Exactly the supplied fork's rules 4.1–4.4, including precedence over no-move loss.
    pub fn material_draw(self) -> bool {
        (0..2).any(|s| {
            self.men[s] == 0
                && self.kings[s].count_ones() == 1
                && self.side(s ^ 1).count_ones() <= 3
        })
    }
    pub fn moves(self) -> Vec<Move> {
        let mut out = Vec::with_capacity(32);
        self.generate(&mut out);
        out
    }
    pub fn generate(&self, out: &mut Vec<Move>) {
        self.captures(out);
        if !out.is_empty() {
            return;
        }
        let empty = self.empty();
        let men = self.men[self.turn];
        if self.turn == 0 {
            add_man_quiets::<-6>(men, empty, out);
            add_man_quiets::<-7>(men, empty, out);
        } else {
            add_man_quiets::<6>(men, empty, out);
            add_man_quiets::<7>(men, empty, out);
        }
        for from in bits(self.kings[self.turn]) {
            add_king_quiets::<0>(from, empty, out);
            add_king_quiets::<1>(from, empty, out);
            add_king_quiets::<2>(from, empty, out);
            add_king_quiets::<3>(from, empty, out);
        }
    }
    #[inline]
    pub fn has_quiet(self) -> bool {
        let empty = self.empty();
        let men = self.men[self.turn];
        if (if self.turn == 0 {
            men & ((empty << 6) | (empty << 7))
        } else {
            men & ((empty >> 6) | (empty >> 7))
        }) != 0
        {
            return true;
        }
        bits(self.kings[self.turn])
            .any(|from| CAPTURE_GEOMETRY.adjacent[from as usize] & empty != 0)
    }
    /// Capture availability without expanding or sorting complete sequences.
    /// Used only as a search predicate; legal moves still use the full generator.
    pub fn has_capture(&self, side: usize) -> bool {
        let empty = self.empty();
        let enemy = self.side(side ^ 1);
        if self.men[side]
            & (((enemy << 7) & (empty << 14))
                | ((enemy << 6) & (empty << 12))
                | ((enemy >> 6) & (empty >> 12))
                | ((enemy >> 7) & (empty >> 14)))
            != 0
        {
            return true;
        }
        bits(self.kings[side]).any(|from| {
            bits(CAPTURE_GEOMETRY.king[from as usize] & enemy)
                .any(|jump| CAPTURE_GEOMETRY.path[from as usize][jump as usize] & !empty == 0)
        })
    }
    pub fn captures(&self, out: &mut Vec<Move>) {
        out.clear();
        let empty = self.empty();
        let enemy = self.side(self.turn ^ 1);
        let men = self.men[self.turn];
        // First-capture eligibility is a single bitboard filter. Source order
        // is canonical, so only moves belonging to one source need sorting.
        let sources = men
            & (((enemy << 7) & (empty << 14))
                | ((enemy << 6) & (empty << 12))
                | ((enemy >> 6) & (empty >> 12))
                | ((enemy >> 7) & (empty >> 14)));
        let kings = self.kings[self.turn];
        for from in bits(sources | kings) {
            let begin = out.len();
            let free = empty | (1 << from);
            if kings & (1 << from) == 0 {
                // Expand the first jump here instead of retaining an extra
                // recursive frame for the entire capture chain.
                for jump in bits(CAPTURE_GEOMETRY.man[from as usize] & enemy) {
                    let to = (jump as i16 * 2 - from as i16) as u8;
                    if free & (1 << to) != 0 {
                        man_rec(from, to, enemy & !(1 << jump), free, 1 << jump, out);
                    }
                }
            } else {
                for jump in bits(CAPTURE_GEOMETRY.king[from as usize] & enemy) {
                    if CAPTURE_GEOMETRY.path[from as usize][jump as usize] & !free == 0 {
                        let dir = CAPTURE_GEOMETRY.direction[from as usize][jump as usize] as usize;
                        king_rec(from, jump, dir, enemy, free, 0, out);
                    }
                }
            }
            if out.len() > begin + 1 {
                out[begin..].sort_unstable_by_key(|m| m.0);
            }
        }
        out.dedup();
    }
    pub fn find_move(self, text: &str) -> Result<Move, String> {
        let nums: Vec<_> = text
            .split(['x', '-'])
            .map(str::parse::<usize>)
            .collect::<Result<_, _>>()
            .map_err(|_| "bad move")?;
        if nums.len() < 2 || nums.iter().any(|&x| !(1..=50).contains(&x)) {
            return Err("bad move".into());
        }
        let caps = nums[2..].iter().fold(0, |a, &x| a | (1 << SPARSE[x - 1]));
        let capture = text.contains('x');
        let moves: Vec<_> = self
            .moves()
            .into_iter()
            .filter(|m| {
                m.from() == SPARSE[nums[0] - 1]
                    && m.to() == SPARSE[nums[1] - 1]
                    && (m.is_capture()) == capture
                    && m.caps() & caps == caps
            })
            .collect();
        // Fully specified HUB capture notation identifies the exact captured
        // set, even if another legal capture has the same endpoints and more
        // captured pieces. Preserve abbreviated input when no exact set exists.
        if let Some(&exact) = moves.iter().find(|m| m.caps() == caps) {
            return Ok(exact);
        }
        if moves.len() != 1 {
            Err("illegal or ambiguous move".into())
        } else {
            Ok(moves[0])
        }
    }
    pub fn display(self) -> String {
        let s = self.hub();
        let mut out = String::new();
        for r in 0..10 {
            for c in 0..10 {
                if (r + c) % 2 == 0 {
                    out.push_str("   ");
                } else {
                    let n = r * 5 + c / 2;
                    out.push_str(&format!(
                        " {} ",
                        match s.as_bytes()[n + 1] {
                            b'e' => '.',
                            b => b as char,
                        }
                    ));
                }
            }
            out.push_str(&format!("   {}–{}\n", r * 5 + 1, r * 5 + 5));
        }
        out.push_str(if self.turn == 0 {
            "White to move\n"
        } else {
            "Black to move\n"
        });
        out
    }
}
#[inline]
fn add_man_quiets<const D: i16>(men: u64, empty: u64, out: &mut Vec<Move>) {
    let froms = if D < 0 {
        men & (empty << (-D as u32))
    } else {
        men & (empty >> (D as u32))
    };
    for from in bits(froms) {
        // from*64 + to = from*65 + D. Both squares are already checked by
        // the bitboard filter, so these indices cannot cross field boundaries.
        let index = from as i16 * 65 + D;
        out.push(Move((index as u64) << 52));
    }
}
#[inline]
fn add_king_quiets<const D: usize>(from: u8, empty: u64, out: &mut Vec<Move>) {
    let mut destinations = king_ray(from, D, empty);
    out.extend((0..destinations.count_ones()).map(|_| {
        let to = if D < 2 {
            (63 - destinations.leading_zeros()) as u8
        } else {
            destinations.trailing_zeros() as u8
        };
        destinations &= !(1 << to);
        Move::new(from, to, 0)
    }));
}
fn man_rec(start: u8, from: u8, enemy: u64, empty: u64, caps: u64, out: &mut Vec<Move>) {
    let mut found = false;
    for jump in bits(CAPTURE_GEOMETRY.man[from as usize] & enemy) {
        let to = (jump as i16 * 2 - from as i16) as u8;
        if empty & (1 << to) != 0 {
            found = true;
            man_rec(
                start,
                to,
                enemy & !(1 << jump),
                empty,
                caps | (1 << jump),
                out,
            );
        }
    }
    if !found && caps != 0 {
        out.push(Move::new(start, from, caps));
    }
}
// Captured pieces remain ghost blockers. Match the C++ fork's grouped-landing
// continuation test: if ANY landing continues, suppress ALL terminal landings.
fn king_rec(
    start: u8,
    jump: u8,
    dir: usize,
    enemy: u64,
    empty: u64,
    caps: u64,
    out: &mut Vec<Move>,
) {
    let enemy = enemy & !(1 << jump);
    let caps = caps | (1 << jump);
    let next = (jump as i16 + DIRS[dir] as i16) as u8;
    let landings = king_ray(jump, dir, empty);
    let mut found = false;
    for from in bits(landings) {
        for target in bits(CAPTURE_GEOMETRY.king[from as usize] & enemy) {
            if CAPTURE_GEOMETRY.path[from as usize][target as usize] & !empty == 0 {
                let new_dir = CAPTURE_GEOMETRY.direction[from as usize][target as usize] as usize;
                if new_dir == dir && from != next {
                    continue;
                }
                found = true;
                king_rec(start, target, new_dir, enemy, empty, caps, out);
            }
        }
    }
    if !found {
        for to in bits(landings) {
            out.push(Move::new(start, to, caps));
        }
    }
}
pub fn perft(p: Position, depth: u8) -> u64 {
    fn visit(p: Position, lists: &mut [Vec<Move>]) -> u64 {
        let Some((moves, rest)) = lists.split_first_mut() else {
            return 1;
        };
        p.generate(moves);
        moves.iter().map(|&m| visit(p.play(m), rest)).sum()
    }
    let mut lists: Vec<_> = (0..depth).map(|_| Vec::with_capacity(32)).collect();
    visit(p, &mut lists)
}

#[cfg(test)]
mod geometry_tests {
    use super::*;
    #[test]
    fn capture_tables_match_independent_board_coordinates() {
        for from in SPARSE {
            for target in SPARSE {
                let (x, y) = (file(from) as i16, rank(from) as i16);
                let (tx, ty) = (file(target) as i16, rank(target) as i16);
                let (dx, dy) = (tx - x, ty - y);
                let diagonal = dx != 0 && dx.abs() == dy.abs();
                let next = (tx + dx.signum(), ty + dy.signum());
                let can_jump = diagonal && (0..10).contains(&next.0) && (0..10).contains(&next.1);
                let mask = 1 << target;
                assert_eq!(CAPTURE_GEOMETRY.king[from as usize] & mask != 0, can_jump);
                assert_eq!(
                    CAPTURE_GEOMETRY.man[from as usize] & mask != 0,
                    can_jump && dx.abs() == 1
                );
                assert_eq!(
                    CAPTURE_GEOMETRY.adjacent[from as usize] & mask != 0,
                    diagonal && dx.abs() == 1
                );
                if can_jump {
                    let mut expected = 0;
                    let (sx, sy) = (dx.signum(), dy.signum());
                    let mut cx = x + sx;
                    let mut cy = y + sy;
                    while (cx, cy) != (tx, ty) {
                        expected |= 1 << SPARSE[(cy * 5 + cx / 2) as usize];
                        cx += sx;
                        cy += sy;
                    }
                    expected |= 1 << SPARSE[(next.1 * 5 + next.0 / 2) as usize];
                    assert_eq!(
                        CAPTURE_GEOMETRY.path[from as usize][target as usize],
                        expected
                    );
                }
            }
        }
    }
}
