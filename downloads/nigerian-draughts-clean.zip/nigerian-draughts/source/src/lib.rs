//! Nigerian rules and SCAN pattern evaluation, ported from the supplied SCAN 3.1 fork.
//! Original engine copyright Fabien Letouzey; see LICENSE.
pub mod board;
pub mod eval;
pub mod game;
pub mod search;
pub mod sacrifices;
pub mod proof;
