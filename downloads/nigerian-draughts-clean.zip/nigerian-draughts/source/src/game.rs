//! Shared game state for the native Rust interface; rules stay in board.rs.
use crate::board::{Move, Position};
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Outcome {
    Draw,
    Win(usize),
}
#[derive(Default)]
pub struct Game {
    pub position: Position,
    pub history: Vec<Position>,
    pub moves: Vec<Move>,
    pub resigned: Option<usize>,
}
impl Game {
    pub fn outcome(&self) -> Option<Outcome> {
        if let Some(side) = self.resigned {
            return Some(Outcome::Win(side ^ 1));
        }
        if self.position.material_draw()
            || self.history.iter().filter(|&&p| p == self.position).count() >= 2
        {
            return Some(Outcome::Draw);
        }
        if self.position.moves().is_empty() {
            Some(Outcome::Win(self.position.turn ^ 1))
        } else {
            None
        }
    }
    pub fn play(&mut self, m: Move) -> Result<(), String> {
        if self.outcome().is_some() {
            return Err("game is over".into());
        }
        if !self.position.moves().contains(&m) {
            return Err("illegal move".into());
        }
        self.history.push(self.position);
        self.moves.push(m);
        self.position = self.position.play(m);
        Ok(())
    }
    pub fn undo(&mut self) -> bool {
        self.resigned = None;
        if let Some(p) = self.history.pop() {
            self.position = p;
            self.moves.pop();
            true
        } else {
            false
        }
    }
    pub fn save(&self) -> String {
        let start = self.history.first().copied().unwrap_or(self.position);
        format!(
            "{}\n{}\n",
            start.hub(),
            self.moves
                .iter()
                .map(ToString::to_string)
                .collect::<Vec<_>>()
                .join(" ")
        )
    }
    pub fn load(s: &str) -> Result<Self, String> {
        let mut lines = s.lines();
        let position = Position::parse(lines.next().ok_or("missing position")?)?;
        let mut game = Self {
            position,
            ..Self::default()
        };
        for text in lines.flat_map(str::split_whitespace) {
            let m = game.position.find_move(text)?;
            game.play(m)?;
        }
        Ok(game)
    }
}
