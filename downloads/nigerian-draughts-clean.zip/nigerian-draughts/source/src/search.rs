use crate::{
    board::{Move, Position},
    eval::Evaluator,
};
use std::{
    sync::{
        Arc, LazyLock,
        atomic::{AtomicBool, Ordering},
    },
    time::{Duration, Instant},
};
const INF: i32 = 10000;
const MAX_PLY: usize = 128;
const SACRIFICES: bool = true;
const SCAN_LMR: bool = true;
const SCAN_FORWARD: bool = true;
const Q_CACHE: bool = false;
const EXTRA_PRUNING: bool = false;
const SINGULAR: bool = true;
const IID: bool = true;
const ENDGAME_GUARD: bool = true;
const THREAT_CHAIN: bool = false;
const ROOT_PROOF: bool = true;
const QUIET_PROMOTIONS: bool = false;
// Search preference only; actual draw outcomes remain unchanged.
pub const DRAW_PRESSURE: i32 = 0;
static REDUCTIONS: LazyLock<[[i16; 64]; 32]> = LazyLock::new(|| {
    std::array::from_fn(|depth| {
        std::array::from_fn(|number| {
            if depth == 0 || number == 0 {
                0
            } else {
                (0.75 + (depth as f64).ln() * (number as f64).ln() / 2.25) as i16
            }
        })
    })
});
#[derive(Clone)]
pub struct Limits {
    pub depth: u8,
    pub nodes: u64,
    pub time: Duration,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            depth: 64,
            nodes: u64::MAX,
            time: Duration::from_secs(5),
        }
    }
}
#[derive(Clone, Copy, Default)]
struct Entry {
    key: u64,
    best: u16,
    score: i16,
    depth: i8,
    bound: u8,
    generation: u8,
}
#[derive(Clone, Default)]
#[repr(align(64))]
struct Bucket([Entry; 4]);
pub struct Search {
    pub eval: Evaluator,
    table: Vec<Bucket>,
    move_buffers: Vec<Vec<Move>>,
    repetition_start: [usize; MAX_PLY],
    generation: u8,
    killers: [[Move; 2]; MAX_PLY],
    history: [[[i32; 63]; 63]; 2],
    capture_history: [[[i32; 63]; 63]; 2],
    countermoves: [[[Move; 63]; 63]; 2],
    played: [Move; MAX_PLY],
    excluded: [Move; MAX_PLY],
    pub nodes: u64,
    pub stop: Arc<AtomicBool>,
    start: Instant,
    limits: Limits,
    aborted: bool,
    pub simple: bool,
    root_turn: usize,
}
#[derive(Clone, Debug)]
pub struct Report {
    pub best: Option<Move>,
    pub score: i32,
    pub depth: u8,
    pub nodes: u64,
    pub elapsed: Duration,
}
impl Search {
    pub fn new(mb: usize) -> Self {
        Self {
            eval: Evaluator::new(),
            table: vec![
                Bucket::default();
                1usize
                    << (mb.clamp(1, 512) * 1024 * 1024 / std::mem::size_of::<Bucket>())
                        .ilog2()
            ],
            move_buffers: (0..MAX_PLY).map(|_| Vec::with_capacity(32)).collect(),
            repetition_start: [0; MAX_PLY],
            generation: 0,
            killers: [[Move::default(); 2]; MAX_PLY],
            history: [[[0; 63]; 63]; 2],
            capture_history: [[[0; 63]; 63]; 2],
            countermoves: [[[Move::default(); 63]; 63]; 2],
            played: [Move::default(); MAX_PLY],
            excluded: [Move::default(); MAX_PLY],
            nodes: 0,
            stop: Arc::new(AtomicBool::new(false)),
            start: Instant::now(),
            limits: Limits::default(),
            aborted: false,
            simple: false,
            root_turn: 0,
        }
    }
    pub fn clear(&mut self) {
        self.table.fill(Bucket::default());
        self.history = [[[0; 63]; 63]; 2];
        self.capture_history = [[[0; 63]; 63]; 2];
        self.countermoves = [[[Move::default(); 63]; 63]; 2];
    }
    pub fn run(
        &mut self,
        p: Position,
        history: &[Position],
        limits: Limits,
        mut progress: impl FnMut(&Report),
    ) -> Report {
        self.start = Instant::now();
        self.root_turn = p.turn;
        self.limits = limits;
        self.nodes = 0;
        self.aborted = false;
        self.played.fill(Move::default());
        self.excluded.fill(Move::default());
        self.generation = self.generation.wrapping_add(1);
        // Caller owns the stop flag, so a stop received immediately after go is not lost.
        for side in &mut self.history {
            for from in side {
                for value in from {
                    *value /= 2;
                }
            }
        }
        self.killers = [[Move::default(); 2]; MAX_PLY];
        let legal = p.moves();
        let mut result = Report {
            best: legal.first().copied(),
            score: 0,
            depth: 0,
            nodes: 0,
            elapsed: Duration::ZERO,
        };
        if p.material_draw() || repeated(p, history) || legal.is_empty() {
            result.best = None;
            result.score = if legal.is_empty() && !p.material_draw() {
                -INF
            } else {
                0
            };
            return result;
        }
        let mut path = history.to_vec();
        if path.last() == Some(&p) {
            path.pop();
        }
        // Men only move forward without capturing; captures/promotion change
        // material. No position before that conversion can ever repeat.
        let mut root_reversible = 0;
        let mut previous = None;
        for (i, &current) in path.iter().chain(std::iter::once(&p)).enumerate() {
            if let Some(prior) = previous {
                let prior: Position = prior;
                if prior.men != current.men
                    || prior.all().count_ones() != current.all().count_ones()
                {
                    root_reversible = i;
                }
            }
            previous = Some(current);
        }
        let key = hash(p);
        let mut order = legal;
        if ROOT_PROOF
            && !self.stop.load(Ordering::Relaxed)
            && p.all().count_ones() <= 10
            && self.limits.depth >= 9
        {
            let allocation = (self.limits.time / 20).min(Duration::from_millis(50));
            let mut proof = crate::proof::Prover::new(
                self.start + allocation,
                self.stop.clone(),
                self.limits.nodes.saturating_sub(self.nodes).min(250_000),
            );
            for d in [5, 7, 9, 11, 13, 15] {
                if d > i16::from(self.limits.depth) || self.start.elapsed() >= allocation {
                    break;
                }
                if let Some((best, score)) = proof.root(p, d, &mut path, &order) {
                    result = Report {
                        best: Some(best),
                        score,
                        depth: d as u8,
                        nodes: proof.nodes,
                        elapsed: self.start.elapsed(),
                    };
                    progress(&result);
                    return result;
                }
            }
            self.nodes += proof.nodes;
        }
        let mut effort = vec![0u64; order.len()];
        'iterations: for depth in 1..=self.limits.depth.min(96) {
            let prior = result.best;
            let mut indexes: Vec<_> = (0..order.len()).collect();
            indexes.sort_by_key(|&i| {
                std::cmp::Reverse((Some(order[i]) == prior, effort[i], order[i].capture_count()))
            });
            order = indexes.iter().map(|&i| order[i]).collect();
            effort.fill(0);
            // Failed aspiration attempts are bounds, never completed reports.
            // Widen in both directions until a full result fits the window.
            let mut margin = if depth >= 5 { 8 } else { INF };
            let (best, score) = loop {
                let (low, high) = if margin >= INF {
                    (-INF, INF)
                } else {
                    (
                        (result.score - margin).max(-INF),
                        (result.score + margin).min(INF),
                    )
                };
                let mut alpha = low;
                let mut best_score = -INF;
                let mut best = order[0];
                path.push(p);
                for (i, &m) in order.iter().enumerate() {
                    self.repetition_start[1] = if m.conversion(p) {
                        path.len()
                    } else {
                        root_reversible
                    };
                    let child = p.play(m);
                    self.played[0] = m;
                    let child_key = successor_hash(key, p, m);
                    let before = self.nodes;
                    let mut score;
                    if i == 0 {
                        score = -self.ab(
                            child,
                            child_key,
                            depth as i16 - 1,
                            -high,
                            -alpha,
                            1,
                            &mut path,
                            true,
                        );
                    } else {
                        score = -self.ab(
                            child,
                            child_key,
                            depth as i16 - 1,
                            -alpha - 1,
                            -alpha,
                            1,
                            &mut path,
                            true,
                        );
                        if score > alpha && score < high && !self.aborted {
                            score = -self.ab(
                                child,
                                child_key,
                                depth as i16 - 1,
                                -high,
                                -alpha,
                                1,
                                &mut path,
                                true,
                            );
                        }
                    }
                    effort[i] += self.nodes - before;
                    if self.aborted {
                        break;
                    }
                    if score > best_score {
                        best_score = score;
                        best = m;
                    }
                    alpha = alpha.max(score);
                    if alpha >= high {
                        break;
                    }
                }
                path.pop();
                if self.aborted {
                    break 'iterations;
                }
                if best_score > low && best_score < high || margin >= INF {
                    break (best, best_score);
                }
                // Search the successful bound move first on the retry.
                let i = order.iter().position(|&m| m == best).unwrap();
                order.swap(0, i);
                effort.swap(0, i);
                margin = (margin * 2).min(INF);
            };
            result = Report {
                best: Some(best),
                score,
                depth,
                nodes: self.nodes,
                elapsed: self.start.elapsed(),
            };
            progress(&result);
            if score.abs() > 8000 || self.start.elapsed() >= self.limits.time {
                break;
            }
        }
        result.nodes = self.nodes;
        result.elapsed = self.start.elapsed();
        result
    }
    fn halted(&mut self) -> bool {
        if self.nodes >= self.limits.nodes
            || self.stop.load(Ordering::Relaxed)
            || (self.nodes & 255 == 0 && self.start.elapsed() >= self.limits.time)
        {
            self.aborted = true;
            true
        } else {
            false
        }
    }
    #[allow(clippy::too_many_arguments)]
    fn ab(
        &mut self,
        p: Position,
        key: u64,
        depth: i16,
        mut alpha: i32,
        beta: i32,
        ply: usize,
        path: &mut Vec<Position>,
        allow_pruning: bool,
    ) -> i32 {
        if self.halted() {
            return 0;
        }
        self.nodes += 1;
        let reversible = self.repetition_start[ply];
        let recent = &path[reversible..];
        if p.material_draw() || (recent.len() >= 4 && repeated(p, recent)) {
            return if p.turn == self.root_turn {
                -DRAW_PRESSURE
            } else {
                DRAW_PRESSURE
            };
        }
        // Probe before generating or sorting: a valid cutoff needs no move list.
        let excluded = self.excluded[ply];
        // Draw-preference bounds belong to one root player. Board hashes stay intact.
        let context_key = key
            ^ if DRAW_PRESSURE != 0 && self.root_turn == 1 {
                mix(715)
            } else {
                0
            };
        let table_key = if excluded != Move::default() {
            context_key
                ^ mix(excluded.caps()
                    ^ (u64::from(excluded.from()) << 50)
                    ^ (u64::from(excluded.to()) << 56))
        } else if Q_CACHE && depth <= 0 {
            context_key ^ if depth == 0 { mix(713) } else { mix(714) }
        } else {
            context_key
        };
        let mut entry = self.probe(table_key);
        let seen = recent.contains(&p);
        let mut tt = entry.key == table_key && entry.bound != 0;
        if tt
            && !seen
            && ply > 1
            && (depth > 0 || Q_CACHE)
            && i16::from(entry.depth) >= depth.max(0)
        {
            let score = from_tt(entry.score as i32, ply);
            if entry.bound == 1
                || (entry.bound == 2 && score >= beta)
                || (entry.bound == 3 && score <= alpha)
            {
                return score;
            }
        }
        let original_alpha = alpha;
        let mut moves = std::mem::take(&mut self.move_buffers[ply]);
        if depth <= 0 {
            p.captures(&mut moves);
        } else {
            p.generate(&mut moves);
        }
        // A quiet position can still contain an immediate opposing capture
        // threat. Search one defensive reply layer before trusting static eval.
        // Children receive negative q-depth, preventing repeated quiet extension.
        let threatened = depth == 0 && moves.is_empty() && p.has_capture(p.turn ^ 1);
        if threatened {
            p.generate(&mut moves);
        }
        if moves.is_empty() {
            if depth <= 0 && p.has_quiet() {
                if SACRIFICES && p.kings == [0, 0] && !p.has_capture(p.turn ^ 1) {
                    crate::sacrifices::generate(p, &mut moves);
                }
                if QUIET_PROMOTIONS {
                    let targets = p.empty() & if p.turn == 0 { 31 } else { 31 << 58 };
                    for step in [6, 7] {
                        let sources = p.men[p.turn]
                            & if p.turn == 0 {
                                targets << step
                            } else {
                                targets >> step
                            };
                        for from in crate::board::bits(sources) {
                            let to = if p.turn == 0 {
                                from - step
                            } else {
                                from + step
                            };
                            let m = Move::new(from, to, 0);
                            if !moves.contains(&m) {
                                moves.push(m);
                            }
                        }
                    }
                }
                if moves.is_empty() {
                    self.move_buffers[ply] = moves;
                    let score = self.value(p);
                    if Q_CACHE && !seen {
                        self.store(table_key, Move::default(), score, 0, 1, ply);
                    }
                    return score;
                }
            } else {
                self.move_buffers[ply] = moves;
                return -INF + ply as i32;
            }
        }
        if ply >= MAX_PLY - 1 {
            self.move_buffers[ply] = moves;
            return self.value(p);
        }
        let capture = moves[0].is_capture();
        let stand_pat = depth <= 0 && !capture && !threatened;
        let initial_score = if stand_pat { self.value(p) } else { -INF };
        if stand_pat && initial_score >= beta {
            self.move_buffers[ply] = moves;
            if Q_CACHE && !seen {
                self.store(table_key, Move::default(), initial_score, 0, 2, ply);
            }
            return initial_score;
        }
        // Real mate bounds, independent of static evaluation or selectivity.
        if -INF + ply as i32 + 2 >= beta {
            self.move_buffers[ply] = moves;
            return -INF + ply as i32 + 2;
        }
        let quiet_safe = !capture && !p.has_capture(p.turn ^ 1);
        let selective = !ENDGAME_GUARD || p.all().count_ones() > 10;
        if EXTRA_PRUNING
            && selective
            && allow_pruning
            && excluded == Move::default()
            && beta - alpha == 1
            && alpha.abs() < 8000
            && quiet_safe
            && depth > 0
        {
            let value = self.value(p);
            if depth <= 2 && value + 200 + i32::from(depth) * 150 < alpha {
                let q = self.ab(p, key, 0, alpha - 1, alpha, ply, path, false);
                if self.aborted {
                    self.move_buffers[ply] = moves;
                    return 0;
                }
                if q < alpha {
                    self.move_buffers[ply] = moves;
                    return q;
                }
            }
            // Only quiet midgames, and require a real-move verification of a pass.
            if depth >= 5
                && p.all().count_ones() >= 12
                && p.side(p.turn).count_ones() >= 4
                && value >= beta
                && beta.abs() < 7800
            {
                let nd = (depth - 4 - depth / 5).max(1);
                let mut null = p;
                null.turn ^= 1;
                self.repetition_start[ply + 1] = path.len();
                let n = -self.ab(
                    null,
                    key ^ TURN_KEY,
                    nd,
                    -beta,
                    -beta + 1,
                    ply + 1,
                    path,
                    false,
                );
                if self.aborted {
                    self.move_buffers[ply] = moves;
                    return 0;
                }
                if n >= beta && n.abs() < 8000 {
                    let verify =
                        self.ab(p, key, (depth - 3).max(1), beta - 1, beta, ply, path, false);
                    if self.aborted {
                        self.move_buffers[ply] = moves;
                        return 0;
                    }
                    if verify >= beta {
                        self.move_buffers[ply] = moves;
                        return verify;
                    }
                }
            }
        }
        if SCAN_FORWARD
            && selective
            && allow_pruning
            && depth >= 3
            && beta - alpha == 1
            && beta.abs() < 7800
            && !seen
            && excluded == Move::default()
        {
            let margin = i32::from(depth) * 10;
            let v = self.ab(
                p,
                key,
                depth * 40 / 100,
                beta + margin - 1,
                beta + margin,
                ply,
                path,
                false,
            );
            if self.aborted {
                self.move_buffers[ply] = moves;
                return 0;
            }
            if v >= beta + margin {
                self.move_buffers[ply] = moves;
                return v - margin;
            }
        }
        alpha = alpha.max(initial_score);
        // A shallow internal search supplies an ordering move after a table miss.
        if IID
            && depth >= 6
            && !tt
            && excluded == Move::default()
            && (beta - original_alpha > 1 || depth >= 9)
        {
            self.ab(
                p,
                key,
                depth - if beta - original_alpha > 1 { 2 } else { 4 },
                alpha,
                beta,
                ply,
                path,
                allow_pruning,
            );
            if self.aborted {
                self.move_buffers[ply] = moves;
                return 0;
            }
            entry = self.probe(table_key);
            tt = entry.bound != 0 && entry.key == table_key;
        }
        let prev = if ply == 0 {
            Move::default()
        } else {
            self.played[ply - 1]
        };
        let counter = self.countermoves[p.turn][prev.from() as usize][prev.to() as usize];
        let singular_move = if SINGULAR
            && depth >= 8
            && tt
            && excluded == Move::default()
            && entry.bound <= 2
            && i16::from(entry.depth) >= depth - 4
            && entry.score.abs() < 8000
            && moves.len() > 1
        {
            let mut candidates = moves
                .iter()
                .copied()
                .filter(|&m| move_index(m) == entry.best);
            let one = candidates.next().unwrap_or_default();
            if candidates.next().is_none() {
                one
            } else {
                Move::default()
            }
        } else {
            Move::default()
        };
        let mut singular = false;
        if singular_move != Move::default() && beta - original_alpha > 1 {
            let sb = from_tt(i32::from(entry.score), ply) - 30;
            self.excluded[ply] = singular_move;
            let alternative = self.ab(p, key, depth - 4, sb - 1, sb, ply, path, false);
            self.excluded[ply] = Move::default();
            if self.aborted {
                self.move_buffers[ply] = moves;
                return 0;
            }
            singular = alternative < sb;
        }
        moves.sort_unstable_by_key(|m| {
            std::cmp::Reverse(if tt && entry.best == move_index(*m) {
                2_000_000
            } else if m.is_capture() {
                1_000_000
                    + m.capture_count() as i32 * 1000
                    + (m.caps() & p.kings[p.turn ^ 1]).count_ones() as i32 * 2000
                    + self.capture_history[p.turn][m.from() as usize][m.to() as usize]
            } else if self.killers[ply][0] == *m {
                900_000
            } else if self.killers[ply][1] == *m {
                800_000
            } else if counter == *m {
                700_000
            } else {
                self.history[p.turn][m.from() as usize][m.to() as usize]
            })
        });
        let mut best = moves[0];
        let mut best_score = initial_score;
        path.push(p);
        for (i, &m) in moves.iter().enumerate() {
            if m == excluded {
                continue;
            }
            self.repetition_start[ply + 1] = if m.conversion(p) {
                path.len()
            } else {
                reversible
            };
            let child = p.play(m);
            self.played[ply] = m;
            let child_key = successor_hash(key, p, m);
            // A forced reply is not a new decision. Extend it only in regular
            // search; quiescence must continue decreasing toward quiet leaves.
            let extension =
                i16::from(depth > 0 && (moves.len() == 1 || (singular && m == singular_move)));
            let next_depth = if THREAT_CHAIN && threatened {
                i16::from(moves.len() == 1)
            } else {
                depth - 1 + extension
            };
            let mut score;
            if i == 0 || depth <= 0 {
                score = -self.ab(
                    child,
                    child_key,
                    next_depth,
                    -beta,
                    -alpha,
                    ply + 1,
                    path,
                    allow_pruning,
                );
            } else {
                // Spend less on late quiet alternatives, while protecting the
                // PV, both killers, promotions and well-established good moves.
                // Every reduced move raising alpha is verified at full depth.
                let pv_node = beta - original_alpha > 1;
                let reduce = if selective
                    && depth >= (if SCAN_LMR { 2 } else { 4 })
                    && i >= (if SCAN_LMR && !pv_node { 2 } else { 4 })
                    && !capture
                    && m != self.killers[ply][0]
                    && m != self.killers[ply][1]
                    && m != counter
                    && extension == 0
                    && !(p.men[p.turn] & (1 << m.from()) != 0
                        && crate::board::is_promotion(m.to(), p.turn))
                {
                    let base = REDUCTIONS[depth.min(31) as usize][(i + 1).min(63)];
                    let pv = i16::from(beta - original_alpha > 1);
                    let good_history =
                        i16::from(self.history[p.turn][m.from() as usize][m.to() as usize] > 4000);
                    (base - pv - good_history).clamp(0, depth - 2)
                } else {
                    0
                };
                score = -self.ab(
                    child,
                    child_key,
                    next_depth - reduce,
                    -alpha - 1,
                    -alpha,
                    ply + 1,
                    path,
                    allow_pruning,
                );
                if reduce > 0 && score > alpha && !self.aborted {
                    score = -self.ab(
                        child,
                        child_key,
                        next_depth,
                        -alpha - 1,
                        -alpha,
                        ply + 1,
                        path,
                        allow_pruning,
                    );
                }
                if score > alpha && score < beta && !self.aborted {
                    score = -self.ab(
                        child,
                        child_key,
                        next_depth,
                        -beta,
                        -alpha,
                        ply + 1,
                        path,
                        allow_pruning,
                    );
                }
            }
            if self.aborted {
                path.pop();
                self.move_buffers[ply] = moves;
                return 0;
            }
            if score > best_score {
                best_score = score;
                best = m;
            }
            alpha = alpha.max(score);
            if alpha >= beta {
                let bonus = (depth.max(1) as i32 * depth.max(1) as i32 * 16).min(2048);
                if capture {
                    update_history(
                        &mut self.capture_history[p.turn][m.from() as usize][m.to() as usize],
                        bonus,
                    );
                }
                if !capture {
                    if self.killers[ply][0] != m {
                        self.killers[ply][1] = self.killers[ply][0];
                        self.killers[ply][0] = m;
                    }
                    self.countermoves[p.turn][prev.from() as usize][prev.to() as usize] = m;
                    update_history(
                        &mut self.history[p.turn][m.from() as usize][m.to() as usize],
                        bonus,
                    );
                    for &earlier in &moves[..i] {
                        update_history(
                            &mut self.history[p.turn][earlier.from() as usize]
                                [earlier.to() as usize],
                            -bonus,
                        );
                    }
                }
                break;
            }
        }
        path.pop();
        if (depth > 0 || Q_CACHE) && !seen {
            let bound = if best_score >= beta {
                2
            } else if best_score <= original_alpha {
                3
            } else {
                1
            };
            self.store(table_key, best, best_score, depth.max(0), bound, ply);
        }
        self.move_buffers[ply] = moves;
        best_score
    }
    fn probe(&self, key: u64) -> Entry {
        let bucket = &self.table[key as usize & (self.table.len() - 1)].0;
        bucket
            .iter()
            .copied()
            .find(|e| e.key == key && e.bound != 0)
            .unwrap_or_default()
    }
    #[allow(clippy::too_many_arguments)]
    fn store(&mut self, key: u64, best: Move, score: i32, depth: i16, bound: u8, ply: usize) {
        let mask = self.table.len() - 1;
        let bucket = &mut self.table[key as usize & mask].0;
        let matching = bucket.iter().position(|e| e.key == key && e.bound != 0);
        let slot = matching.unwrap_or_else(|| {
            (0..4)
                .min_by_key(|&i| {
                    let e = bucket[i];
                    if e.bound == 0 {
                        i32::MIN
                    } else {
                        i32::from(e.depth)
                            - 8 * i32::from(self.generation.wrapping_sub(e.generation))
                    }
                })
                .unwrap()
        });
        let old = bucket[slot];
        if matching.is_some()
            && old.generation == self.generation
            && i16::from(old.depth) > depth + if bound == 1 { 2 } else { 0 }
        {
            return;
        }
        bucket[slot] = Entry {
            key,
            best: move_index(best),
            score: to_tt(score, ply) as i16,
            depth: depth as i8,
            bound,
            generation: self.generation,
        };
    }
    fn value(&self, p: Position) -> i32 {
        if self.simple {
            self.eval.pst(p)
        } else {
            self.eval.evaluate(p)
        }
    }
}
// The full 64-bit position key verifies every score. This compact move tag is
// only an ordering hint; singular search requires exactly one legal match.
fn move_index(m: Move) -> u16 {
    let c = m.caps();
    u16::from(m.from())
        | (u16::from(m.to()) << 6)
        | (((c ^ (c >> 16) ^ (c >> 32) ^ (c >> 48)) & 15) as u16) << 12
}
fn repeated(p: Position, path: &[Position]) -> bool {
    path.iter().filter(|&&q| p == q).count() >= 2
}
fn to_tt(s: i32, ply: usize) -> i32 {
    if s > 8000 {
        s + ply as i32
    } else if s < -8000 {
        s - ply as i32
    } else {
        s
    }
}
fn from_tt(s: i32, ply: usize) -> i32 {
    if s > 8000 {
        s - ply as i32
    } else if s < -8000 {
        s + ply as i32
    } else {
        s
    }
}
const fn mix(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e3779b97f4a7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
    x ^ (x >> 31)
}
const PIECE_KEYS: [[u64; 63]; 4] = {
    let mut keys = [[0; 63]; 4];
    let mut piece = 0;
    while piece < 4 {
        let mut square = 0;
        while square < 63 {
            keys[piece][square] = mix((piece * 63 + square) as u64);
            square += 1;
        }
        piece += 1;
    }
    keys
};
const TURN_KEY: u64 = mix(252);
pub fn hash(p: Position) -> u64 {
    let mut key = if p.turn == 0 { 0 } else { TURN_KEY };
    for side in 0..2 {
        for square in crate::board::bits(p.men[side]) {
            key ^= PIECE_KEYS[side][square as usize];
        }
        for square in crate::board::bits(p.kings[side]) {
            key ^= PIECE_KEYS[side + 2][square as usize];
        }
    }
    key
}
fn successor_hash(mut key: u64, p: Position, m: Move) -> u64 {
    let side = p.turn;
    let king = p.kings[side] & (1 << m.from()) != 0;
    let crowned = king || crate::board::is_promotion(m.to(), side);
    key ^= TURN_KEY
        ^ PIECE_KEYS[side + 2 * usize::from(king)][m.from() as usize]
        ^ PIECE_KEYS[side + 2 * usize::from(crowned)][m.to() as usize];
    for square in crate::board::bits(m.caps()) {
        let king = p.kings[side ^ 1] & (1 << square) != 0;
        key ^= PIECE_KEYS[(side ^ 1) + 2 * usize::from(king)][square as usize];
    }
    key
}
fn update_history(value: &mut i32, bonus: i32) {
    // Bounded gravity rewards cutoffs and penalizes earlier failed quiet moves.
    *value += bonus - *value * bonus.abs() / 16384;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transposition_layout_and_verified_scores() {
        assert_eq!(std::mem::size_of::<Entry>(), 16);
        assert_eq!(std::mem::size_of::<Bucket>(), 64);
        let mut s = Search::new(1);
        let k = hash(Position::default());
        let best = Position::default().moves()[0];
        s.store(k, best, 9990, 8, 1, 4);
        let e = s.probe(k);
        assert_eq!(e.best, move_index(best));
        assert_eq!(from_tt(i32::from(e.score), 2), 9992);
        assert_eq!(s.probe(k ^ (1 << 40)).bound, 0);
        s.store(k, best, -20, 2, 3, 1);
        assert_eq!(s.probe(k).depth, 8);
        s.clear();
        assert_eq!(s.probe(k).bound, 0);
    }

    #[test]
    fn incremental_hash_matches_recomputed_positions() {
        let fixtures = [
            Position::default(),
            Position::parse("W:W28,36:B23,14,31").unwrap(),
            Position::parse("W:WK32:B27,17,7,28").unwrap(),
            Position::parse("W:W12:B7").unwrap(),
            Position::parse("B:WK36,45,49:B1,8,K14,19,K25").unwrap(),
        ];
        let mut random = 0x17caffe314159u64;
        let mut checked = 0;
        for start in fixtures {
            let mut p = start;
            for _ in 0..1000 {
                let moves = p.moves();
                for &m in &moves {
                    assert_eq!(successor_hash(hash(p), p, m), hash(p.play(m)));
                    checked += 1;
                }
                if moves.is_empty() || p.material_draw() {
                    p = start;
                } else {
                    random ^= random << 13;
                    random ^= random >> 7;
                    random ^= random << 17;
                    p = p.play(moves[random as usize % moves.len()]);
                }
            }
        }
        assert!(checked > 20000);
    }

    #[test]
    fn history_rewards_and_penalties_stay_bounded() {
        let mut h = 0;
        for bonus in [2048, -2048, 16, -16] {
            for _ in 0..10000 {
                update_history(&mut h, bonus);
                assert!((-16384..=16384).contains(&h));
            }
        }
    }
}
