use draughts::{
    board::{Position, perft},
    eval::Evaluator,
    search::{Limits, Search},
};
use std::{sync::atomic::Ordering, time::Duration};
fn p(f: &str) -> Position {
    Position::parse(f).unwrap()
}
#[test]
fn starting_moves_and_roundtrip() {
    let p = Position::default();
    assert_eq!(p.moves().len(), 9);
    assert_eq!(Position::parse(&p.hub()).unwrap(), p);
    assert_eq!(perft(p, 3), 658);
}
#[test]
fn capture_is_compulsory() {
    let p = p("W:W28,46:B23");
    assert!(!p.moves().is_empty());
    assert!(p.moves().iter().all(|m| m.is_capture()));
    assert!(p.find_move("46-41").is_err());
}
#[test]
fn backwards_capture() {
    let p = p("W:W23:B28");
    assert!(p.find_move("23x32x28").is_ok());
}
#[test]
fn promotion_after_sequence() {
    let p = p("W:W12:B7");
    let m = p.find_move("12x1x7").unwrap();
    let next = p.play(m);
    assert_eq!(next.men[0], 0);
    assert_eq!(next.kings[0].count_ones(), 1);
}
#[test]
fn free_choice_not_max_capture() {
    let p = p("W:W28,36:B23,14,31");
    let moves = p.moves();
    assert!(moves.iter().any(|m| m.capture_count() == 1));
    assert!(moves.iter().any(|m| m.capture_count() == 2));
}
#[test]
fn no_capture_prefixes() {
    let p = p("W:W28:B23,14");
    assert!(p.moves().iter().all(|m| m.capture_count() == 2));
}
#[test]
fn nigerian_material_draw() {
    for f in ["W:WK46:BK5", "W:WK46:B1,2,3", "B:W31,32,33:BK5"] {
        assert!(p(f).material_draw());
    }
    assert!(!p("W:WK46:B1,2,3,4").material_draw());
}
#[test]
fn bad_positions_rejected() {
    for s in [
        "",
        "W:W1:B2",
        "W:W31:B50",
        "W:W31:B31",
        "W:W31:B",
        "W:W0:B3",
        "W:W31:BX",
        "W:WK51:B3",
    ] {
        assert!(Position::parse(s).is_err(), "{s}");
    }
}
#[test]
fn eval_rotation_symmetry() {
    let e = Evaluator::new();
    let p = p("W:W28,32,36:BK5,18");
    let flip = Position {
        men: [p.men[1].reverse_bits() >> 1, p.men[0].reverse_bits() >> 1],
        kings: [
            p.kings[1].reverse_bits() >> 1,
            p.kings[0].reverse_bits() >> 1,
        ],
        turn: p.turn ^ 1,
    };
    assert_eq!(e.evaluate(p), e.evaluate(flip));
}
#[test]
fn search_produces_legal_move_and_respects_nodes() {
    let mut e = Search::new(1);
    let p = Position::default();
    let r = e.run(
        p,
        &[],
        Limits {
            depth: 12,
            nodes: 1500,
            time: Duration::from_secs(10),
        },
        |_| {},
    );
    assert!(p.moves().contains(&r.best.unwrap()));
    assert!(r.nodes <= 1500);
    assert!(r.depth > 0);
}
#[test]
fn search_draw_and_repetition() {
    let mut e = Search::new(1);
    let limits = Limits {
        depth: 4,
        nodes: 1000,
        time: Duration::from_secs(1),
    };
    let drawn = p("W:WK46:BK5");
    assert!(e.run(drawn, &[], limits.clone(), |_| {}).best.is_none());
    let p = Position::default();
    let r = e.run(p, &[p, p], limits, |_| {});
    assert_eq!(r.score, 0);
    assert!(r.best.is_none());
}
#[test]
fn already_stopped_search_returns_legal_fallback() {
    let mut e = Search::new(1);
    e.stop.store(true, Ordering::Relaxed);
    let r = e.run(Position::default(), &[], Limits::default(), |_| {});
    assert_eq!(r.depth, 0);
    assert!(r.best.is_some());
    assert_eq!(r.nodes, 0);
}

#[test]
fn game_save_load_undo_and_resign() {
    use draughts::game::{Game, Outcome};
    let mut game = Game::default();
    for text in ["31-26", "16-21"] {
        let m = game.position.find_move(text).unwrap();
        game.play(m).unwrap();
    }
    let saved = game.save();
    let loaded = Game::load(&saved).unwrap();
    assert_eq!(loaded.position, game.position);
    assert_eq!(loaded.moves, game.moves);
    game.resigned = Some(0);
    assert_eq!(game.outcome(), Some(Outcome::Win(1)));
    assert!(game.undo());
    assert!(game.resigned.is_none());
    assert_eq!(game.moves.len(), 1);
    assert!(Game::load("garbage").is_err());
}

#[test]
fn shallow_search_matches_exhaustive_minimax() {
    fn exact(p: Position, depth: i32, ply: i32, e: &Evaluator, root_turn: usize) -> i32 {
        if p.material_draw() {
            return if p.turn == root_turn {
                -draughts::search::DRAW_PRESSURE
            } else {
                draughts::search::DRAW_PRESSURE
            };
        }
        let moves = p.moves();
        if moves.is_empty() {
            return -10000 + ply;
        }
        if depth <= 0 && !moves[0].is_capture() {
            // Independently identify an opponent capture through its full list.
            let mut opponent = p;
            opponent.turn ^= 1;
            let threat = opponent.moves().first().is_some_and(|m| m.is_capture());
            if depth < 0 || !threat {
                let mut selected = Vec::new();
                if p.kings == [0, 0] && !threat {
                    draughts::sacrifices::generate(p, &mut selected);
                }
                // Exhaust every selected quiet exchange with no alpha-beta,
                // table, reduction, ordering, or evaluation-based cutoff.
                return selected
                    .into_iter()
                    .map(|m| -exact(p.play(m), depth - 1, ply + 1, e, root_turn))
                    .fold(e.evaluate(p), i32::max);
            }
        }
        // Reference minimax uses the engine's new horizon policy: a forced
        // non-root reply consumes no decision depth. It has no TT or pruning.
        let child_depth = depth - 1 + i32::from(ply > 0 && depth > 0 && moves.len() == 1);
        moves
            .into_iter()
            .map(|m| -exact(p.play(m), child_depth, ply + 1, e, root_turn))
            .max()
            .unwrap()
    }
    let mut e = Search::new(1);
    let mut positions = vec![
        Position::default(),
        p("W:W28,36:B23,14,31"),
        p("B:W31,32,36:B16,18,20"),
    ];
    let mut board = Position::default();
    for step in 0..240 {
        let moves = board.moves();
        if board.material_draw() || moves.is_empty() {
            board = Position::default();
        } else {
            board = board.play(moves[(step * 19 + 23) % moves.len()]);
            if step % 12 == 0 && !board.material_draw() && !board.moves().is_empty() {
                positions.push(board);
            }
        }
    }
    for p in positions {
        let expected = exact(p, 3, 0, &e.eval, p.turn);
        e.clear();
        let r = e.run(
            p,
            &[],
            Limits {
                depth: 3,
                nodes: 1_000_000,
                time: Duration::from_secs(10),
            },
            |_| {},
        );
        if expected.abs() <= 8000 {
            assert_eq!(r.depth, 3);
        }
        assert_eq!(r.score, expected);
    }
    // At most four quiet choices per side: no late-move reduction applies.
    // Depth six exercises aspiration retries against exhaustive minimax.
    for board in [p("W:W31,36:B16,20"), p("B:W32,37:B15,19")] {
        let expected = exact(board, 6, 0, &e.eval, board.turn);
        e.clear();
        let report = e.run(
            board,
            &[],
            Limits {
                depth: 6,
                nodes: 1_000_000,
                time: Duration::from_secs(10),
            },
            |_| {},
        );
        assert_eq!(report.score, expected);
        if expected.abs() <= 8000 {
            assert_eq!(report.depth, 6);
        }
    }
}

#[test]
fn king_capture_reaches_real_draw_instead_of_false_win() {
    // Actual game 4 finish: capturing the king and man leaves a lone king
    // versus two men. The original C++ search reported +99.87 here.
    let position = p("W:WK35:B16,23,25,K30");
    assert!(!position.material_draw());
    assert!(
        position
            .moves()
            .iter()
            .all(|&m| position.play(m).material_draw())
    );
    let r = Search::new(1).run(
        position,
        &[],
        Limits {
            depth: 12,
            nodes: 100000,
            time: Duration::from_secs(1),
        },
        |_| {},
    );
    // This is a declared search preference, not a different game outcome.
    assert_eq!(r.score, -draughts::search::DRAW_PRESSURE);
    let after = position.play(r.best.unwrap());
    let game = draughts::game::Game {
        position: after,
        ..Default::default()
    };
    assert_eq!(game.outcome(), Some(draughts::game::Outcome::Draw));
    assert!(position.moves().contains(&r.best.unwrap()));
}

#[test]
fn interrupted_iterations_keep_last_completed_report() {
    let position = Position::default();
    let mut completed = Vec::new();
    let report = Search::new(1).run(
        position,
        &[],
        Limits {
            depth: 40,
            nodes: 30000,
            time: Duration::from_secs(10),
        },
        |r| completed.push(r.clone()),
    );
    let last = completed.last().unwrap();
    assert_eq!(
        (report.best, report.score, report.depth),
        (last.best, last.score, last.depth)
    );
    assert!(completed.windows(2).all(|r| r[1].depth == r[0].depth + 1));
    assert!(
        completed
            .iter()
            .all(|r| position.moves().contains(&r.best.unwrap()))
    );
    assert!(report.nodes <= 30000);
    assert!(report.depth < 40);
}

#[test]
fn bitboard_king_rays_match_independent_square_walk() {
    use draughts::board::{DIRS, SPARSE, SQUARES, king_quiets, valid};
    let mut random = 0x123456789abcdefu64;
    for _ in 0..500 {
        random ^= random << 13;
        random ^= random >> 7;
        random ^= random << 17;
        let empty = random & SQUARES;
        for from in SPARSE {
            let mut expected = 0;
            for d in DIRS {
                let mut q = from as i16 + d as i16;
                while valid(q) && empty & (1 << q) != 0 {
                    expected |= 1 << q;
                    q += d as i16;
                }
            }
            assert_eq!(king_quiets(from, empty), expected);
        }
    }
}

#[test]
fn capture_only_generation_matches_full_generator() {
    let mut p = Position::default();
    let mut caps = Vec::new();
    for i in 0..180 {
        let moves = p.moves();
        p.captures(&mut caps);
        assert_eq!(
            caps,
            moves
                .iter()
                .copied()
                .filter(|m| m.is_capture())
                .collect::<Vec<_>>()
        );
        if caps.is_empty() {
            assert_eq!(p.has_quiet(), !moves.is_empty());
        }
        if moves.is_empty() || p.material_draw() {
            p = Position::default();
        } else {
            p = p.play(moves[(i * 23 + 7) % moves.len()]);
        }
    }
}

#[test]
fn real_king_cycle_is_threefold_draw() {
    use draughts::game::{Game, Outcome};
    let mut game = Game {
        position: p("W:WK32,K50:BK1,K2"),
        ..Game::default()
    };
    for round in 0..2 {
        for text in ["32-27", "1-6", "27-32", "6-1"] {
            let m = game.position.find_move(text).unwrap();
            game.play(m).unwrap();
        }
        if round == 0 {
            assert!(game.outcome().is_none());
        }
    }
    assert_eq!(game.outcome(), Some(Outcome::Draw));
    let r = Search::new(1).run(game.position, &game.history, Limits::default(), |_| {});
    assert_eq!(r.score, 0);
    assert!(r.best.is_none());
}

#[test]
fn promotion_row_shortcut_matches_board_geometry() {
    use draughts::board::{SPARSE, is_promotion, rank};
    for square in SPARSE {
        for side in 0..2 {
            assert_eq!(
                is_promotion(square, side),
                rank(square) == if side == 0 { 0 } else { 9 }
            );
        }
    }
}

#[test]
fn compact_move_roundtrip_and_ordering() {
    use draughts::board::{Move, SPARSE, SQUARES};
    assert_eq!(std::mem::size_of::<Move>(), 8);
    let mut seed = 0xdeadbeef12345678u64;
    let mut previous = 0u64;
    for i in 0..20000 {
        seed ^= seed << 13;
        seed ^= seed >> 7;
        seed ^= seed << 17;
        let caps = seed & SQUARES;
        let from = SPARSE[i % 50];
        let to = SPARSE[(i * 17) % 50];
        let m = Move::new(from, to, caps);
        assert_eq!((m.from(), m.to(), m.caps()), (from, to, caps));
        assert_eq!(m.capture_count(), caps.count_ones());
        assert_eq!(m.is_capture(), caps != 0);
        let a = Move::new(from, to, previous);
        assert_eq!(a.order_key().cmp(&m.order_key()), previous.cmp(&caps));
        previous = caps;
    }
}

#[test]
fn capture_predicate_matches_complete_sequences_for_both_sides() {
    let mut random = 0x7319caffe195u64;
    let mut board = Position::default();
    for _ in 0..10000 {
        for side in 0..2 {
            let mut q = board;
            q.turn = side;
            let mut captures = Vec::new();
            q.captures(&mut captures);
            assert_eq!(board.has_capture(side), !captures.is_empty());
        }
        let moves = board.moves();
        if moves.is_empty() || board.material_draw() {
            board = Position::default();
        } else {
            random ^= random << 13;
            random ^= random >> 7;
            random ^= random << 17;
            board = board.play(moves[random as usize % moves.len()]);
        }
    }
}

#[test]
fn auxiliary_proof_respects_small_node_and_stop_limits() {
    let p = Position::parse("W:W31,36:B16,20").unwrap();
    let mut s = Search::new(1);
    let r = s.run(
        p,
        &[],
        Limits {
            depth: 20,
            nodes: 64,
            time: Duration::from_secs(1),
        },
        |_| {},
    );
    assert!(r.nodes <= 64);
    s.stop.store(true, Ordering::Relaxed);
    let r = s.run(
        p,
        &[],
        Limits {
            depth: 20,
            nodes: 10000,
            time: Duration::from_secs(1),
        },
        |_| {},
    );
    assert_eq!(r.nodes, 0);
    assert_eq!(r.depth, 0);
}

#[test]
fn canonical_capture_is_not_confused_with_a_longer_superset_capture() {
    let p = Position::parse("BbbeeeWeewweeeeebeeeeeeeeeeeewBebeeeeeeeeewbWbBeeeB").unwrap();
    for text in ["50x47x42x44", "50x47x9x10x29x42x44"] {
        let m = p.find_move(text).expect("fully specified legal capture");
        assert_eq!(m.to_string(), text);
        assert!(p.moves().contains(&m));
    }
    assert!(
        p.find_move("50x47").is_err(),
        "genuinely ambiguous abbreviation stays ambiguous"
    );
}
