Kentrodraught Rust engine - retained warm round 12

Linux x86-64 executable: ./scan_nigerian
HUB protocol: ./scan_nigerian hub
Rust source and current evaluation weights: source/
Build: cargo build --release --manifest-path source/Cargo.toml --bin scan_nigerian
The supplied binary was built for the original cloud CPU. Rebuild on a different CPU if necessary.

Original Nigerian game rules preserved. No trainer, games, research datasets or build caches included.
This model has NOT achieved seven wins in ten; latest fresh confirmation was zero wins, zero losses, nine rule draws and one cutoff.
GPL-3.0-or-later; see LICENSE.
