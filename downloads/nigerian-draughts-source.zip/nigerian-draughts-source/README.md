# Nigerian Draughts - Rust source

This smaller package contains the complete Rust source, trained evaluation data,
Cargo files, tests, and license. Compiled binaries and research archives are
omitted. Build locally with a Rust toolchain supporting edition 2024:

    cargo build --release --locked --bin scan_nigerian
    ./target/release/scan_nigerian

For HUB protocol mode:

    ./target/release/scan_nigerian hub

For the GUI, install the platform's X11 development libraries, then run:

    cargo build --release --locked --features gui --bin nigerian-draughts-gui
    ./target/release/nigerian-draughts-gui

The GUI requires a working X11 display. The trained evaluation data is embedded
at compile time; keep data/eval_nigerian when building the project.

The C++ game rules and existing evaluator architecture are preserved.
The supplied source, engine, GUI, and trained weights are unchanged from the
previous package. Only packaging and this README have changed.

Recorded validation: all 335 tactical certificates passed. At one second per
move, the final ten-game C++ comparison was 4 wins, 2 losses, and 4 draws.
The requested seven-win target was not reached in that comparison.

License: GPL-3.0-or-later. See the source LICENSE and source attribution.
